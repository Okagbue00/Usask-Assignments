


import java.util.ArrayList;

public class messageHandler {

    private String pseudo;
    private ArrayList<message> listMsg;

    public messageHandler(){
        this.pseudo = "";
        this.listMsg = new ArrayList<message>();
    }
    public messageHandler(String pseudo){
        this.pseudo = pseudo;
        this.listMsg = new ArrayList<message>();
    }
    public String getPseudo() {
        return pseudo;
    }

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public ArrayList<message> getListMsg() {
        return listMsg;
    }

    public void setListMsg(ArrayList<message> listMsg) {
        this.listMsg = listMsg;
    }

}
