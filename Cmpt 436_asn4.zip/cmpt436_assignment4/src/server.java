import javax.xml.ws.Endpoint;



public class server {

    public static void main(String[] str){

        Endpoint.publish("http://localhost:8080/", new serverHandler());

        System.out.println("Server is up and running...");
    }

}


