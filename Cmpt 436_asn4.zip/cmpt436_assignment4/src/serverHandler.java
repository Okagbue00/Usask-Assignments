


import java.util.ArrayList;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(endpointInterface = "serverHandler")

public class serverHandler  implements serverChat{

    private final ArrayList<messageHandler> userList;

    public serverHandler(){
        this.userList = new ArrayList<messageHandler>();
    }

    @Override
    public boolean subscribe(String pseudo){
        messageHandler u = this.getUser(pseudo);
        synchronized (userList){
            if(u != null)
                return false;
            userList.add(new messageHandler(pseudo));
            return true;
        }
    }

    @Override
    public boolean unsubscribe(String pseudo){
        messageHandler subs = this.getUser(pseudo);
        synchronized (userList){
            if(subs == null)
                return false;
            userList.remove(subs);
            return true;
        }
    }

    @Override
    public String getMessageUser(String pseudo){
        messageHandler u = this.getUser(pseudo);
        synchronized (userList){
            if(u == null)
                return "";
            String m =u.getListMsg().toString();
            u.getListMsg().clear();
            return m;
        }

    }

    @Override
    public void postMsg(String pseudo, String Message){
        message m = new message(pseudo, Message);
        synchronized (userList){
            for(messageHandler u:userList){
                if(!u.getPseudo().equals(pseudo))
                    u.getListMsg().add(m);
            }
        }

    }

    private messageHandler getUser(String pseudo){
        for(messageHandler u : userList)
            if(u.getPseudo().equals(pseudo))
                return u;
        return null;
    }

}

