/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import java.util.ArrayList;

public class Blob implements Groupable{
    double x, y;
    double r;

    public Blob(double nx, double ny) {
        x = nx;
        y = ny;
        r = 50;
    }

    public void move(double dx, double dy) {
        x += dx;
        y += dy;
    }

    public boolean contains(double cx, double cy) {
        return dist(cx, cy, x ,y) <= r;
    }

    private double dist(double x1,double y1,double x2, double y2) {
        return Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));
    }

    public ArrayList<Groupable> getChildren() {
        return null;
    }

    public void resize(double x){
        if (!(r < 5) || !(x < 0)) {
            r = r + x;
        }
    }

    public boolean isContained(double x1, double y1, double x2, double y2) {
        return !(x - r < x1) && y - r >= y1 && x + r <= x2 && y + r <= y2;
    }

    public boolean hasChildren() {
        return false;
    }

    public double getTop() {
        return y - r;
    }

    public double getBottom() {
        return y + r;
    }

    public double getLeft() {
        return x - r;
    }

    public double getRight() {
        return x + r;
    }

}
