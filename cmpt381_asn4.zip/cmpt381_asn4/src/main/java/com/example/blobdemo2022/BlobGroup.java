/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import java.util.ArrayList;

import static java.lang.Math.max;
import static java.lang.Math.min;

public class BlobGroup implements Groupable {

    ArrayList<Groupable> children;
    double left;
    double right;
    double top;
    double bottom;


    public BlobGroup() {
        right = 0;
        bottom = 0;
        children = new ArrayList<>();
        left = Double.MAX_VALUE;
        top = Double.MAX_VALUE;

    }

    public void add(Groupable g) {
        children.add(g);
        left = min(g.getLeft(), left);
        top = min(g.getTop(), top);
        right = max(g.getRight(), right);
        bottom = max(g.getBottom(), bottom);
    }

    public boolean hasChildren() {
        return true;
    }

    public boolean contains(double x, double y) {
        for (Groupable g : children) {
            if (!g.contains(x, y)) {
                continue;
            }
            return true;
        }
        return false;
    }

    public boolean isContained(double x1, double y1, double x2, double y2) {
        for (Groupable g : children) {
            if (g.isContained(x1, y1, x2, y2)) {
                continue;
            }
            return false;
        }
        return true;
    }

    public void move(double dx, double dy) {
        children.forEach(g -> g.move(dx, dy));
        left = left + dx;
        top = top + dy;
        right = right + dx;
        bottom = bottom + dy;
    }

    public ArrayList<Groupable> getChildren() {
        return children;
    }

    public double getLeft() {
        return left;
    }

    public double getRight() {
        return right;
    }

    public double getTop() {
        return top;
    }

    public double getBottom() {
        return bottom;
    }

    public void remove(Groupable g) {
        children.remove(g);
    }



}
