/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */
package com.example.blobdemo2022;

import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.util.ArrayList;
import java.util.List;

public class BlobController {
    BlobModel model;
    InteractionModel iModel;
    double prevX, prevY;
    double dX, dY;
    State currentState = State.READY;
    Groupable hitGroup = null;

    public BlobController() {
    }

    public void setModel(BlobModel newModel) {
        model = newModel;
    }

    public void setIModel(InteractionModel newIModel) {
        iModel = newIModel;
    }

    public void handlePressed(MouseEvent event) {
        if (iModel.currentState != InteractionModel.pageState.EDIT) {
            switch (currentState) {
                case READY -> {
                    boolean hit = model.hitBlob(event.getX(), event.getY());
                    if (hit) {
                        hitGroup = model.find(event.getX(), event.getY());
                        currentState = State.TRAINING;
                    }
                }
            }
        } else {
            switch (currentState) {
                case READY -> {
                    boolean hit = model.hitBlob(event.getX(), event.getY());
                    boolean wasSelected = false;
                    if (hit) {
                        hitGroup = model.find(event.getX(), event.getY());
                        wasSelected = iModel.isSelected(hitGroup);
                    }
                    if (!iModel.shiftDown && !iModel.controlDown && hit && !wasSelected) {
                        iModel.setSelection(hitGroup);
                        prevX = event.getX();
                        prevY = event.getY();
                        currentState = State.DRAGGING;
                    } else if (!iModel.shiftDown && !iModel.controlDown && !hit) {
                        prevX = event.getX();
                        prevY = event.getY();
                        iModel.clearSelection();
                        currentState = State.PREPARE_RUBBER;
                    } else if (iModel.shiftDown && !iModel.controlDown && !hit) {
                        currentState = State.PREPARE_CREATE;
                    } else if (iModel.shiftDown && !iModel.controlDown && hit) {
                        prevX = event.getX();
                        prevY = event.getY();
                        currentState = State.RESIZING;
                    } else if (!iModel.shiftDown && !iModel.controlDown && hit) {
                        prevX = event.getX();
                        prevY = event.getY();
                        currentState = State.DRAGGING;
                    } else if (iModel.controlDown && !hit) {
                        prevX = event.getX();
                        prevY = event.getY();
                        currentState = State.PREPARE_RUBBER;
                    } else if (iModel.controlDown && hit && !wasSelected) {
                        prevX = event.getX();
                        prevY = event.getY();
                        iModel.addSelection(hitGroup);
                        currentState = State.DRAGGING;
                    } else if (iModel.controlDown && hit && wasSelected) {
                        prevX = event.getX();
                        prevY = event.getY();
                        iModel.removeSelection(hitGroup);
                        currentState = State.DRAGGING;
                    }
                }
            }
        }
    }

    public void handleDragged(MouseEvent event) {
        if (iModel.currentState != InteractionModel.pageState.EDIT) {

        } else {
            switch (currentState) {
                case PREPARE_CREATE -> {
                    currentState = State.READY;
                }
                case DRAGGING -> {
                    dX = event.getX() - prevX;
                    dY = event.getY() - prevY;
                    prevX = event.getX();
                    prevY = event.getY();
                    // - move blob
                    model.move(iModel.selection, dX, dY);
                    // transition to new state: same state
                }
                case RESIZING -> {
                    ArrayList<Groupable> allSelected = iModel.getAllSelected();
                    System.out.println("Selected List Size : " + allSelected.size());
                    dX = event.getX() - prevX;
                    prevX = event.getX();
                    model.resizeBlob(allSelected, dX);
                }
                case PREPARE_RUBBER -> {
                    iModel.createRubber(prevX, prevY);
                    iModel.setRubberEnd(event.getX(), event.getY());
                    currentState = State.RUBBERBAND;
                }
                case RUBBERBAND -> {
                    iModel.setRubberEnd(event.getX(), event.getY());
                }
            }
        }
    }

    public void handleReleased(MouseEvent event) {
        if (iModel.currentState != InteractionModel.pageState.EDIT) {
            switch (currentState) {
                case TRAINING -> {
                    boolean st = model.showNextTarget();
                    currentState = State.READY;
                    if (!st){
                        iModel.currentState = InteractionModel.pageState.REPORT;

                        model.showChart();
                    }

                }
            }
        }else{
            switch (currentState) {
                case PREPARE_CREATE -> {
                    model.addBlob(event.getX(), event.getY());
                    currentState = State.READY;
                }
                case DRAGGING -> {
                    iModel.unselect();
                    currentState = State.READY;
                }
                case RESIZING -> {
                    iModel.unselect();
                    currentState = State.READY;
                }
                case PREPARE_RUBBER -> {
                    iModel.clearSelection();
                    currentState = State.READY;
                }
                case RUBBERBAND -> {
                    List<Groupable> rubberSet;
                    rubberSet = model.findInRubberband(iModel.rubber.left,
                            iModel.rubber.top, iModel.rubber.left + iModel.rubber.width,
                            iModel.rubber.top + iModel.rubber.height);
                    iModel.addSubtractSelection(rubberSet);
                    iModel.deleteRubber();
                    currentState = State.READY;
                }
            }
        }
    }

    public void handleKeyPressed(KeyEvent event) {
        if (iModel.currentState != InteractionModel.pageState.EDIT) {
            switch (event.getCode()) {
                case CONTROL:
                    iModel.setControl(true);
                    break;
                case SHIFT:
                    iModel.setShift(true);
                    break;
                case T:
                    if (iModel.controlDown) {
                        iModel.currentState = InteractionModel.pageState.TEST;
                        model.showTargetTrainerView();
                    }
                    break;
                case E:
                    if (iModel.controlDown) {
                        iModel.currentState = InteractionModel.pageState.EDIT;
                        model.showEditorView();
                    }
                    break;
            }
        }else{
            switch (event.getCode()) {
                case CONTROL:
                    iModel.setControl(true);
                    break;
                case SHIFT:
                    iModel.setShift(true);
                    break;
                case DELETE:
                    ArrayList<Groupable> allSelected = iModel.getAllSelected();
                    System.out.println("List Size selected is : " + allSelected.size());
                    model.deleteSelectedBlob(allSelected);
                    break;
                case X:
                    if (iModel.controlDown) {
                        allSelected = iModel.getAllSelected();
                        model.cutSelected(allSelected);
                    }
                    break;
                case C:
                    if (iModel.controlDown) {
                        allSelected = iModel.getAllSelected();
                        model.copySelected(allSelected);
                    }
                    break;
                case V:
                    if (iModel.controlDown) {
                        model.pasteSelected(iModel);
                    }
                    break;
                case Z:
                    if (iModel.controlDown) {
                        model.undo();
                    }
                    break;
                case R:
                    if (iModel.controlDown) {
                        model.redo();
                    }
                    break;
                case T:
                    if (iModel.controlDown) {
                        iModel.currentState = InteractionModel.pageState.TEST;
                        model.showTargetTrainerView();
                    }
                    break;
                case E:
                    if (iModel.controlDown) {
                        iModel.currentState = InteractionModel.pageState.EDIT;
                        model.showEditorView();
                    }
                    break;

            }
        }
    }

    public void handleKeyReleased(KeyEvent event) {
        System.out.println("Event Type Released : " + event.getCode());
        switch (event.getCode()) {
            case CONTROL:
                iModel.setControl(false);
                break;
            case SHIFT:
                iModel.setShift(false);
                break;
        }
    }

    enum State {READY, PREPARE_CREATE, DRAGGING, RESIZING, PREPARE_RUBBER, RUBBERBAND, TRAINING}
}
