/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

For this assignment on Multiple Selection, Undo/Redo and Cut/Copy/Paste, I implemented all the parts of the assignment
and they are all working correctly and responding correctly. In this file is attached Blob, BlobContext, BlobController,
BlobCreate, BlobCreate, BlobDelete, BlobGroup, BlobManager, BlobModel, BlobModelListener, BlobMove, BlobRecord, BlobTarget, BlobView,
Groupable, IModelListener, InteractionModel, Main, MainUI,ResizeMenu, RubberRectangle, Target Clipboard are all the files used in
completeing this assignment and I used the blobdemo in Lab 09. To run the application would need to launch the Main.java

--------------------------------

To create an item, the user would need --- to hold shift to create

To delete an item --- would need to press control and the delete key

To undo and redo an item ---- would need to press control + Z to undo and control + R to redo

To copy and paste an item --- would need to press control + C to copy and contorl + V to paste

To switch to targeting trainer --- would need to press Control + T and to switch back Control + E...

And I think those are just the major implementation made in this phase of the assignment, and thank you very much for grading my work.

