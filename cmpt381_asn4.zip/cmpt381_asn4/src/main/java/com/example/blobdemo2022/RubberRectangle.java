/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;


public class RubberRectangle {

    double width;
    double height;
    double left;
    double top;


    public RubberRectangle(double x1, double y1) {
        left = x1;
        top = y1;
        width = 0;
        height = 0;
    }

    public void updateCoords(double x2, double y2) {
        left = Math.min(left, x2);
        top = Math.min(top, y2);
        width = Math.max(left, x2) - left;
        height = Math.max(top, y2) - top;
    }
}
