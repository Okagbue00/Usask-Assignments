/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.Double.*;
import static javafx.scene.chart.XYChart.*;

public class BlobView extends StackPane implements BlobModelListener, IModelListener {
    GraphicsContext gc;
    Canvas myCanvas;
    BlobModel model;
    InteractionModel iModel;

    public BlobView() {
        myCanvas = new Canvas(800,800);
        gc = myCanvas.getGraphicsContext2D();
        this.getChildren().add(myCanvas);
    }

    public void setModel(BlobModel newModel) {
        model = newModel;
    }

    public void setIModel(InteractionModel newIModel) {
        iModel = newIModel;
    }

    @Override
    public void modelChanged() {
        draw();
    }


    private void draw() {
        switch (iModel.currentState) {
            case REPORT -> {
                this.getChildren().clear();
                this.getChildren().add(showChart());
            }
            default -> {
                this.getChildren().clear();
                this.getChildren().add(myCanvas);
                gc.clearRect(0, 0, myCanvas.getWidth(), myCanvas.getHeight());
                if (!iModel.hasRubberband()) {
                } else {
                    gc.setFill(Color.YELLOW);
                    gc.fillRect(iModel.rubber.left, iModel.rubber.top, iModel.rubber.width, iModel.rubber.height);
                }
                AtomicInteger count = new AtomicInteger(1);
                model.getBlobs().forEach(g -> drawGroup(g, iModel.isSelected(g), count.getAndIncrement()));
            }
        }
    }

    private void drawGroup(Groupable group, boolean selected, int count) {
        if (group.hasChildren()) {
            group.getChildren().forEach(child -> drawGroup(child, selected, count));
            gc.setStroke(Color.BLACK);
            gc.strokeRect(group.getLeft(), group.getTop(),
                    group.getRight() - group.getLeft(), group.getBottom() - group.getTop());
        } else {
            if (selected) {
                gc.setFill(Color.PURPLE);
            } else {
                gc.setFill(Color.LIGHTBLUE);
            }
            Blob b = (Blob) group;
            gc.fillOval(group.getLeft(), group.getTop(),
                    group.getRight() - group.getLeft(), group.getBottom() - group.getTop());
            gc.setStroke(Color.BLACK);
            gc.strokeOval(group.getLeft(), group.getTop(),
                    group.getRight() - group.getLeft(), group.getBottom() - group.getTop());
            gc.setFill(Color.BLACK);
            gc.fillText(count+"", group.getLeft()+b.r, group.getTop()+b.r);
        }
    }


    @Override
    public void iModelChanged() {
        draw();
    }

    public void setController(BlobController controller) {
        myCanvas.setOnMousePressed(event -> controller.handlePressed(event));
        myCanvas.setOnMouseDragged(event -> controller.handleDragged(event));
        myCanvas.setOnMouseReleased(event -> controller.handleReleased(event));
        myCanvas.setOnKeyPressed(event -> controller.handleKeyPressed(event));
        myCanvas.setOnKeyReleased(event -> controller.handleKeyReleased(event));
    }

    public Node showChart(){
        ArrayList<BlobRecord> trialRecords = model.trialRecords;
        int totalRec = trialRecords.size();
        double minTime = MAX_VALUE;
        double maxTime = MIN_VALUE;
        for(BlobRecord record : trialRecords){
            minTime = Math.min(minTime, record.elapsedTime);
            maxTime = Math.max(maxTime, record.elapsedTime);
        }
        Stage stage = new Stage();
        stage.setTitle("Target Trainer Demo");
        final NumberAxis xAxis = new NumberAxis(0, totalRec+1, 1);
        final NumberAxis yAxis = new NumberAxis(minTime-10, maxTime+10, 10);
        final ScatterChart<Number,Number> scatter_chart = new ScatterChart<>(xAxis,yAxis);
        xAxis.setLabel("Target IDs");
        yAxis.setLabel("Target movements");
        xAxis.setAutoRanging(true);
        scatter_chart.setTitle("Targeting Performance");

        Series series1 = new Series();
        series1.setName("Targeting Performance");
        for (BlobRecord record : trialRecords){
            series1.getData().add(new Data(record.id, record.elapsedTime));
        }
        scatter_chart.getData().addAll(series1);

        return scatter_chart;

    }
}
