/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */
package com.example.blobdemo2022;

import java.util.ArrayList;

public class BlobDelete extends BlobTarget {

    ArrayList<Groupable> groupables;
    Groupable toDelete;

    public BlobDelete(ArrayList<Groupable> groupables, Groupable toDelete) {
        this.name = "Blob Delete";
        this.groupables = groupables;
        this.toDelete = toDelete;
    }

    @Override
    public void execute() {
        groupables.remove(toDelete);
    }

    @Override
    public void undo() {
        if (groupables.contains(toDelete)){
            groupables.remove(toDelete);
        }else{
            groupables.add(toDelete);
        }
    }

    @Override
    public void redo() {
        execute();
    }

    @Override
    public BlobTarget copy() {
        return new BlobDelete(groupables, toDelete);
    }

}
