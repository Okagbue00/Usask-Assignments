/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import java.util.Stack;

public class BlobManager {

    private final Stack<BlobTarget> unadd;
    private final Stack<BlobTarget> readd;

    boolean boo;
    BlobContext bc;
    
    public BlobManager() {
        unadd = new Stack<>();
        readd = new Stack<>();
    }

    public void performCommand(BlobTarget target) {
        if (!boo) {
        } else {
            bc.addCommand(target.copy());
        }
        target.execute();
        unadd.push(target);
        readd.clear();
    }
    
    public void undo() {
        if (unadd.empty()) {
            System.out.println("Limit exceeded for undo\n");
            return;
        }
        BlobTarget c = unadd.pop();
        c.undo();
        readd.push(c);
    }
    
    public void redo() {
        if (readd.empty()) {
            System.out.println("Limit exceeded for redo\n");
            return;
        }
        BlobTarget c = readd.pop();
        c.undo();
        unadd.push(c);
    }
    
}
