/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

public class ResizeMenu extends BlobTarget {

    Blob blob;
    double crStateBeforeMove;
    double dr;


    public ResizeMenu(Blob blob, double dr) {
        this.name = "Resize";
        this.blob = blob;
        this.dr = dr;
    }

    @Override
    public BlobTarget copy() {
        return new ResizeMenu(blob, dr);
    }

    @Override
    public void undo() {
        blob.r = crStateBeforeMove;
    }

    @Override
    public void redo() {
        execute();
    }

    @Override
    public void execute() {
        this.crStateBeforeMove = blob.r;
        blob.resize(dr);
    }



}
