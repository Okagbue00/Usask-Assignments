/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */


package com.example.blobdemo2022;

import java.util.ArrayList;

public class TargetClipboard {
    static ArrayList<Groupable> cutSelection = null;
    static String Operation = null;
}
