/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import java.util.ArrayList;
import java.util.List;

public class InteractionModel {
    ArrayList<Groupable> selection;
    List<IModelListener> subscribers;
    boolean controlDown;
    boolean shiftDown;
    boolean trainer;
    Blob selected;
    RubberRectangle rubber;


    public InteractionModel() {
        subscribers = new ArrayList<>();
        selection = new ArrayList<>();
        rubber = null;
        controlDown = false;
        trainer = false;
    }

    public void addSubscriber(IModelListener sub) {
        subscribers.add(sub);
    }

    private void notifySubscribers() {
        subscribers.forEach(s -> s.iModelChanged());
    }

    public void setSelected(Blob b) {
        selected = b;
        notifySubscribers();
    }

    public void unselect() {
        selected = null;
    }

    public Blob getSelected() {
        return selected;
    }

    public void clearSelection() {
        selection.clear();
        notifySubscribers();
    }

    public void setSelection(Groupable g) {
        selection.clear();
        selection.add(g);
        notifySubscribers();
    }

    public void addSelection(Groupable g) {
        selection.add(g);
        notifySubscribers();
    }

    public ArrayList<Groupable> getAllSelected() {
        return selection;
    }

    public void removeSelection(Groupable g) {
        selection.remove(g);
        notifySubscribers();
    }

    public boolean isSelected(Groupable g) {
        return selection.contains(g);
    }

    public void createRubber(double x1, double y1) {
        rubber = new RubberRectangle(x1, y1);
    }

    public void setRubberEnd(double x2, double y2) {
        rubber.updateCoords(x2, y2);
        notifySubscribers();
    }

    public boolean hasRubberband() {
        return (rubber != null);
    }

    public void deleteRubber() {
        rubber = null;
        notifySubscribers();
    }

    public void addSubtractSelection(Groupable g) {
        if (selection.contains(g)) {
            selection.remove(g);
        } else {
            selection.add(g);
        }
        notifySubscribers();
    }

    public void addSubtractSelection(List<Groupable> set) {
        set.forEach(g -> addSubtractSelection(g));
    }

    public void setControl(boolean isDown) {
        controlDown = isDown;
        notifySubscribers();
    }

    public void setShift(boolean isDown) {
        shiftDown = isDown;
        notifySubscribers();
    }

    enum pageState {EDIT, TEST, REPORT};

    pageState currentState = pageState.EDIT;
}

