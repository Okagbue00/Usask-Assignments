/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Main extends Application {



    @Override
    public void start(Stage primaryStage) {
        StackPane root = new StackPane();

        BlobModel model = new BlobModel();
        BlobController controller = new BlobController();
        BlobView view = new BlobView();
        InteractionModel iModel = new InteractionModel();

        controller.setModel(model);
        view.setModel(model);
        controller.setIModel(iModel);
        view.setIModel(iModel);
        model.addSubscriber(view);
        iModel.addSubscriber(view);
        view.setController(controller);
        view.setOnMousePressed(event -> controller.handlePressed(event));
        view.setOnMouseDragged(event -> controller.handleDragged(event));
        view.setOnMouseReleased(event -> controller.handleReleased(event));
        view.setOnKeyPressed(event -> controller.handleKeyPressed(event));
        view.setOnKeyReleased(event -> controller.handleKeyReleased(event));
        root.getChildren().add(view);
        primaryStage.setTitle("Target Trainer Demo");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
        view.requestFocus();
    }



    public static void main(String[] args) {
        launch(args);
    }
}
