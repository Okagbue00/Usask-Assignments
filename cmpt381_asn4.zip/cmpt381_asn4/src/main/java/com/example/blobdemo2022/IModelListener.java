/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

public interface IModelListener {
    void iModelChanged();
}
