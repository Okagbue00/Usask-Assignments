/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */
package com.example.blobdemo2022;

import java.util.ArrayList;

public class BlobContext extends BlobTarget {

    ArrayList<BlobTarget> commands;
    
    public BlobContext() {
        commands = new ArrayList<>();
    }

    public void addCommand(BlobTarget c) {
        commands.add(c);
    }

    @Override
    public BlobTarget copy() {
        BlobContext comp = new BlobContext();
        commands.stream().map(BlobTarget::copy).forEachOrdered(comp::addCommand);
        return comp;
    }
    
    @Override
    public void execute() {
        commands.forEach(BlobTarget::execute);
    }

    @Override
    public void undo() {
        int i = commands.size()-1;
        while (i >= 0) {
            commands.get(i).undo();
            i--;
        }
    }

    @Override
    public void redo() {
        execute();
    }
    

}
