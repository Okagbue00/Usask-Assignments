/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

public abstract class BlobTarget {

    public String name;

    public abstract void execute();
    public abstract void undo();
    public abstract void redo();

    public abstract BlobTarget copy();
}
