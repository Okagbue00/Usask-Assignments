/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

public class BlobRecord {
    int id;
    double elapsedTime;

    public BlobRecord() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BlobRecord(int id, double elapsedTime) {
        this.id = id;
        this.elapsedTime = elapsedTime;
    }

    public double getElapsedTime() {
        return elapsedTime;
    }

    public void setElapsedTime(double elapsedTime) {
        this.elapsedTime = elapsedTime;
    }
}
