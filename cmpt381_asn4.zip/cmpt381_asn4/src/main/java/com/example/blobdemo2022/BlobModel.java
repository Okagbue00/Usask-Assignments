/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import java.util.*;

public class BlobModel {
    private final List<BlobModelListener> subscribers;
    ArrayList<Groupable> blobs;
    BlobManager blobManager;
    private ArrayList<Groupable> targetTrainerViewTempBlobs = new ArrayList<>();
    private ArrayList<Groupable> editorViewBlobs = new ArrayList<>();

    public BlobModel() {
        subscribers = new ArrayList<>();
        blobs = new ArrayList<>();
        blobManager = new BlobManager();
    }

    public void addBlob(double x, double y) {
        Blob b = new Blob(x, y);
        blobManager.performCommand(new BlobCreate(blobs,b));
        notifySubscribers();
    }

    public void undo(){
        blobManager.undo();
        notifySubscribers();
    }

    public void redo(){
        blobManager.redo();
        notifySubscribers();
    }

    public void move(List<Groupable> moveGroup, double dX, double dY) {
        moveGroup.forEach(g -> blobManager.performCommand(new BlobMove((Blob) g, dX, dY)));
        notifySubscribers();
    }

    public void addSubscriber(BlobModelListener sub) {
        subscribers.add(sub);
    }

    private void notifySubscribers() {
        subscribers.forEach(BlobModelListener::modelChanged);
    }

    public List<Groupable> getBlobs() {
        return blobs;
    }

    public boolean hitBlob(double x, double y) {
        return blobs.stream()
                .anyMatch(b -> b.contains(x, y));
    }

    public Groupable whichHit(double x, double y) {
        for (Groupable b : blobs) {
            if (b.contains(x,y)) return b;
        }
        return null;
    }

    public void resizeBlob(ArrayList<Groupable> allSelected, double dx){
        for (Iterator<Groupable> iterator = allSelected.iterator(); iterator.hasNext(); ) {
            Groupable groupable = iterator.next();
            resizeGroup(groupable, dx);
        }
        notifySubscribers();
    }

    public void resizeGroup(Groupable g, double dx){
        if (!g.hasChildren()) {
            Blob b = (Blob) g;
            blobManager.performCommand(new ResizeMenu(b, dx));
        } else {
            resizeGroup(g,dx);
        }
    }

    public void deleteSelectedBlob(ArrayList<Groupable> selectedGroups){
        for (Groupable g : selectedGroups) {
            blobManager.performCommand(new BlobDelete(blobs, g));
        }
        notifySubscribers();
    }

    public Groupable find(double x, double y) {
        boolean seen = false;
        Groupable acc = null;
        for (Groupable g : blobs) {
            if (g.contains(x, y)) {
                if (!seen) {
                    seen = true;
                    acc = g;
                } else {
                    acc = g;
                }
            }
        }
        Optional<Groupable> result = seen ? Optional.of(acc) : Optional.empty();
        return result.orElse(null);
    }

    public List<Groupable> findInRubberband(double x1, double y1, double x2, double y2) {
        List<Groupable> list = new ArrayList<>();
        for (Groupable g : blobs) {
            if (g.isContained(x1, y1, x2, y2)) {
                list.add(g);
            }
        }
        return list;
    }

    public void cutSelected(ArrayList<Groupable> selected){
        TargetClipboard.cutSelection = new ArrayList<>();
        TargetClipboard.Operation = "CUT";
        for (Groupable g : selected) {
            Blob b = (Blob)g;
            Blob bb = new Blob(b.x, b.y);
            bb.r = b.r;
            TargetClipboard.cutSelection.add(bb);
        }
        blobs.removeAll(selected);

        notifySubscribers();
    }

    public void copySelected(ArrayList<Groupable> selected){
        TargetClipboard.cutSelection = new ArrayList<>();
        TargetClipboard.Operation = "COPY";
        for (Groupable g : selected) {
            Blob b = (Blob)g;
            Blob bb = new Blob(b.x, b.y);
            bb.r = b.r;
            TargetClipboard.cutSelection.add(bb);
        }

        notifySubscribers();
    }

    public void pasteSelected(InteractionModel interactionModel){
        interactionModel.setSelection(null);
        ArrayList<Groupable> cutSelection = TargetClipboard.cutSelection;
        for (int j = 0, cutSelectionSize = cutSelection.size(); j < cutSelectionSize; j++) {
            Groupable g = cutSelection.get(j);
            Blob b = (Blob) g;
            Blob bb = new Blob(b.x, b.y);
            bb.r = b.r;
            blobs.add(bb);
            interactionModel.addSelection(bb);
        }
        if (TargetClipboard.Operation.equals("CUT")){
            TargetClipboard.cutSelection = new ArrayList<>();
        }
        notifySubscribers();
    }

    public void showTargetTrainerView() {
        trialRecords = new ArrayList<>();
        if (!blobs.isEmpty()) {
            targetTrainerViewTempBlobs = new ArrayList<>();
            targetTrainerViewTempBlobs.addAll(blobs);
            editorViewBlobs = new ArrayList<>();
            editorViewBlobs.addAll(blobs);
            blobs = new ArrayList<>();
            i=0;
            blobs.add(targetTrainerViewTempBlobs.get(i++));
            startTime = System.currentTimeMillis();
        }
    }

    public void showEditorView() {
        if (!editorViewBlobs.isEmpty()) {
            blobs = new ArrayList<>();
            blobs.addAll(editorViewBlobs);
            i = 0;
        } else {
            i = 0;
        }
    }
    int i = 0;
    public ArrayList<BlobRecord> trialRecords = new ArrayList<>();
    private long startTime = 0;

    public boolean showNextTarget() {
        long endTime = 0;
        if (targetTrainerViewTempBlobs.size() <= i) {
            endTime = System.currentTimeMillis();
            trialRecords.add(new BlobRecord(i, endTime - startTime));
            for (Iterator<BlobRecord> iterator = trialRecords.iterator(); iterator.hasNext(); ) {
                BlobRecord t = iterator.next();
                System.out.println(t.id + " - " + t.elapsedTime);
            }
            notifySubscribers();
            return false;
        } else {
            blobs.add(targetTrainerViewTempBlobs.get(i++));
            endTime = System.currentTimeMillis();
            trialRecords.add(new BlobRecord(i-1, endTime - startTime));
            startTime = endTime;
            notifySubscribers();
            return true;
        }
    }

    public void showChart(){
        notifySubscribers();
    }
}
