/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

import java.util.ArrayList;

public interface Groupable {
    
    boolean hasChildren();

    ArrayList<Groupable> getChildren();

    double getLeft();

    double getRight();

    double getTop();

    double getBottom();

    boolean contains(double x, double y);

    boolean isContained(double x1, double y1, double x2, double y2);

    void move(double dx, double dy);
}
