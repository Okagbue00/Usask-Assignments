/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */
package com.example.blobdemo2022;

import java.util.ArrayList;

public class BlobCreate extends BlobTarget {

    Blob blob;
    ArrayList<Groupable> groupables;

    public BlobCreate(ArrayList<Groupable> groupables, Blob blob) {
        this.name = "Blob Create";
        this.blob = blob;
        this.groupables = groupables;
    }

    @Override
    public void execute() {
        groupables.add(blob);
    }

    @Override
    public BlobTarget copy() {
        return new BlobCreate(groupables, blob);
    }

    @Override
    public void undo() {
        if (groupables.remove(blob)) {
            return;
        }
        groupables.add(blob);
    }

    @Override
    public void redo() {
        execute();
    }

}
