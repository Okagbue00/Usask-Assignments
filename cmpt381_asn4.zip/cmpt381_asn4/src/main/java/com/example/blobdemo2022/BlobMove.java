/*
OKAGBUE FRANCIS
CMPT 381
11279373
 */

package com.example.blobdemo2022;

public class BlobMove extends BlobTarget {

    Blob blob;
    double dx;
    double dy;
    double xx;
    double xy;

    public BlobMove(Blob blob, double dx, double dy) {
        this.name = "Blob move";
        this.blob = blob;
        this.dx = dx;
        this.dy = dy;
    }

    @Override
    public void execute() {
        this.xx = blob.x;
        this.xy = blob.y;
        blob.move(dx, dy);
    }

    @Override
    public void undo() {
        blob.x = xx;
        blob.y = xy;
    }

    @Override
    public void redo() {
        execute();
    }

    @Override
    public BlobTarget copy() {
        return new BlobMove(blob, dx, dy);
    }

}
