
const express = require("express");

const bodyParser = require("body-parser");

const mysql = require("mysql");

const  app = express();

const port = 8000;

const path = __dirname;

const host = '0.0.0.0';


app.use(bodyParser.urlencoded({extended: true}));

const mysqlFile = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: "root",
    database: 'assignment'
});



mysqlFile.connect((err) =>
{
    if (err) {
        throw err
    }
            console.log("Mysql Connected...")


});


app.get('/', (req, res)=> {
    res.sendFile('posting.html', {root: path + '/'});
});

app.post('/postMessage', (req, res) =>{

    const bodyTopic = req.body.topic;
    const bodyData = req.body.data;
    const date = new Date().toISOString().slice(0, 19).replace("T", " ");

    let insert_sql = 'INSERT INTO post(topic, data, timestamp) VALUES(?, ?, ?)'; //to insert new records inside a table

    mysqlFile.query(insert_sql, [bodyTopic, bodyData, date], (err) => {
        if (!err) {
        } else {
            throw err;
        }

    });
    res.redirect('/');
});

app.get('/post1', (req, res) =>{

    const sql = 'SELECT * FROM post ORDER BY timestamp';
    mysqlFile.query(sql, (err, result) => {
        let data_file = [];
        if(err){
            throw err
        }
        Object.keys(result).forEach((key_file) => {
            let post_row = result[key_file];
            data_file.push((post_row.topic + " " + post_row.data + " " + post_row.timestamp));
        });
        console.log(data_file);
        res.send(data_file);
    });

});


app.listen(port, host);

console.log("Server started and running on port 8000.");