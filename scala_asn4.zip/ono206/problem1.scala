//OKAGBUE ONYEKA FRANCIS
// CMPT 340
// 11279373
// MARCH 22, 2022


import akka.actor.Actor
import akka.actor.ActorRefS
import akka.actor.ActorSystem
import akka.actor.Props

import util.Random.nextInt

class SmallestValue(var number: Int) {}

class SortActor extends Actor {
    private var _smallestValue: Int = 0
    private var _childActor: ActorRef = null

    def receive = {
        // Receive sentinel 
        case 0 => {
            sender() ! new SmallestValue(_smallestValue)

            // Send to child actors to stop them
            if (_childActor != null) {
                _childActor ! 0
            }
        }

        // Receive first value
        case x: Int if _smallestValue == 0 => _smallestValue = x 

        // Receive other values
        case x: Int => {
            // Create child actor to handle not smallest number
            if (_childActor == null) {
                _childActor = context.actorOf(Props[SortActor], "ChildSorter")
            }

            if (x < _smallestValue) {
                _childActor ! _smallestValue
                _smallestValue = x
            } else {
                _childActor ! x
            }
        }

        // Receive small value from child actors
        case num: SmallestValue => {
            context.parent ! num
        }
    }
}

object Client {
    case class start()
}

class Client(l: List[Int]) extends Actor {
    import Client._ 

    def receive = {
        // Receive reply from the sort actor 
        case n : SmallestValue => println(n.number)

        // Receive list from Main to sort 
        case start() => {
            val sortActor = context.actorOf(Props[SortActor], "WorkerSorter")

            // Sort each value 
            for (n <- l) {
                sortActor ! n 
            }

            // Send the sentinel
            sortActor ! 0
        }
    }
}

object problem1 extends App {
    val system = ActorSystem("SortingSystem")

    // default Actor constructor
    val client = system.actorOf(Props(classOf[Client], List(1, 2, 4, 8 , 3 , 4, 9 ,12 ,34 , 32, 31, 10, 9, 8)))

    // Start the client
    client ! Client.start()
}