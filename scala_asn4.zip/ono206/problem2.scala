//OKAGBUE ONYEKA FRANCIS
// CMPT 340
// 11279373
// MARCH 23, 2022


import akka.actor.Actor
import akka.actor.ActorRef
import akka.actor.ActorSystem
import akka.actor.Props

// Card Collector actor
class CardCollector extends Actor {
    private var _shuffledDeck : List[Any] = Nil

    def receive = {
        case x : Int => {
            _shuffledDeck  = _shuffledDeck :+ x 
        }
        case None => {
            // Send the shuffled deck back to parent 
            context.parent ! _shuffledDeck

            // Reset 
            _shuffledDeck = Nil 
        }
    }
}

// Performs the FaroShuffle 
class FaroShuffler extends Actor {
    private var _stacks : List[Any] = Nil
    private var _shuffleType : Option[Boolean] = None 
    private var _cardCollectorActor : Option[ActorRef] = None 

    def shuffle[A](l1: List[A], l2: List[A]): List[A] = (l1, l2) match {
        case (x1 :: sub_l1, x2 :: sub_l2) =>
            x1 :: x2 :: shuffle(sub_l1, sub_l2) // Return element in l1 before l2
        case (l1, Nil) => l1 // If l2 is empty, return l1
        case (Nil, l2) => l2 // If l1 is empty, return l2
    }

    def perform = (_stacks, _shuffleType, _cardCollectorActor) match {
        case ((stack2: List[Any]) :: (stack1: List[Any]) :: Nil, Some(b : Boolean), Some(cA : ActorRef)) => {
            // Perform the faro shuffle 
            val shuffledDeck = b match {
                case true => shuffle(stack1, stack2)
                case false => shuffle(stack2, stack1)
            } 

            // Send to card collector actor 
            for (x <- shuffledDeck) {
                cA ! x
            }

            // Send None 
            cA ! None 

            // Reset 
            _stacks = Nil 
            _shuffleType = None
        } 
        case _ => {}
    }

    def receive = {
        case stack: List[Any] => {
            _stacks = stack :: _stacks  
            perform
        }
        case shuffleType: Boolean => {
            _shuffleType = Some(shuffleType) 
            perform
        }
        case cardCollector: ActorRef => {
            _cardCollectorActor = Some(cardCollector)
            perform
        }
    }
}

// Splits the two decks evenly and sends them to the FaroShuffle actor, one at a time
class Splitter() extends Actor {
    // Split the deck into two lists by extracting the first and last elements
    def split[A] (l : List[A]) : (List[A], List[A]) = l match {
        case first :: (middle :+ last) => split(middle) match {
            case (left, right) => (first :: left, right :+ last)
        }
        case l => (l, Nil)
    }

    // Process messages 
    def receive = {
        case (l: List[Any], fs: ActorRef) => {
            // Split the deck into sub stacks 
            val (subStack1, subStack2) = split(l)

            // Send to FaroShuffle 
            fs ! subStack1 
            fs ! subStack2
        }
    }
}

// Shuffler message
class ShuffleMessage(
    val deck: List[Any], 
    val numberOfShuffles: Int, 
    val outShuffle: Boolean
)

// Shuffler 
class Shuffler extends Actor {
    val faroShuffler = context.actorOf(Props[FaroShuffler])
    val splitterActor = context.actorOf(Props[Splitter])
    val cardCollectorActor = context.actorOf(Props[CardCollector])
    var shuffleMessages : List[(ActorRef, ShuffleMessage)] = Nil 

    def perform(msg: ShuffleMessage) = {
        // Send the type of shuffle 
        faroShuffler ! msg.outShuffle

        // Send card collector 
        faroShuffler ! cardCollectorActor

        // Send the deck to splitter 
        splitterActor ! (msg.deck, faroShuffler)
    }

    def receive = {
        case msg: ShuffleMessage => {
            // Add to queue 
            shuffleMessages = shuffleMessages :+ (sender(), msg) 

            // Start the shuffle if its the only one in the queue
            shuffleMessages match {
                case (s, m) :: Nil => perform(m)
                case _ => {}
            }
        }
        case shuffled: List[Any] => {
            shuffleMessages match {
                case (s, msg) :: queue => msg.numberOfShuffles match {
                    case n if n > 1 => {
                        val updatedShuffleMessage = new ShuffleMessage(shuffled, n - 1, msg.outShuffle)

                        // Re-insert to the queue
                        shuffleMessages = (s, updatedShuffleMessage) :: queue

                        // Perform 
                        perform(updatedShuffleMessage)
                    }
                    case _ => {
                        // Shuffling complete
                        // Send back to original sender
                        s ! shuffled

                        // Update list of shuffle messages
                        shuffleMessages = queue

                        // Perform other messages in queue
                        shuffleMessages match {
                            case (s, msg) :: queue => {
                                perform(msg)
                            }
                            case _ => {}
                        }
                    }
                }
                case _ => {}
            }
        }
    }
}

// Shuffler client 
object Client {
    case class start()
}

class Client(msg: ShuffleMessage) extends Actor {
    import Client._
    val shuffler = context.actorOf(Props[Shuffler])

    def receive = {
        case start() => {
            shuffler ! msg 
        }
        
        case shuffled: List[Any] => {
            println(shuffled)
        }
    }
}

object problem2 extends App {
    val system = ActorSystem("FaroShuffleSystem")

    // default Actor constructor
    val client = system.actorOf(Props(classOf[Client],  new ShuffleMessage(List(1, 2, 3, 4, 5, 6, 7, 8), 1, true)))

    // Send the shuffle message
    client ! Client.start()
}