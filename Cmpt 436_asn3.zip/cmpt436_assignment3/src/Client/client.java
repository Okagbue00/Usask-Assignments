package Client;

import Server.serverInterface;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


class client {

    clientHandler clientHandler;
    GraphicalInterfaceView client_view;
    serverInterface server;

    public client() throws RemoteException, NotBoundException {
        Registry reg = LocateRegistry.getRegistry(8080);
        server = (serverInterface) reg.lookup("ServerClientChattool");

        clientHandler = new clientHandler(this);
        client_view = new GraphicalInterfaceView(this);
        client_view.show();
        server.assignServer(clientHandler);
    }

    public static void main(String[] args) throws RemoteException, NotBoundException {
        new client();
    }

    public void displayMessage(String message) throws RemoteException {
        client_view.display(message);

    }

    public void assignFriends(String message) throws RemoteException {
        server.alertFriends(message);
    }

    public void remove() throws RemoteException {
        server.remove(clientHandler);
    }


}
