package Client;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;

import static java.util.logging.Logger.*;

public class GraphicalInterfaceView extends JFrame  implements ClientMessage {

    private JButton button_client;
    private JTextArea text_client;
    private JTextField text_server;
    private JTextField text_username;
    client client;
    String user_name;

    public GraphicalInterfaceView(client client) {
        initComponents();
        this.client = client;
    }

    private void initComponents() {

        JScrollPane panel = new JScrollPane();
        text_client = new JTextArea();
        text_server = new JTextField();
        button_client = new JButton();
        JLabel label = new JLabel();
        text_username = new JTextField();
        JButton btnSet = new JButton();


        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chat-Tool-Box");
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent event) {
                formWindowClosing(event);
            }
        });

        text_client.setEditable(false);
        text_client.setColumns(20);
        text_client.setRows(5);
        panel.setViewportView(text_client);

        text_server.setEditable(false);
        text_server.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        button_client.setText("Send message");
        button_client.setEnabled(false);

        button_client.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });

        label.setText("Client-name");

        text_username.setName("tb_name"); // NOI18N

        btnSet.setText("Add");

        btnSet.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evt) {
                btnSetActionPerformed(evt);
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createSequentialGroup()

                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(label)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                        .addGap(125, 125, 125)
                                                        .addComponent(btnSet))
                                                .addComponent(text_username, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)))
                                .addComponent(panel, GroupLayout.PREFERRED_SIZE, 371, GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(text_server, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(button_client, GroupLayout.PREFERRED_SIZE, 74, GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(14, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING))
        );
        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addComponent(label))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(btnSet))
                                .addGroup(layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(text_username, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panel, GroupLayout.PREFERRED_SIZE, 248, GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(button_client, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
                                .addComponent(text_server, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE))
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING))
        );

        pack();
    }

    public void display(String message) {

        if(!(text_client.getText()).equals(""))
            text_client.append("\n"+ message);
        else
            text_client.append(message);
    }


    private void btnSendActionPerformed(ActionEvent event) {
        try {
            client.assignFriends(user_name +": "+ text_server.getText());
            text_server.setText("");
        } catch (RemoteException exception) {
            getLogger(GraphicalInterfaceView.class.getName()).log(Level.SEVERE, null, exception);
        }

    }

    private void btnSetActionPerformed(ActionEvent event) {

        user_name = text_username.getText();
        if (!user_name.equals("")) {
            try {
                client.assignFriends(user_name +": is Connected");
                text_server.setEditable(true);
                button_client.setEnabled(true);
            } catch (RemoteException ex) {
                getLogger(GraphicalInterfaceView.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void formWindowClosing(WindowEvent event) {
        try {
            client.remove();
        } catch (RemoteException exception) {
            getLogger(GraphicalInterfaceView.class.getName()).log(Level.SEVERE, null, exception);
        }
    }
    
    
    
}
