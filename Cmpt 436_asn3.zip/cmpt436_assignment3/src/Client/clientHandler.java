package Client;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import static java.util.logging.Level.SEVERE;
import static java.util.logging.Logger.*;

class clientHandler extends UnicastRemoteObject implements ClientInterface {

    client client;

    public clientHandler(client client) throws RemoteException {
        this.client = client;
    }

    public void receive(String message) {
        try {
            client.displayMessage(message);
        }
        catch (RemoteException remoteException) {
            getLogger(client.class.getName()).log(SEVERE, null, remoteException);
        }
    }
}

