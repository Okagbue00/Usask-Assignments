package Client;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ClientMessage extends Remote {

    void display(String message) throws RemoteException;
}
