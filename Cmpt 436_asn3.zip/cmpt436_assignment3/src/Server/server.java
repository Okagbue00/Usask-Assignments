package Server;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class server {

    public static void main(String[] args) {
        new server();
    }

    public server() {
        try {
             serverHandler server_handler = new serverHandler();
            Registry remote_registry = LocateRegistry.createRegistry(8080);
            remote_registry.rebind("ServerClientChattool", server_handler);
            System.out.println("Server is up and running...");

        }
        catch (RemoteException e)
        {
            e.printStackTrace();
        }
    }




}



