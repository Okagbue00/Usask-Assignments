package Server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import Client.ClientInterface;

public interface serverInterface extends Remote {

    public  void alertFriends(String msg) throws RemoteException;

    public  void assignServer(ClientInterface client_inter) throws RemoteException;

    public  void remove(ClientInterface client_inter) throws RemoteException;




}


