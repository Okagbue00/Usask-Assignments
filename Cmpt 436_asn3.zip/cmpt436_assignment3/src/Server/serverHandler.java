package Server;

import Client.ClientInterface;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class serverHandler extends UnicastRemoteObject implements serverInterface {

    ArrayList<ClientInterface> cl = new ArrayList<>();

    public serverHandler() throws RemoteException {
    }

    public void assignServer(ClientInterface client_interface) throws RemoteException{
        cl.add(client_interface);

    }


    public void remove(ClientInterface client_interface) {
        cl.remove(client_interface);
        System.out.println("Delete client!");
    }

    public void alertFriends(String msg) {
        for (int i = 0; i < cl.size(); i++) {
            ClientInterface client = cl.get(i);
            try {
                client.receive(msg);
            } catch (RemoteException remoteException) {
                System.out.println("Failed to alert other clients");
                remoteException.printStackTrace();
            }
        }
    }


}
