import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class clientHandler implements Runnable{

    public static ArrayList<clientHandler> cl = new ArrayList<>();

    private Socket sockets;
    private BufferedReader br;
    private BufferedWriter bw;
    private String client_name;

    public clientHandler (Socket sockets)
    {
        try
        {
            this.sockets = sockets;
            this.bw = new BufferedWriter(new OutputStreamWriter(sockets.getOutputStream())); //is a char stream and byte stream. will be sending characters
            this.br = new BufferedReader(new InputStreamReader(sockets.getInputStream()));
            this.client_name = br.readLine(); //sends to the client name
            cl.add(this); //it takes in the client handler
            displayMessage("Server" + " " + client_name + " has joined the chat rooms...");


        }

        catch (IOException e)
        {
            terminate(sockets, br, bw);
        }
    }

    @Override
    public void run() {

        String client_message;

        while (sockets.isConnected()){

            try
            {
                client_message = br.readLine(); //is a blocking operation and suppose to be run on a separate thread
                displayMessage(client_message);

            }

            catch (IOException e)
            {
                terminate(sockets, br, bw);
                break; //would break from the loop as soon as the client disconnects..
            }
        }

    }

    public void displayMessage(String message)
    {
        for (clientHandler clr : cl)
        {
            try
            {
                if (!clr.client_name.equals(client_name))
                {
                    clr.bw.write(message);

                    clr.bw.newLine(); //it symbolizes it is done sending data and nothing more to do again..
                    clr.bw.flush();
                }
            }

            catch (IOException exception)
            {
                terminate(sockets, br, bw);
            }
        }
    }

    public void leaveRoom()
    {
        cl.remove(this); //it clears the users from the room chat box..
        System.out.println("Server:" + client_name + "has left the chat room...");

    }

    public void terminate(Socket sockets, BufferedReader br, BufferedWriter bw)
    {
        leaveRoom();

        try
        {
            if (br != null)
            {
                br.close();
            }

            if (bw != null)
            {
                bw.close();
            }

            if (sockets != null)
            {
                sockets.close();
            }
        }

        catch (IOException exception)
        {
            exception.printStackTrace();
        }
    }
}
