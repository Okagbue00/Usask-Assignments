import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class server{

    private final ServerSocket ss;
    private static final int portNumber = 8080;

    public server(ServerSocket ss)
    {
        this.ss = ss;

    }
    public void startServer()
    {
        try{

            while(!ss.isClosed()) //would check for when the server socket is currently open and would then accept
            {
               Socket sockets = ss.accept(); //it would hold until the client connects

                System.out.println("A new Chat room has been created where client would connect to each other");

                clientHandler cl = new clientHandler(sockets);
                Thread tr = new Thread(cl);
                tr.start();
            }
        }

        catch (Exception ignored)
        {

        }
    }


    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(portNumber);
        server server = new server(ss);
        server.startServer();
    }
}