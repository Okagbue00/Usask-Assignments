import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class client {

    private Socket sockets;
    private BufferedWriter bw;
    private BufferedReader br;
    private String client_user_name;
    private static final int portNumber = 8080;


    public client(Socket sockets, String client_user_name) {
        try {
            this.sockets = sockets;
            this.bw = new BufferedWriter(new OutputStreamWriter(sockets.getOutputStream()));
            this.br = new BufferedReader(new InputStreamReader(sockets.getInputStream()));
            this.client_user_name = client_user_name;

        } catch (IOException exception) {
            terminate(sockets, br, bw);
        }
    }

    public void sendMessages() {
        try {
            bw.write(client_user_name);
            bw.newLine();
            bw.flush();

            Scanner scanner = new Scanner(System.in);
            while (sockets.isConnected())
            {
                String chat_message = scanner.nextLine();
                bw.write(client_user_name + ":-" + chat_message);
                bw.newLine();
                bw.flush();
            }
        }
        catch (IOException exception)
        {
            terminate(sockets, br, bw);
        }

    }

    public void clientMessage()
    {
        new Thread(() -> {
            String chatRoom;
            while (sockets.isConnected())
            {
                try
                {
                    chatRoom = br.readLine();
                    System.out.println(chatRoom);
                }
                catch (IOException exception)
                {
                    terminate(sockets, br, bw);
                }
            }
        }).start();
    }

    public void terminate(Socket sockets, BufferedReader br, BufferedWriter bw)
    {
        try
        {
            if (br != null)
            {
                br.close();
            }

            if (bw != null)
            {
                bw.close();
            }

            if (sockets != null)
            {
                sockets.close();
            }
        }

        catch (IOException exception)
        {
            exception.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your chat room username: ");
        String client_username = scanner.nextLine();
        Socket sockets = new Socket("localhost", portNumber);
        client client = new client(sockets, client_username);
        client.clientMessage();
        client.sendMessages();
    }
}


