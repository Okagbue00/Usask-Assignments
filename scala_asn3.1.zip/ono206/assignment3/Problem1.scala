//OKAGBUE ONYEKA FRANCIS
// CMPT 340
//ASSIGNMENT 3.1
//MARCH 3RD 2023
//PROBLEM 1
// ONO206
//11279373

package cmpt340.ono206.assignment3

object Problem1 extends App {

  val royalParent = Map("George" -> ("m", "William", "Catherine"), "Charlotte" -> ("f", "William", "Catherine"), "Louis" -> ("m", "William", "Catherine"), "Archie" -> ("m", "Harry", "Meghan"), "Lilibet" -> ("f", "Harry", "Meghan"), "Savannah" -> ("f", "Autumn", "Peter"), "Isla" -> ("f", "Autumn", "Peter"), "Mia" -> ("f", "Zara", "Mike"), "Lena" -> ("f", "Zara", "Mike"), "Lucas" -> ("m", "Zara", "Mike"), "Sienna" -> ("f", "Beatrice", "Edoardo"), "August" -> ("m", "Eugenie", "Jack"), "Beatrice" -> ("f", "Andrew", "Sarah"), "Eugenie" -> ("f", "Andrew", "Sarah"), "Louise" -> ("f", "Edward", "Sophie"), "James" -> ("m", "Edward", "Sophie"), "Peter" -> ("m", "Mark", "Anne"), "Zara" -> ("f", "Mark", "Anne"), "William" -> ("m", "Diana", "Charles"), "Harry" -> ("m", "Diana", "Charles"), "Charles" -> ("m", "Elizabeth", "Philip"), "Anne" -> ("f", "Elizabeth", "Philip"), "Andrew" -> ("m", "Elizabeth", "Philip"), "Edward" -> ("m", "Elizabeth", "Philip"), "Elizabeth" -> ("f", "", ""), "Philip" -> ("m", "", ""), "Diana" -> ("f", "", ""), "Mark" -> ("m", "", ""), "Sophie" -> ("f", "", ""), "Sarah" -> ("f", "", ""), "Mike" -> ("m", "", ""), "Autumn" -> ("f", "", ""), "Meghan" -> ("f", "", ""), "Catherine" -> ("f", "", ""), "Timothy" -> ("m", "", ""), "Jack" -> ("m", "", ""), "Camilla" -> ("f", "", ""), "Edoardo" -> ("m", "", ""))

  def children(parent1: String, parent2: String): Option[List[String]] = {
    // (a.) This children function takes two strings as parameters
    // that represents the names of two parents and it then returns
    // a list of list of strings that represents the name of their children

    val childFilter1 = royalParent.filter(m => parent2 == m._2._3 && parent1 == m._2._2).keys // it filter the map to get children with parent2 as mother and parent1 as father
    val childFilter2 = royalParent.filter(m => parent1 == m._2._3 && parent2 == m._2._2).keys // it filter the map to get children with parent2 as father and parent1 as mother

    // it returns None if there are no children
    if (!(childFilter2.nonEmpty || childFilter1.nonEmpty)) {
      None
    }
    //or it would combine the both children filter into one list
    else {
      val childList = (childFilter1++childFilter2).toList
      Some(childList)
    }

  }

  def grandparents(p: String): Option[List[String]] = {
    // (b.) This grandparents function takes a string as a parameter that represents the name of the person
    // and then adds a list of strings that represents their grandparents name

    //it checks whether the person exists in the royal parent map
    if (!(royalParent contains p) || royalParent(p)._2.==("")) {
      None
    }
    else {
      //it gets the name of the four grandparents from the royalParent map
      val grandpa1 = royalParent(royalParent(p)._2)._2
      val grandpa2 = royalParent(royalParent(p)._3)._2
      val grandpa3 = royalParent(royalParent(p)._2)._3
      val grandpa4 = royalParent(royalParent(p)._3)._3

      //it would filter any empty string and would create a list of the grandparents name
      val grandparentList = List(grandpa1, grandpa3, grandpa2, grandpa4).filter(_ != "")

      Some(grandparentList)
    }
  }

  def sisters(p: String): Option[List[String]] = {
    // (c.) This sisters function takes a string as a parameter that represents the name of the person
    // and then calls the children function to get a list of the person siblings and then filters the list
    // to only include siblings whose gender is female

    // it checks to see if the person exists in the royal parent map
    if (!(royalParent contains p) || royalParent(p)._2.==("")) {
      None
    }
    else {
      // it then gets the siblings of the person, and filter to only include siblings who are female
      children(royalParent(p)._2, royalParent(p)._3).map(_.filter(_ != p).filter(royalParent(_)._1 == "f"))
    }

  }

  def firstCousins(p: String): Option[List[String]] = {
    // (d.) This firstCousins function takes a string as a parameter that represents the name of the person
    //  and then returns a list of strings that represents the name of the first Cousins

    //it checks whether the person exists in the royal parent map
    if (!(royalParent contains p) || royalParent(p)._2.==("")) {
      None
    }
    else {
      //it would return list of all first cousins using the filter operation wrapped in Some
      val cousins = royalParent.keys.filter { x =>
        (grandparents(x), grandparents(p)) match {
          case (Some(gp1), Some(gp2)) if gp1 == gp2 => royalParent(x)._2 != royalParent(p)._2
          case _ => false
        }

      }.toList
      Some(cousins)

    }
  }

  def uncles(p: String): Option[List[String]] = //both uncles who are brothers of a parent, and parent's sisters' spouses
  {
    //(e.) This uncles function takes a string as a parameter that represents the name of the person
    // and then returns a list of strings that represents the name of the uncles

    //it checks whether the person exists in the royal parent map
    if (!(royalParent contains p) || royalParent(p)._2.==("")){
      None
    }

    else {
      //it would return a list of uncles who are brothers of a parent or parent sister spouses
      firstCousins(royalParent(p)._2).map(_.filter(_ != p).filter(royalParent(_)._1 == "m"))

    }
  }

  //testing code

  println("--------------Testing For Children-----------------")


  // Testing for children
  println(children("William", "Catherine"))
  println(children("Diana","Charles"))
  val childrenTest3 = children("Mark", "Anne")
  println(s"Mark and Anne childrens:  $childrenTest3")

  println("--------------Testing For GrandParents-----------------")


  //Testing for grandparents

  //Test 1 for grandparents
  val grandparentsTesting1 = grandparents("William")
  println(s"William grandparents: $grandparentsTesting1")

  //Test 2 for grandparents (John does not exist in the royal parent map)
  val grandparentsTesting2 = grandparents("John")
  println(s"John's grandparents (Does not exist on the Royal parent Map): $grandparentsTesting2")

  println(grandparents("George"))


  println("--------------Testing For Sisters-----------------")

  val sistersTesting1 = sisters("Archie")
  println(s"Archie Sister : $sistersTesting1")

  println(sisters("Fredlin")) //does not exist in the royal Parent map

  println(sisters("Savannah"))

  println("--------------Testing For First Cousins-----------------")

  println(firstCousins("Harry"))

  val firstCousinsTesting1 = firstCousins("Archie")
  println(s"Archie First Cousins : $firstCousinsTesting1")

  println(firstCousins("Francis")) //does not exist on the Royal Parent Map

  println("--------------Testing For Uncles-----------------")

  println(uncles("Francis")) //does not exist on the Royal Parent Map

  val unclesTesting1 = uncles("Archie")
  println(s"Archie uncles: $unclesTesting1")

  val unclesTesting2 = uncles("August")
  println(s"August uncles: $unclesTesting2")

}

