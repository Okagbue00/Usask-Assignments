//OKAGBUE ONYEKA FRANCIS
// CMPT 340
//ASSIGNMENT 3.1
//MARCH 3RD 2023
//PROBLEM 2
// ONO206
//11279373


package cmpt340.ono206.assignment3

import scala.annotation.tailrec
import scala.util.hashing.Hashing.Default

object Problem2 extends App {

  trait Partial[+A, +B] {

    //(a.) Map

    def map[C](f: B => C): Partial[A, C] = this match {

      case Success(suc) => Success(f(suc))
      case Errors(err) => Errors(err)
    }

    //(b.) FlatMap

    def flatMap[CC >: A, C](f: B => Partial[CC, C]): Partial[CC, C] = this match {
      case Success(suc) => f(suc)
      case Errors(err) => Errors(err)
    }

    //(c.) getOrElse

    def getOrElse[C >: B](as: => C): C = this match {
      case Success(suc) => suc
      case Errors(_) => as

    }

    //(d.) orElse

    def orElse[CC >: A, C >: B](as: => Partial[CC, C]): Partial[CC, C] = this match {
      case Success(suc) => Success(suc)
      case Errors(_) => as
    }

    //(e.) map2

    def map2[CC >: A, C, D1](c: Partial[CC, C])(f: (B, C) => D1): Partial[CC, D1] = this match {

      case Success(suc) => c match {
        case Success(ces) => Success(f(suc, ces))
        case Errors(err) => Errors(err)
      }

      case Errors(err) => c match {
        case Success(suc) => Errors(err)
        case Errors(or) => Errors(err ++ or)
        case _ => Errors(err)
      }

    }


  }

  case class Errors[+A](get: Seq[A]) extends Partial[A, Nothing]

  case class Success[+B](get: B) extends Partial[Nothing, B]

  object Partial {

    //(f.) traverse

    def traverse[A, B, C](xy: List[B])(f: B => Partial[C, A]): Partial[C, List[A]] = {
      @tailrec
      def loop(xx: List[B], res: Partial[C, List[A]]): Partial[C, List[A]] = xx match {
        case Nil => res.map(_.reverse)
        case x :: rest =>
          f(x) match {
            case Errors(errors) =>
              res match {
                case Errors(resErrors) => Errors(errors ++ resErrors)
                case Success(_) => Errors(errors)
              }
            case Success(a) =>
              res match {
                case Errors(errors) => Errors(errors)
                case Success(as) => loop(rest, Success(a :: as))
              }
          }
      }

      loop(xy, Success(Nil))
    }

  }


  //(g.) Try Function

  def Try[A](aa: => A): Partial[Throwable, A] = {
    try {
      Success(aa)
    }
    catch {
      case exception: Throwable => Errors(Seq(exception))
    }
  }

  // Testing for Map

  println("---------------Testing for Map----------------")
  val test1: Partial[Int, Int] = Success(1)
  if (test1.map(_ + 5) == Success(6)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test2: Partial[Int, Int] = Success(10)
  if (test2.map(_ + 10) == Success(15)) {
    println("Success")
  }
  else {
    println("(Should be error because is suppose to be 20 rather than 15) Error")
  }

  val test3: Partial[Int, Int] = Success(100)
  if (test3.map(_ + 100) == Success(200)) {
    println("Success")
  }
  else {
    println("Error")
  }

  // Testing for FlatMap
  println("---------------Testing for FlatMap----------------")

  val test4: Partial[Int, Int] = Success(100)
  if (test4.flatMap(_ => test4.map(_ + 100)) == Success(200)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test5: Partial[Int, Int] = Success(5)
  if (test5.flatMap(_ => test5.map(_ + 5)) == Success(10)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test6: Partial[Int, Int] = Success(10)
  if (test6.flatMap(_ => test6.map(_ + 5)) == Success(10)) {
    println("Success")
  }
  else {
    println("Should be error because is suppose to be 15 rather than 10 Error")
  }

  //Testing for getOrElse

  println("---------------Testing for getOrElse----------------")

  val test10: Partial[Int, Int] = Success(10)
  if (test10.orElse(test10.map(_ + 5)) == Success(10)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test11: Partial[Int, Int] = Success(25)
  if (test11.orElse(test11.map(_ + 5)) == Success(25)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test12: Partial[Int, Int] = Success(7)
  if (test12.orElse(test12.map(_ + 3)) == Success(10)) {
    println("Success")
  }
  else {
    println("Should display error -- suppose to be 7 and not 10 Error")
  }


  //Testing for OrElse

  println("---------------Testing for OrElse----------------")

  val test7: Partial[Int, Int] = Success(10)
  if (test7.orElse(test7.map(_ + 5)) == Success(10)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test8: Partial[Int, Int] = Success(100)
  if (test8.orElse(test7.map(_ + 20)) == Success(100)) {
    println("Success")
  }
  else {
    println("Error")
  }

  val test9: Partial[Int, Int] = Success(15)
  if (test9.orElse(test7.map(_ + 1)) == Success(16)) {
    println("Success")
  }
  else {
    println("Should display error--suppose to be 15 and not 16 Error")
  }

  // Testing for map2

  println("---------------Testing for map2----------------")

  val test13: Partial[String, Int] = Success(10)
  val test14: Partial[String, Int] = Success(10)

  val test15: Partial[String, Double] = test13.map2(test14)(_ + _)

  test15 match {
    case Success(value) => println(s"Success(the value is): $value")
    case Errors(errors) => println(s"Errors: $errors")
  }

  val test16: Partial[String, Int] = Success(5)
  val test17: Partial[String, Int] = Success(3)

  val test18: Partial[String, Int] = test16.map2(test17)(_ * _)

  test18 match {
    case Success(value) => println(s"Success(the value is): $value")
    case Errors(errors) => println(s"Errors: $errors")
  }

  println("---------------Testing for Try----------------")

  val test19 = Try(14 / 2)
  assert(test19 == Success(7))

  val test20 = Try(10 - 1)
  println(s"Success(the value is): $test20")


  println("---------------Testing for traverse----------------")

  val listTest = List("1", "2", "3", "4")
  def myFunction(xx: String): Partial[Throwable, Int] = Try(xx.toInt)
  val test21 = Partial.traverse(listTest)(myFunction)

  if (test21 == Success(List(1, 2, 3, 4))) {
    println("Success")
  } else {
    println("Error")
  }

}
