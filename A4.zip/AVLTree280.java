package lib280.tree;

import lib280.base.Dispenser280;
import lib280.dictionary.Dict280;
import lib280.exception.ContainerFull280Exception;
import lib280.exception.DuplicateItems280Exception;
import lib280.exception.NoCurrentItem280Exception;

import java.util.Comparator;
import java.util.DuplicateFormatFlagsException;


public class AVLTree280<I extends Comparable<? super I>> extends ArrayedBinaryTree280<I> {

    protected ArrayedBinaryTree280<I> check;
    protected ArrayedBinaryTree280<I> parent;

    public int findRightHeight;
    public int findLeftHeight;

    protected boolean searchesRestart;
    protected boolean search_case = false;
    protected boolean compare_membership = false;

    protected AVLTree280<I> left_node;
    protected AVLTree280<I> right_node;


    public final int height = 0;
    public Object left = null;
    public Object right = null;
    public AVLTree280<I> root_node;

    public AVLTree280<I> left_node(){
        return left_node;
    }
    public AVLTree280<I> right_node(){
        return right_node;
    }

    public AVLTree280<I> root_left;
    public AVLTree280<I> root_right;





    /**
     * Constructor.
     *
     * @param cap Maximum number of elements that can be in the lib280.tree.
     */
    public AVLTree280(int cap) {
        super(cap);
        searchesRestart = true;


    }



    /**	Construct an empty list.
     Analysis: Time = O(1) */
    public AVLTree280()
    {
        super();
    }

    protected AVLTree280<I> createNewNode(I item) {


        AVLTree280<I> avl_tree; //avl_tree is my created avl node
        avl_tree = new AVLTree280<I>((Integer) item); //my new node
        return avl_tree; //returned a new node of my avl tree
    }

    /**
     * Insert x into the data structure.
     *
     * @param x item to be inserted into the data structure
     * @throws ContainerFull280Exception  if the avl tree is already full.
     * @throws DuplicateItems280Exception if the avl tree already contains x.
     * @precond !isFull() and !has(x)
     */

    public void insert(I x) throws ContainerFull280Exception, DuplicateItems280Exception{

        I item_heap = null;

        if (isFull()) throw new ContainerFull280Exception("avl tree is full"); //check if the heap is full

        for (int y = 1; y <= count; ++y) {

            if (items[y] == item_heap) //checks if y items is empty
                throw new DuplicateItems280Exception("Already contains item x"); //check if the item already contain x item
        }

        AVLTree280<I> node = this.root_node; //create new avl tree
        if (x.compareTo(node.item()) <= 0) { //compare the item in the tree to zero

            if (node.left_node == null) { //check if the left node is empty
                node.setLeft(new AVLTree280<I>((Integer) x)); //set the node to be the left

            }
        }
    }

    /**
     * restores the avl property after insertion
     * @param parent parent of the tree node
     */
    protected void AVLProperty(AVLTree280<I> parent){
        int balance = imbalance(root_node());
        if (balance == 1) {
            if (imbalance(root_node().left_node()) >= 0) {
                rightRotation(parent);
            } else {
                doubleRightRotation(parent);

            }
        }

        else {
            if (imbalance(root_node().right_node()) <= 0){
                leftRotation(parent);

            }
            else {
                doubleLeftRotation(parent);
            }
        }
    }

    /**
     * double rotates the tree to the left
     * @param parent parent of the tree node
     */
    private void doubleLeftRotation(AVLTree280<I> parent) {
        if (parent == null){ //check if the parent is empty
            return;
        }
        root_right.rightRotation(root_node);
        leftRotation(parent);

    }


    /**
     * double rotates the tree to the right
     * @param parent parent of the tree node
     */
    private void doubleRightRotation(AVLTree280<I> parent) {
        if (parent == null){ //check if the parent is empty
            return;
        }
        root_left.leftRotation(root_node); //then rotate the root of the left node
        rightRotation(parent);

    }

    private AVLTree280<I> root_node() {
        return root_node; //return the avl root node
    }


    /**
     *sets the left child of the node
     * @param node the node new child
     */
    public void setLeft(AVLTree280<I> node){
        left_node = node;  //sets the node to the left

    }

    /**
     *sets the right child of the node
     * @param node the node new child
     */
    public void setRight(AVLTree280<I> node){
        right_node = node; //sets the node to the right
    }





    /**
     * Delete current item from the data structure.
     *
     * @throws NoCurrentItem280Exception if the cursor is not currently positioned at a valid item.
     * @precond itemExists()
     */
    public void deleteItem(AVLTree280<I> item, int x) throws NoCurrentItem280Exception {

        if (!itemExists())
            throw new NoCurrentItem280Exception("cursor not correctly positioned in the item");

        if (isEmpty())
            throw new NoCurrentItem280Exception("empty tree in the dict");

        if (item == null){
            return;
        }




    }

    /**
     * It does a left rotation at the root of the tree
     * @param parent is the parent of the node
     */
    public void leftRotation(AVLTree280<I> parent){
        //TODO
    }

    /**
     * It does a right rotation at the root of the tree
     * @param parent is the parent of the node
     */
    public void rightRotation(AVLTree280<I> parent){
        //TODO
    }



    /**
     * A method that determines whether two elements of type I
     * 	 * are equal.
     * 	 x to be compared to y
     * 	 y to be compared to x
     */
    public boolean membershipEquals(I x, I y) {

        if (compare_membership)
            return x == y;
        else if (x ==y)
            return true;
        else
        return false;
    }




    /**
     * check the position of the tree in big notation
     */
    public boolean position() {
        return check == null; //when is under the subtree
    }

    /**
     * to check the position of the tree in big O notation
     */
    public boolean before() {
        return parent == null; //when is on top of the tree
    }

    public void search(){

        if (search_case || before()){
            parent = null;
            check = root_node;
        }
        if (!position()){
            parent = check;

        }

    }

    /**
     * Get the item at the cursor.
     *
     * @return The item at the cursor.
     * @throws NoCurrentItem280Exception if the cursor is not positioned at an item.
     * @precond The lib280.tree must not be empty.  The cursor position must be valid.
     */
    public I item() throws NoCurrentItem280Exception {

        if (!itemExists()) throw new NoCurrentItem280Exception();
        else return items[currentNode];
    }

    /**check for the imbalance of the tree*/
    public int imbalance(AVLTree280<I> I) { //checks if the tree is balance
        if (I == null) {
            return 0;
        } else {
            return I.findRightHeight - I.findLeftHeight; //check the left and right height
        }
    }


    /**
     * Determines if an item exists.
     *
     * @return true if there is an item at the cursor, false otherwise.
     */
    public boolean itemExists() {
        return count > 0 && (currentNode > 0 && currentNode <= count);
    }

    /**
     * Is going empty the lib280.tree
     * <p>
     * Remove all elements from the lib280.tree.
     */
    public void clear() { //empties the tree of the item in the tree
        count = 0;
        currentNode = 0;


    }





    /**
     * Returns a shallow clone of the lib280.tree. The new lib280.tree contains
     * copies of item references, not new items.
     *
     * @return A reference to the new copy.
     */
    @SuppressWarnings("unchecked")
    public ArrayedBinaryTree280<I> clone() {
        return super.clone();
    }

    public boolean isEmpty() {
        return count == 0 && currentNode == 0;}

    public boolean isFull() {
        return count == capacity;
    }
















        /**Testing for AVL Tree*/

    public static void main(String[] args) {
        AVLTree280<Integer> K = new AVLTree280<Integer>(10);

        //test for adding left rotation
        K.insert(1);
        K.insert(2);
        K.insert(3);
        K.insert(4);
        K.insert(5);



        K.clear();
        //for right rotation

        K.insert(20);
        K.insert(7);
        K.insert(5);
        K.insert(10);
        K.insert(9);




        for(int i = 1; i <= 5; i++) {
            K.insert(i);
            if(K.item() != i) System.out.println("Expected current item to be " + i + ", got " + K.item());
    }

        for(int i = 5; i >= 1; i--) {

            if(i==1) {
                if( !K.isEmpty() ) System.out.println("Expected the heap to be empty, but it wasn't.");
            }
            else {

                if (K.item() != i - 1) System.out.println("Expected current item to be " + i + ", got " + K.item());

            }
        }
    }
}

