package lib280.tree;

import lib280.base.CursorPosition280;
import lib280.base.Dispenser280;
import lib280.exception.*;

public class ArrayedHeap280<I extends Comparable<? super I>> extends ArrayedBinaryTree280<I> implements Dispenser280<I> {
    /**
     * Constructor.
     *
     * @param cap Maximum number of elements that can be in the lib280.tree.
     */

    /*@SuppressWarnings("unchecked")
    public ArrayedBinaryTree280(int cap) {
        capacity = cap;
        currentNode = 0;
        count = 0;
        items = (I[]) new Object[capacity+1];*/

    @SuppressWarnings("unchecked")

    public ArrayedHeap280(int cap) {
       super(cap);

        items = (I[]) new Comparable[cap + 1];



    }





    /**	Insert x into the data structure.
     * @precond !isFull() and !has(x)
     * @param x item to be inserted into the data structure
     * @throws ContainerFull280Exception if the heap is already full.
     * @throws DuplicateItems280Exception if the heap already contains x.
     */


    public void insert(I x) throws ContainerFull280Exception, DuplicateItems280Exception{
        // TODO - Implement this method


        //set the item heap to be empty
        I item_heap = null;
        I new_heap; //new heap to be inserted
        I heap_branch; //heap_branch to be inserted

        if (isFull()) throw new ContainerFull280Exception("Heap is full"); //check if the heap is full

            for (int y = 1; y <= count; ++y) {

                if (items[y] == item_heap) //checks if y items is empty
                    throw new DuplicateItems280Exception("Already contains item x"); //check if the item already contain x item
            }

            if (currentNode == count + 1) { //index of the current will be the current number of elements
                currentNode = currentNode + 1; //going to increment the index of the node of the position
            }

            count = count + 1; //increase the number of elements
            items[count] = x; //assign the current elements in the items to x
            currentNode = count; //assign current node to be current number of elements


            while (items[currentNode] != items[1] && items[currentNode].compareTo(items[findParent(currentNode)]) > 0) { //check the current node if is equal to index 0 and then compare the parent



                heap_branch = items[findParent(currentNode)]; //assign heap_branch to be the parent of the current node
                new_heap = items[currentNode]; //and new heap to be item index

                items[findParent(currentNode)] = new_heap; //swap the items
                items[currentNode] = heap_branch;

                 currentNode = findParent(currentNode); //assign current node to be the index of the parent
            }


        }





    /**	Delete current item from the data structure.
     * @precond	!itemExists() and isEmpty()
     * @throws NoCurrentItem280Exception if the cursor is not currently positioned at a valid item.
     *         NoCurrentItem280Exception if the cursor is not currently positioned at a valid item.
     *
     */


    public void deleteItem() throws NoCurrentItem280Exception {
        //TODO - Implement this method

        I item;
        I heap_right;
        I heap_left;

        
        if (!itemExists())
            throw new NoCurrentItem280Exception("cursor not correctly positioned in the item"); //throw an exception error
        if (isEmpty())
            throw new NoCurrentItem280Exception("empty tree in the dict"); //throw an empty exception error
        Object item_heap = null;


        items[currentNode] = items[count]; //assign to be current number of items in the tree
        count = count - 1; //then decrease the current number of elements in the tree

        boolean test = true; //assign test to be true;
        if (count != 0) //check if the number of elements is equal to zero
            while (findLeftChild(currentNode) < count && test) { //iterate and check the index of the left child is less than number of elements of the boolean

                item = items[currentNode]; //assign item to be the index of the node in the item

                heap_right = items[findRightChild(currentNode)]; //finds the right child index
                heap_left = items[findLeftChild(currentNode)]; //finds the left child index

                if (heap_right != item_heap & heap_right.compareTo(heap_left) >= 0) { //check if the right child and left is greater than zero or is empty

                    if (item.compareTo(heap_right) <= 0) { //checks if is less than or equal to

                        items[currentNode] = heap_right; //then the index of the node willl be the right heap
                        items[findRightChild(currentNode)] = item; //and the right child of the node will be the item
                        currentNode = findRightChild(currentNode); //make the index of the node to be the right index of the child
                    }

                }  if (heap_left.compareTo(heap_right) >= 0) { //check if the heap left is the right heap

                    if (item.compareTo(heap_left) <= 0) { //check if the heap left is less than zero or equal to
                        items[currentNode] = heap_left;

                        items[findLeftChild(currentNode)] = item; //assign item to be the index of the left child of the currrent node

                        currentNode = findLeftChild(currentNode); //will be the index of the left child index
                    }
                }else
                    test = false; //exit from the loop
            }
                if (count == 0) //checks if current number of elements is equal to zero or 1
                    currentNode = 0; //assign zero then
                else //otherwise
                if (count == 1)
                    currentNode = 1;
                else currentNode = 1; //assign to be one
            }



    /**
     * Helper for the regression test.  Verifies the heap property for all nodes.
     */
    private boolean hasHeapProperty() {
        for(int i=1; i <= count; i++) {
            if( findRightChild(i) <= count ) {  // if i Has two children...
                // ... and i is smaller than either of them, , then the heap property is violated.
                if( items[i].compareTo(items[findRightChild(i)]) < 0 ) return false;
                if( items[i].compareTo(items[findLeftChild(i)]) < 0 ) return false;
            }
            else if( findLeftChild(i) <= count ) {  // if n has one child...
                // ... and i is smaller than it, then the heap property is violated.
                if( items[i].compareTo(items[findLeftChild(i)]) < 0 ) return false;
            }
            else break;  // Neither child exists.  So we're done.
        }
        return true;
    }

    /**
     * Regression test
     */
    public static void main(String[] args) {

        ArrayedHeap280<Integer> H = new ArrayedHeap280<Integer>(10);

        // Empty heap should have the heap property.
        if(!H.hasHeapProperty()) System.out.println("Does not have heap property.");

        // Insert items 1 through 10, checking after each insertion that
        // the heap property is retained, and that the top of the heap is correctly i.
        for(int i = 1; i <= 10; i++) {
            H.insert(i);
            if(H.item() != i) System.out.println("Expected current item to be " + i + ", got " + H.item());
            if(!H.hasHeapProperty()) System.out.println("Does not have heap property.");
        }

        // Remove the elements 10 through 1 from the heap, chekcing
        // after each deletion that the heap property is retained and that
        // the correct item is at the top of the heap.
        for(int i = 10; i >= 1; i--) {
            // Remove the element i.
            H.deleteItem();
            // If we've removed item 1, the heap should be empty.
            if(i==1) {
                if( !H.isEmpty() ) System.out.println("Expected the heap to be empty, but it wasn't.");
            }
            else {
                // Otherwise, the item left at the top of the heap should be equal to i-1.
                if(H.item() != i-1) System.out.println("Expected current item to be " + i + ", got " + H.item());
                if(!H.hasHeapProperty()) System.out.println("Does not have heap property.");
            }
        }

        System.out.println("Regression Test Complete.");
    }
}