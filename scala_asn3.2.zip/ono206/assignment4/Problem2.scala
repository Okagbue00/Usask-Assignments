

// OKAGBUE ONYEKA FRANCIS
// CMPT 340
// ASSIGNMENT 3.2
// MARCH 9TH 2023
// 11279373
// ONO206
//QUESTION 2

package cmpt340.assignment4

object Problem2 extends App{

  //For these problems, use the following implementation of unfold:

  def unfold[A, S](z: S)(f: S => Option[(A, S)]): LazyList[A] =  f(z) match {

    case Some((h, s)) => h #:: unfold(s)(f)

    case None => LazyList()

    //#:: is the Cons constructor of LazyLists

  }

  def sum(N: LazyList[Int]): Int = { N.sum }

  def factors(n: Int): LazyList[Int] = {
    unfold(1)(m =>
      if (m > n) {
        None
      }

      else {
        Some((m, m + 1))
      } ).filter(n.%(_) == 0).filter(n.!=)
  }


  def perfectNumbers(f: Int => LazyList[Int])(n: LazyList[Int] => Int): LazyList[Int] = {
    unfold(1)(m => Some(m * (m + 1) / 2, m + 1))
      .filter(m => n(f(m)) == m)
      .filter(m => f(m).sum == m)
  }



  println(factors(28).toList)
  println(perfectNumbers(factors)(sum).take(4).toList)





}























