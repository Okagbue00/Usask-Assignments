// OKAGBUE ONYEKA FRANCIS
// CMPT 340
// ASSIGNMENT 3.2
// MARCH 9TH 2023
// 11279373
// ONO206
// QUESTION 1

package cmpt340.assignment4


object Problem1 extends App {


  //For these problems, use the following implementation of unfold:

  def unfold[A, S](z: S)(f: S => Option[(A, S)]): LazyList[A] = f(z) match {

    case Some((h, s)) => h #:: unfold(s)(f)

    case None => LazyList()

    //#:: is the Cons constructor of LazyLists

  }

  def pyth(N: Int): LazyList[(Int, Int, Int)] = {

    //This function generates a lazy list of Pythagorean triples up to a given limit N.
    //param: N is the limit up to which to generate Pythagorean triples.
    //return: would return a lazy list of Pythagorean triples

    val pythagorean = unfold(3) { //the lazy list is generated using the unfold method

      case m if m <= N =>
        Some(m, m + 1)

      case k => None

    }


  //uses a for-comprehension to represent the values of x, y and z.
    for {

      (x, _) <- pythagorean.zip(pythagorean)
      (y, _) <- pythagorean.zip(pythagorean)
      (z, _) <- pythagorean.zip(pythagorean) takeWhile (_._1.<=(N))

      if math.sqrt(x * x + y * y) == z

    }

    yield (x, y, z)
  }

  //Here ---> to test the program for the pythogrean triples
    val result1 = pyth(10).toList
    val result2 = pyth(12).toList
    val result3 = pyth(5).toList
    val result4 = pyth(1).toList
    val result5 = pyth(99).toList

    println(result1)
    println(result2)
    println(result3)
    println(result4)
    println(result5)

}
