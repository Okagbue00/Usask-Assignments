
const express = require("express");

const bodyParser = require("body-parser");

const {writeFile} = require("fs");

const fs = require("fs");

const  app = express();

const port = 8080;

const host = '0.0.0.0';


app.use(bodyParser.urlencoded({extended: true}));



app.post("/postmessage", (req, res) =>
{
    const topic = req.body.topic, data = req.body.data, date = new Date();
    writeFile('posts.txt', `${topic}, ${data}, ${date}\n`, {flag: 'a+'},
        err => {
            if (err){
                console.error(err)
            }
        });
    res.sendFile("posting.html", {root: __dirname + '/'});

});


app.get("/postingfile", (req,res) =>{
    var write = fs.readFileSync('posts.txt')
    res.send(write)
})

app.get('/',(req,res)=>{
    res.sendFile("posting.html", {root: __dirname + '/'})

});

app.listen(port, host);

console.log("Well-implemented...")