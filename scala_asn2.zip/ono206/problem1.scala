object problem1 {

  // (a) The returned list contains the first element of l1, followed by the
  // first element of l2, followed by the second element of l1, and so on. If one
  // of the lists ends before the other, the other list's remaining elements are
  // simply added to the end.
  def shuffle[A](l1: List[A], l2: List[A]): List[A] = (l1, l2) match {
    case (x1 :: sub_l1, x2 :: sub_l2) =>
      x1 :: x2 :: shuffle(sub_l1, sub_l2) // Return element in l1 before l2
    case (l1, Nil) => l1 // If l2 is empty, return l1
    case (Nil, l2) => l2 // If l1 is empty, return l2
  }

  // (b) It splits the contents of the provided list into two lists, the first
  // with the first n-elements of the list (in order), and the second with the
  // remaining elements (again, in order). These two lists are then returned as
  // a list of two lists.
  def split[A](ls: List[A], n: Int): List[List[A]] = n match {
    case 0          => List(Nil, ls)
    case n if n < 0 => List(Nil, ls) // Negative n
    case n =>
      ls match {
        case x :: sub_ls =>
          split(sub_ls, n - 1) match {
            case first :: last :: Nil => List(x :: first, last)
            case _                    => List(Nil, Nil)
          }
        case Nil => List(Nil, Nil)
      }
  }

  // (c) Carry out perfect Faro shuffles exactly once
  def outShuffle[A](ls: List[A]): List[A] = ls.length match {
    case n if n % 2 != 0 => ls // Do not shuffle if deck is odd
    case n =>
      split(ls, n / 2) match {
        case first :: last :: Nil => shuffle(first, last)
        case _                    => ls // Do not shuffle if split failed
      }
  }

  def inShuffle[A](ls: List[A]): List[A] = ls.length match {
    case n if n % 2 != 0 => ls // Do not shuffle if deck is odd
    case n =>
      split(ls, n / 2) match {
        case first :: last :: Nil => shuffle(last, first)
        case _                    => ls // Do not shuffle if split failed
      }
  }

  // (d) Carries out the required number of shuffles on the list
  def nShuffle[A](
      shuffleFun: (List[A]) => List[A],
      n: Int,
      ls: List[A]
  ): List[A] = n match {
    case n if n <= 0 => ls // Do nothing
    case n =>
      nShuffle(
        shuffleFun,
        n - 1,
        shuffleFun(ls)
      ) // Shuffle once and proceed to next
  }

  // (e) Count the number of times shuffle is performed to get the target list
  def howManyShuffles[A](
      shuffleFun: (List[A]) => List[A],
      ls: List[A],
      lsTarget: List[A]
  ): Int = shuffleFun(ls) == lsTarget match {
    case true => 1
    case false =>
      1 + howManyShuffles(
        shuffleFun,
        shuffleFun(ls),
        lsTarget
      ) // Apply once and proceed
  }

  def main(args: Array[String]): Unit = {
    // Test shuffle(l1, l2)
    var l1: List[Int] = List(0, 2, 4, 6, 8, 10)
    var l2: List[Int] = List(1, 3, 5, 7, 9, 11)

    // Equal lengths
    assert(shuffle(l1, l2) == List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11))

    // Shorter l2
    l2 = List(1, 3, 5)

    assert(shuffle(l1, l2) == List(0, 1, 2, 3, 4, 5, 6, 8, 10))

    // Shorter l1
    l1 = List(0, 2, 4, 6)
    l2 = List(1, 3, 5, 7, 9, 11)

    assert(shuffle(l1, l2) == List(0, 1, 2, 3, 4, 5, 6, 7, 9, 11))

    // Empty l2
    assert(shuffle(l1, Nil) == List(0, 2, 4, 6))

    // Empty l1
    assert(shuffle(Nil, l2) == List(1, 3, 5, 7, 9, 11))

    // Test split(ls, n)
    l1 = List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    assert(split(l1, 1) == List(List(1), List(2, 3, 4, 5, 6, 7, 8, 9, 10)))
    assert(split(l1, 2) == List(List(1, 2), List(3, 4, 5, 6, 7, 8, 9, 10)))
    assert(split(l1, 10) == List(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), List()))
    assert(split(l1, 11) == List(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), List()))
    assert(split(l1, -1) == List(List(), List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))
    assert(split(l1, -2) == List(List(), List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))

    // Test outShuffle(ls)

    assert(outShuffle(l1) == List(1, 6, 2, 7, 3, 8, 4, 9, 5, 10))

    l2 = List(1, 2, 3)

    assert(outShuffle(l2) == List(1, 2, 3))

    // Test inShuffle(ls)

    assert(inShuffle(l1) == List(6, 1, 7, 2, 8, 3, 9, 4, 10, 5))
    assert(inShuffle(l2) == List(1, 2, 3))

    // Test nShuffle(shuffleFun, n, ls)

    assert(nShuffle(outShuffle, 0, l1) == List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
    assert(nShuffle(outShuffle, 1, l1) == List(1, 6, 2, 7, 3, 8, 4, 9, 5, 10))
    assert(nShuffle(outShuffle, 2, l1) == List(1, 8, 6, 4, 2, 9, 7, 5, 3, 10))

    // Test howManyShuffles
    val deck = Range.inclusive(1, 52).toList
    val deckOS1 = outShuffle(deck)
    val deckOS2 = outShuffle(deckOS1)

    // Expected = 1
    assert(howManyShuffles(outShuffle, deck, deckOS1) == 1)

    // Expected = 2
    assert(howManyShuffles(outShuffle, deck, deckOS2) == 2)

    println(
      "How many out-shuffles are required to return a stack of 52 cards to its original beginning?"
    )
    println(howManyShuffles(outShuffle, deck, deck))

    println(
      "How many in-shuffles are required to completely reverse a stack of 52 cards?"
    )
    println(howManyShuffles(inShuffle, deck, deck.reverse))

  }
}
