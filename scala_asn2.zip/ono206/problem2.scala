// Define the Tree type here 
type Tree[A] = Node[A] | Leaf[A]
class Node[A](var value : A, var leftSubTree: Option[Tree[A]], var rightSubTree: Option[Tree[A]]) {}
class Leaf[A](var value : A) {}

object problem2 {
    // (a) Define functions to convert tree into list
    // Flatten the tree in order: left, node, right 
    def inOrder[A](tree: Tree[A]): List[A] = tree match {
        case leaf: Leaf[A] => List(leaf.value)
        case node: Node[A] => (node.leftSubTree, node.rightSubTree) match {
            case (None, None) => List(node.value)
            case (Some(left), None) => inOrder(left) ::: List(node.value)
            case (None, Some(right)) => List(node.value) ::: inOrder(right)
            case (Some(left), Some(right)) => inOrder(left) ::: List(node.value) ::: inOrder(right)
        }
    }

    // Flatten the tree in order: node, left, right 
    def preOrder[A](tree: Tree[A]): List[A] = tree match {
        case leaf: Leaf[A] => List(leaf.value)
        case node: Node[A] => (node.leftSubTree, node.rightSubTree) match {
            case (None, None) => List(node.value)
            case (Some(left), None) => List(node.value) ::: inOrder(left)
            case (None, Some(right)) => List(node.value) ::: inOrder(right)
            case (Some(left), Some(right)) => List(node.value) ::: inOrder(left) ::: inOrder(right)
        }
    }

    // Flatten the tree in order: left, right, node
    def postOrder[A](tree: Tree[A]): List[A] = tree match {
        case leaf: Leaf[A] => List(leaf.value)
        case node: Node[A] => (node.leftSubTree, node.rightSubTree) match {
            case (None, None) => List(node.value)
            case (Some(left), None) => inOrder(left) ::: List(node.value)
            case (None, Some(right)) => inOrder(right) ::: List(node.value) 
            case (Some(left), Some(right)) => inOrder(left) ::: inOrder(right) ::: List(node.value)
        }
    }

    // (b) Checks whether the key is in the tree or not 
    def search[A](tree: Tree[A], key: A): Boolean = tree match {
        case leaf: Leaf[A] => key == leaf.value
        case node: Node[A] => (node.leftSubTree, node.rightSubTree) match {
            case (None, None) => key == node.value
            case (Some(left), None) => key == node.value || search(left, key)
            case (None, Some(right)) => key == node.value || search(right, key)
            case (Some(left), Some(right)) => key == node.value || search(left, key) || search(right, key)
        }
    }

    // (c) Returns a new tree with before replaced with after 
    def replace[A](tree: Tree[A], before: A, after: A): Tree[A] = tree match {
        case leaf: Leaf[A] => leaf.value == before match {
            case true => Leaf(after)
            case false => Leaf(leaf.value)
        } 
        case node: Node[A] => (node.leftSubTree, node.rightSubTree) match {
            case (None, None) => node.value == before match {
                case true => Node(after, None, None)
                case false => Node(node.value, None, None)
            }
            case (Some(left), None) => node.value == before match {
                case true => Node(after, Some(replace(left, before, after)), None)
                case false => Node(node.value, Some(replace(left, before, after)), None)
            }
            case (None, Some(right)) => node.value == before match {
                case true => Node(after, None, Some(replace(right, before, after)))
                case false => Node(node.value, None, Some(replace(right, before, after)))
            }
            case (Some(left), Some(right)) => node.value == before match {
                case true => Node(after, Some(replace(left, before, after)), Some(replace(right, before, after)))
                case false => Node(node.value, Some(replace(left, before, after)), Some(replace(right, before, after)))
            }
        }
    }

    def main(args: Array[String]): Unit = {
        val leaf = Leaf(1)
        println(leaf.value)

        var tree1 = Node(2, Some(Leaf(1)), Some(Leaf(3)))
        println(inOrder(tree1))
        println(preOrder(tree1))
        println(postOrder(tree1))
        
        println(search(tree1, 1))
        println(search(tree1, 2))
        println(search(tree1, 3))
        println(search(tree1, 0))
        println(search(tree1, 4))
        println(search(tree1, 5))

        var tree2 = Node(4, 
            Some(Node(3, 
                Some(Leaf(1)), 
                Some(Leaf(2)))), 
            Some(Node(1, 
                Some(Leaf(2)), 
                None)))
        println(inOrder(tree2))
        println(inOrder(replace(tree2, 1, 10)))
        println(inOrder(replace(tree2, 2, 100)))
    }
}