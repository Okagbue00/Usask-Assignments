object problem3 {

    // (a) Doubles a digit and subtracts 9 if the result is greater than 9
    def luhnDouble(digit: Int): Int = (digit * 2) match {
        case n if n > 9 => n - 9
        case n => n
    }

    // (b) Apply a list of functions to a list of values 
    def altMap(funcs: List[(Int) => Int], values: List[Int]): List[Int] = (funcs, values) match {
        case (f :: sub_funcs, x :: sub_values) => f(x) :: altMap(sub_funcs ::: List(f), sub_values)
        case _ => Nil 
    }

    // (c) Apply luhn to check the validity of card numbers 
    def luhn(values: List[Int]): Boolean = {
        // Define sum to add the list of integers
        def sum(digits: List[Int]): Int = digits match {
            case digit :: sub_digits => digit + sum(sub_digits)
            case Nil => 0
        }

        // The card is valid if the sum of computed digits is divisible by 10
        sum(altMap(List((x:Int) => x, luhnDouble), values.reverse)) % 10 == 0
    }

    def main(args: Array[String]): Unit = {
        println(luhnDouble(3))
        println(luhnDouble(6))

        println(altMap(List(_ + 10, _ + 100), List(0, 1, 2, 3, 4)))

        println(luhn(List(1, 2, 3, 4)))
        println(luhn(List(6, 7, 8, 9)))
        println(luhn(List(4, 6, 2, 4, 7, 4, 8, 2, 3, 3, 2, 4, 9, 7, 8, 0)))
    }
}