/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;

public class MainUI extends StackPane {
    // it stores all the widgets
    ListView<Houses> houses;
    ListView<SearchSpec> searches;
    ControlFilter priceFilter;
    ControlFilter bedroomFilter;
    ControlFilter areaFilter;
    TextField searchName;
    Button saveButton;
    Button loadButton;
    Button clearButton;
    Button quitButton;
    ArrayList<Houses> houseList = Houses.loadHouseList();
    SearchSpec filterSpec = new SearchSpec();

    /**
     * Construct the main UI control of the application.
     */
    public MainUI() {
        setPrefWidth(800); // it sets the size
        GridPane mainBox = new GridPane(); // it adds the widgets
        getChildren().add(mainBox); // it adds the main box

        // Set constraints to grid pane
        ColumnConstraints columnConst = new ColumnConstraints();
        columnConst.setPercentWidth(50);
        mainBox.getColumnConstraints().add(columnConst);
        mainBox.getColumnConstraints().add(columnConst);

        RowConstraints rowConst = new RowConstraints();
        rowConst.setPercentHeight(100);
        mainBox.getRowConstraints().add(rowConst);

        // Add the left and right boxes
        VBox leftBox = setupLeftBox();
        mainBox.add(leftBox, 0, 0);

        VBox rightBox = setupRightBox();
        mainBox.add(rightBox, 1, 0);
    }

    /**
     * Setup the left box of the application.
     * @return the vertical box control
     */
    private VBox setupLeftBox() {
        VBox leftBox = new VBox();
        leftBox.setSpacing(5);
        leftBox.setPadding(new Insets(5));

        // Add controls to the left box
        Label title = new Label("Houses for Sale");
        leftBox.getChildren().add(title);
        title.setStyle("-fx-font-size: 200%; -fx-font-weight: bold;");

        // Create the list view for houses
        houses = new ListView<Houses>();
        houses.getItems().addAll(houseList);
        leftBox.getChildren().add(houses);
        VBox.setVgrow(houses, Priority.ALWAYS);

        // Add the filter controls
        priceFilter = new ControlFilter("Price", 150000, 800000, 150000, 800000);
        bedroomFilter = new ControlFilter("Bedrooms", 1, 6, 1, 6);
        areaFilter = new ControlFilter("Sq.Ft.", 750, 3000, 750, 3000);

        // Setup the filter controls
        setupFilterEvents();
        createNewSpec();    // Create a valid filter specification
        leftBox.getChildren().addAll(priceFilter, bedroomFilter, areaFilter);

        // Add the save search box
        leftBox.getChildren().add(setupSaveSearch());

        return leftBox;
    }

    /**
     * Create a new specification based on the filter controls' values.
     */
    private void createNewSpec() {
        filterSpec = new SearchSpec();

        // Get the values from the filter controls
        filterSpec.setPriceLower(priceFilter.lower().get());
        filterSpec.setPriceUpper(priceFilter.upper().get());
        filterSpec.setAreaLower(areaFilter.lower().get());
        filterSpec.setAreaUpper(areaFilter.upper().get());
        filterSpec.setBedroomLower(bedroomFilter.lower().get());
        filterSpec.setBedroomUpper(bedroomFilter.upper().get());
    }

    /**
     * Setup the filter events to update the filter when the set button is pressed.
     */
    private void setupFilterEvents() {
        // Create an event handler for all the set buttons
        final EventHandler<ActionEvent> filterHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                // Update current spec
                createNewSpec();
                filter();
            }
        };

        // Set the common event handler to all filter controls
        priceFilter.setOnAction(filterHandler);
        areaFilter.setOnAction(filterHandler);
        bedroomFilter.setOnAction(filterHandler);
    }

    /**
     * Setup the save search box that will store the search specifications.
     * @return horizontal box of the save search
     */
    private HBox setupSaveSearch() {
        // Create save search box
        HBox saveBox = new HBox();
        saveBox.setSpacing(5);

        // Create the controls and set its properties
        saveButton = new Button("Save");
        searchName = new TextField();
        searchName.setPromptText("Name of Search");

        saveBox.getChildren().addAll(new Label("Save Search:"), searchName, saveButton);
        HBox.setHgrow(searchName, Priority.ALWAYS);

        // Setup event for save button
        saveButton.setOnAction((event) -> {
            // Only save if name is saved
            if (searchName.getText().length() > 0) {
                // Update the name of the search spec
                filterSpec.setName(searchName.getText());

                // Add to the searches list view
                searches.getItems().add(filterSpec);

                // Clear the text box
                searchName.clear();
            }
        });

        return saveBox;
    }

    /**
     * Setup the buttons box to control the searches list.
     * @return horizontal box of the buttons
     */
    private HBox setupButtonsBox() {
        // it creates the buttons box
        HBox buttonsBox = new HBox();
        buttonsBox.setSpacing(5);

        // Create buttons
        loadButton = new Button("Load Search");
        clearButton = new Button("Clear Filters");
        quitButton = new Button("Quit");

        // Configure button events
        quitButton.setOnAction((action) -> {
            Platform.exit();
        });

        clearButton.setOnAction((action) -> {
            searches.getItems().clear();
        });

        loadButton.setOnAction((action) -> {
            // Selected search spec
            SearchSpec selectedItem = searches.getSelectionModel().getSelectedItem();

            // Update only if there is a selected item
            if (selectedItem == null) {
                return;
            }

            // Get the selected searches item
            filterSpec = selectedItem;

            // Update the filter controls
            priceFilter.lower().set(filterSpec.getPriceLower());
            priceFilter.upper().set(filterSpec.getPriceUpper());
            areaFilter.lower().set(filterSpec.getAreaLower());
            areaFilter.upper().set(filterSpec.getAreaUpper());
            bedroomFilter.lower().set(filterSpec.getBedroomLower());
            bedroomFilter.upper().set(filterSpec.getBedroomUpper());

            // Apply the filter
            filter();
        });

        // Add to the box
        buttonsBox.getChildren().addAll(loadButton, clearButton, quitButton);

        // Adjust the width
        HBox.setHgrow(loadButton, Priority.ALWAYS);
        HBox.setHgrow(clearButton, Priority.ALWAYS);

        loadButton.setMaxWidth(Double.MAX_VALUE);
        clearButton.setMaxWidth(Double.MAX_VALUE);
        quitButton.setMinWidth(80);

        return buttonsBox;
    }

    /**
     * Setup the right box that contains the search list.
     * @return
     */
    private VBox setupRightBox() {
        VBox rightBox = new VBox();
        rightBox.setSpacing(5);
        rightBox.setPadding(new Insets(5));

        // Create the list view of searches
        searches = new ListView<SearchSpec>();

        // Add controls to the right box
        Label title = new Label("Saved Searches");
        title.setStyle("-fx-font-size: 150%; -fx-font-weight: bold;");
        rightBox.getChildren().add(title);
        rightBox.getChildren().add(searches);
        VBox.setVgrow(searches, Priority.ALWAYS);

        rightBox.getChildren().add(setupButtonsBox());

        return rightBox;
    }

    /**
     * Apply the current filter search specification.
     */
    private void filter() {
        houses.getItems().clear(); // clears the house list search

        // Iterate through each house and add if it matches
        houseList.stream().filter(house -> filterSpec.isMatch(house)).forEach(house -> houses.getItems().add(house));
    }

}

