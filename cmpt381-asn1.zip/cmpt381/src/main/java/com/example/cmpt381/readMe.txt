/* Okagbue  Onyeka Francis
* Ono206
* 11279373 */

To run the application, you would need to run the App class, it has the start function that would execute the program.
All parts of the assignment is implemented correctly and the GUI are working appropriately as supposed to.
The files for the assignment include:- the houses.txt, App, ControlFilter, Houses, MainUI, SearchSpec...