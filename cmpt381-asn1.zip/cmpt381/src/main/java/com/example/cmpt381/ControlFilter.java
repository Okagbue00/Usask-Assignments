/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381;

import javafx.beans.property.DoubleProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class ControlFilter extends HBox {
    //creates the min and max sliders, button and label
    Slider minSlider;
    Slider maxSlider;
    Button setButton;
    Label rangeLabel;

    /**
     * Construct a new filter control.
     * @param title title of the filter
     * @param minValue minimum value of the slider
     * @param maxValue maximum value of the slider
     * @param lowValue initial low value of the slider
     * @param highValue initial high value of the slider
     */
    public ControlFilter(String title, double minValue, double maxValue, double lowValue, double highValue) {
        // it creates the widgets
        setSpacing(5);
        setStyle("-fx-background-color: #cccccc;");
        setPadding(new Insets(2.5));
        getChildren().add(new Label(title));

        VBox sliderBox = new VBox();

        // creates the sliders
        minSlider = new Slider();
        minSlider.setMin(minValue);
        minSlider.setMax(maxValue);

        maxSlider = new Slider();
        maxSlider.setMin(minValue);
        maxSlider.setMax(maxValue);

        sliderBox.getChildren().addAll(minSlider, maxSlider);
        HBox.setHgrow(sliderBox, Priority.ALWAYS);

        getChildren().add(sliderBox);

        // Creates the buttons
        rangeLabel = new Label();
        getChildren().add(rangeLabel);

        setButton = new Button("Set");
        getChildren().add(setButton);

        // Set low and high values
        lower().set(lowValue);
        upper().set(highValue);

        updateRangeLabel(lowValue, highValue);

        // Set events
        configureEvents();
    }

    /**
     * Configure the event handlers of the controls.
     */
    private void configureEvents() {
        // Capture sliding events
        lower().addListener((oev, ov, nv) -> {
            double new_value = nv.doubleValue();

            // Adjust upper if lower is greater than upper
            if (new_value > upper().get()) {
                upper().set(new_value);
            }

            updateRangeLabel(new_value, upper().get());
        });

        upper().addListener((oev, ov, nv) -> {
            double new_value = nv.doubleValue();

            // Adjust lower if upper is less than lower
            if (lower().get() > new_value) {
                lower().set(new_value);
            }

            updateRangeLabel(lower().get(), new_value);
        });
    }

    /**
     * Set the event handler of the set button.
     * @param handler new event handler
     */
    public void setOnAction(EventHandler<ActionEvent> handler)
    {
        setButton.setOnAction(handler);
    }

    /**
     * Get the double property of the lower slider.
     * @return lower slider double property
     */
    public DoubleProperty lower()
    {
        return minSlider.valueProperty();
    }

    /**
     * Get the double property of the upper slider.
     * @return upper slider double property
     */
    public DoubleProperty upper()
    {
        return maxSlider.valueProperty();
    }

    /**
     * Update the label based on the new low and high range.
     * @param low low value of the range
     * @param high high value of the range
     */
    public void updateRangeLabel(double low, double high)
    {
        rangeLabel.setText(String.format("%.0f - %.0f", low, high));
    }

}

