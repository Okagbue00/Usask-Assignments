/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class App extends Application {
    /**
     * Application is started.
     * @param stage The stage where the scene will be placed on
     * @throws IOException exception from creating the scene
     */
    @Override
    public void start(Stage stage) throws IOException {
        Scene scene = new Scene(new MainUI());
        stage.setTitle("381 2022 A1.");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Entry point of the application.
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        launch();
    }
}
