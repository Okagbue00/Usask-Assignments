/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381;

public class SearchSpec {
    private double priceLower = 0;
    private double priceUpper = Double.MAX_VALUE;
    private double bedroomLower = 0;
    private double bedroomUpper = Double.MAX_VALUE;
    private double areaLower = 0;
    private double areaUpper = Double.MAX_VALUE;
    private String name = "";

    /**
     * Set the name of the search specification.
     * @param value new name
     */
    public void setName(String value)
    {
        name = value;
    }

    /**
     * Get the lower price.
     * @return lower price value
     */
    public double getPriceLower()
    {
        return priceLower;
    }

    /**
     * Get the upper price.
     * @return upper price value
     */
    public double getPriceUpper()
    {
        return priceUpper;
    }

    /**
     * Get the lower number of bedrooms.
     * @return lower number
     */
    public double getBedroomLower()
    {
        return bedroomLower;
    }

    /**
     * Get the upper number of bedrooms.
     * @return upper number
     */
    public double getBedroomUpper()
    {
        return bedroomUpper;
    }

    /**
     * Get the lower area.
     * @return lower area
     */
    public double getAreaLower()
    {
        return areaLower;
    }

    /**
     * Get the upper area
     * @return upper area
     */
    public double getAreaUpper()
    {
        return areaUpper;
    }

    /**
     * Set the lower price.
     * @param value new lower price
     */
    public void setPriceLower(double value)
    {
        priceLower = value;
    }

    /**
     * Set the upper price.
     * @param value new upper price
     */
    public void setPriceUpper(double value)
    {
        priceUpper = value;
    }

    /**
     * Set the lower number of bedrooms.
     * @param value new lower number of bedrooms
     */
    public void setBedroomLower(double value)
    {
        bedroomLower = value;
    }

    /**
     * Set the upper number of bedrooms.
     * @param value new upper number of bedrooms
     */
    public void setBedroomUpper(double value)
    {
        bedroomUpper = value;
    }

    /**
     * Set the lower area.
     * @param value new lower area
     */
    public void setAreaLower(double value)
    {
        areaLower = value;
    }

    /**
     * Set the upper area.
     * @param value new upper area
     */
    public void setAreaUpper(double value)
    {
        areaUpper = value;
    }

    /**
     * Check if the house matches the filter specification.
     * @param house house to match
     * @return true if matched, false otherwise
     */
    public boolean isMatch(Houses house) {
        return priceLower <= house.getPrice() && house.getPrice() <= priceUpper &&
                bedroomLower <= house.getBedrooms() && house.getBedrooms() <= bedroomUpper &&
                areaLower <= house.getArea() && house.getArea() <= areaUpper;
    }

    /**
     * Convert the filter specification to string.
     * @return Formatted string showing the details of the filter specification
     */
    public String toString() {
        return String.format("%s: $%.0f-%.0f, %d-%dBR, %.0f-%.0f sq.ft.",
                name, priceLower, priceUpper, (int)bedroomLower, (int)bedroomUpper, areaLower, areaUpper);
    }
}
