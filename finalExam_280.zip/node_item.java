package lib280;

/// This design is defined by the set of item of the ordered elements in the Abstract data type. And each of the item in the
/// structure was given a count which is always copied when is then inserted or deleted from the bag abstract data structure.

public class node_item<I extends Comparable<? super I>> implements Comparable<node_item<I>> {
    public I item_bag; //is the item bag
    public int value; //value is the number of items in the bag

    /**
     * It creates a node item type
     * @param item is the item
     */
    public node_item(I item){
        item_bag = item;
        value = 0;
    }

    /**
     * it gets the item
     * @return it returns the item bag
     */
    public I getItem(){
        return item_bag; //returns the item bag
    }

    /**
     * it increases the item bag
     */
    public void increase(){
        value = value + 1; //it increases the value by 1
    }

    /**
     * it decreases the item of the bag
     */
    public void decrease(){
        value = value - 1; //it decreases the value by 1
    }

    /**
     * It displays the number of times popped up in the bag file
     * @return it returns the value of the item
     */
    public int display(){
        return value; //then returns the value to be displayed
    }

    /**
     * function to compare the items bag
     *
     * @return none
     */
    public int compareTo(node_item<I> element) {
        return 0;
    }
}