package lib280;

import lib280.exception.ContainerEmpty280Exception;
import lib280.exception.ItemNotFound280Exception;
import lib280.list.LinkedIterator280;
import lib280.list.LinkedList280;


public class Bag<I extends Comparable<? super I>> extends LinkedList280<I> {
    protected LinkedList280<I> B; //is the set of possible bags
    protected LinkedList280<node_item<I>> T; //is the ordered elements
    protected int numberOfBag; //is a non-negative integer...

    /**
     * It constructs a a new empty bag to hold elements from T
     * @param item is the item of the bag
     */
    public Bag(LinkedList280<node_item<I>> item){
         T = item; //holds the element T
         B = new LinkedList280<>(); //B to store my linked list
        numberOfBag = 0; //is the a non-negative number

    }

    /**
     * Is the number of copies of t from b
     * @param t is the totally orderable elements in the bag
     * @return it returns the number of copies of t from b been displayed
     */
    public int numberIn(node_item<I> t){
        if (B.isEmpty() || !B.has(t.getItem())) //it checks if the bag is empty or does contains an item
            return 0;
        if (T.isEmpty() || !T.has(t)) throw new ItemNotFound280Exception("item does not exist..."); //it throws an exception that is if the ordered elements items in the bag is empty or it does not contain an item

        return t.display(); //it then displays the number of copies from t in b...
    }

    /**
     * It adds copies from t to b and increases it by one
     * @param t is a set of totally ordered elements that can be in the bag
     */
    public void add(node_item<I> t) { //function to add a copy of t from b and then makes it increases the t in b by 1
        if (T.isEmpty() || !T.has(t)) //it just checks if T the item is empty or does not contain any item
            throw new ItemNotFound280Exception("item does not exist..."); //and then it throws an exception error to show that item does not exist in the bag...
        else { //otherwise
            if (B.isEmpty()) { //checks if the bag is empty
                B.insert(t.getItem()); //then inserts the item gotten into the bag
                numberOfBag = numberOfBag + 1; //and increases it by one
            }

            if (t.getItem().compareTo(B.firstItem()) == 0 || t.getItem().compareTo(B.firstItem()) < 0) { //it compares the bag first item if is empty
                B.insertFirst(t.getItem()); //and then it inserts t into the first item/element in the bag
                numberOfBag++; //it then increases by one
            } else if (t.getItem().compareTo(B.lastItem()) == 0 || t.getItem().compareTo(B.lastItem()) > 0) { //compares the bag last item if is empty
                B.insertLast(t.getItem()); //it inserts t into the last item in the bag
                numberOfBag++; //and then increases the counter by one
            } else { //otherwise
                B.goFirst(); //it jumps to the first item in the bag
                while (B.itemExists()) { //and loop to check if an item exists in the bag
                    if (t.getItem().compareTo(B.item()) == 0 || t.getItem().compareTo(B.item()) < 0) { //and then compares if the item in the bag is empty
                        B.insertBefore(t.getItem()); //it inserts an element in the bag before the current cursor position
                        break; //then breaks away from the loop
                    }
                    B.goForth(); // it advances one item in the bag
                }
                numberOfBag += 1; //and increases the value by one
            }
            t.increase(); //then it increases the counter of the add copy of t in b by one
        }
    }

    /**
     * It removes a copy of t from b
     * @param t is the ordered elements in the bag
     */
    public void remove(node_item<I> t) {
        if (B.isEmpty() || !B.has(t.getItem())) throw new ItemNotFound280Exception("no item to delete from the bag"); //checks if the bag is empty or if an item does not contain in the bag and then throws an exception
        else {
            if (B.firstItem().compareTo(t.getItem()) == 0) { //it checks to compare if the first item and the item gotten in the bag is empty
                B.deleteFirst(); //then it deletes the first item
                numberOfBag -= 1; //and decrease the bag by one
            } else if (B.lastItem().compareTo(t.getItem()) == 0) { //compares the last item and then deletes the last item in the bag
                B.deleteLast(); //it deletes the last item in the bag
                numberOfBag -= 1; //then decreases it by one
            } else {
                B.goFirst(); //advances to the first item in the bag
                while (B.itemExists()) { //checks if the bag item still exist
                    if (t.getItem().compareTo(B.item()) == 0 || t.getItem().compareTo(B.item()) < 0) { //compares and checks if the items in the bag and the item is empty
                        B.delete(t.getItem()); //it then deletes the item in the bag
                        break;
                    }
                    B.goForth(); //and advances by one item in the bag
                }
                numberOfBag -= 1; //decreases by one
            }
            t.decrease(); //it then decreases the counter of the item been removed by one from a copy of t in b

        }
    }

    public String toString() {
        if (B.isEmpty()) //check if the bag is empty
            return " "; //returns an empty string

        LinkedIterator280<I> iter = B.iterator(); //assign iter to be the bag iterator
        String result = ""; //result is the string builder


        iter.goFirst(); //iterates over the elements
        while (!iter.after()) {
            result += iter.item() + ",";
            iter.goForth();
        }
        return result; //returns the string builder

    }


    // **** Regression testing *****************************************************************************************************************************************
    public static void main(String[] args) {
        node_item<Integer> firstItem = new node_item<>(0);
        node_item<Integer> secondItem = new node_item<>(1);
        node_item<Integer> thirdItem = new node_item<>(2);

        LinkedList280<node_item<Integer>> T = new LinkedList280<>();
        LinkedList280<node_item<Integer>> T1 = new LinkedList280<>();


        System.out.println("************** REGRESSION TESTING ******************************");
        //test to check if the bag is empty
        System.out.println(T);
        if (T.isEmpty())
            System.out.println("Bag should be empty and it is...");
        else System.out.println("Error and the bag is not empty...");

        //test for insert item

        T.insert(firstItem);
        T.insert(firstItem);
        T.insert(secondItem);
        T.insert(thirdItem);
        System.out.println("The first item should be: 0 and it is " + firstItem.display());

        //test for deleting item
        T.delete(firstItem);
        T.deleteFirst();
        T.deleteLast();

        T.insertLast(firstItem);
        T.insertLast(firstItem);

        //test for add item
        Bag<Integer> bag = new Bag<>(T);
        bag.add(firstItem);
        bag.add(secondItem);
        bag.add(thirdItem);
        System.out.println(bag.toString());

        //test for delete item
        Bag<Integer> bag1 = new Bag<>(T);
        bag1.add(firstItem);
        bag1.add(secondItem);
        bag1.add(thirdItem);

        bag1.remove(firstItem);
        bag1.numberIn(firstItem);
        bag1.remove(thirdItem);
        System.out.println(bag1.toString());
        System.out.println("The bag item should be 1...");


        T1.insert(firstItem);
        T1.delete(firstItem);
        System.out.println("Deleted 0");
        System.out.print("the bag should be empty ....");
        if( T1.isEmpty() ) System.out.println("and it is.  OK!");
        else System.out.println("and it is not.  ERROR!");


        //test for finding the delete first item in the bag
        System.out.println("Deleting first item from the bag.");
        try {
            T1.deleteFirst();
            System.out.println("ERROR: exception should have been thrown, but wasn't.");
        }
        catch( ContainerEmpty280Exception e ) {
            System.out.println("Caught exception.  OK!");
        }

        //test for finding the delete first item in the bag
        System.out.println("Deleting last item from the bag.");
        try {
            T1.deleteLast();
            System.out.println("ERROR: exception should have been thrown, but wasn't.");
        }
        catch( ContainerEmpty280Exception e ) {
            System.out.println("Caught exception.  OK!");
        }


        System.out.println("deleting the first item.");
        try {
            T1.delete(firstItem);
            System.out.println("ERROR: exception should have been thrown, but wasn't.");
        }
        catch( ContainerEmpty280Exception e ) {
            System.out.println("Caught exception.  OK!");
        }
    }
}