import lib280.base.NDPoint280;
import lib280.exception.InvalidArgument280Exception;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


public class KDTree280 {
    protected int dimension;
    protected KDNode280 kdNode;
    protected int d;
    protected int medianOffSet;
    protected NDPoint280 ndPoint280;


    /**
     *
     * @param array is the arr used to build the kdtree 280
     * @param dimension Dimensionality of the point.
     */
    protected KDTree280(NDPoint280[] array, int dimension) {
        int i = 0;
        int arrayLength = array.length;
        while (i < arrayLength) {
             ndPoint280 = array[i];
             //throws an exception if the dimension point is not equal
            if (!(ndPoint280.dim() == dimension)) throw new RuntimeException("Error: dimension is not accurate");
            i++;
        }
        this.dimension = dimension;

        //to build the tree left, right and the depth...
        kdNode = kdTree(array, 0, array.length - 1, 0);

    }

    /**
     * To build the kTree
     * @param array array of k- dimensional points
     * @param left offset of start of subarray from which to build a kd - tree
     * @param right offset of end of subarray from which to build a kd - tree
     * @param depth the current depth in the partially built tree
     * @return the root of the tree
     */
    protected KDNode280 kdTree(NDPoint280[] array, int left, int right, int depth) {

        ////Builds the kTree

        //checks if the dimensional points is empty
        if (array != null) {

            if (right < left) { //checks if the end subarray is greater than the start of the subarray
                return null;
            } else {
                // Select axis based on depth so that axis cycles through all
                // valid values . (k is the dimensionality of the tree )
                d = depth % dimension;
            }

            medianOffSet = (left + right) / 2; //it sums up both the start and end subarray and divides by two

            // Put the median element in the correct position
            // This call assumes you have added the dimension d parameter
            // to jSmallest as described earlier .


            jSmallest(array, left, right, medianOffSet);

            // Create node and construct subtrees
            KDNode280 kdnodes;

            kdnodes = new KDNode280(array[medianOffSet]);
            kdnodes.setLeftNode(kdTree(array, left, medianOffSet - 1, depth + 1));
            kdnodes.setRightNode(kdTree(array, medianOffSet + 1, right, depth + 1));
            return kdnodes;

        } else {

            return null;
        }
    }


    /**
     * Position the smallest node in the list and in the correct position
     * @param list array of comparable elements
     * @param left offset of start of subarray for which we want the median element
     * @param right offset of end of subarray for which we want the median element
     * @param j is the element that belongs at array index j
     */
    protected void jSmallest(NDPoint280 [] list, int left, int right, int j ){
        if (right > left){
            // Partition the subarray using the last element , list [ right ], as a pivot .
            // The index of the pivot after partitioning is returned .
            // This is exactly the same partition algorithm used by quicksort .

            int pivotIndex;
            pivotIndex = partition(list, left, right, d); //call partition method
            // If the pivotIndex is equal to j, then we found the j-th smallest
            // element and it is in the right place ! Yay!
            // If the position j is smaller than the pivot index , we know that
            // the j-th smallest element must be between left , and pivotIndex -1, so
            // recursively look for the j-th smallest element in that subarray :

            if (j < pivotIndex)
                jSmallest(list, left, pivotIndex - 1,  j); //will be pivotIndex - 1 if j is less than the pivot
                // Otherwise , the position j must be larger than the pivotIndex ,
                // so the j-th smallest element must be between pivotIndex +1 and right .

            else if (j > pivotIndex)
                jSmallest(list, pivotIndex + 1, right, j); //will be pivotIndex + 1 if j is greater than the pivot
            // Otherwise , the pivot ended up at list [j], and the pivot *is* the
            // j-th smallest element and we ’re done.
        }
    }


    /**
     * Partition a subarray using its last element as a pivot
     * @param list array of comparable elements
     * @param left lower limit on subarray to be partitioned
     * @param right upper limit on subarray to be partitioned
     * @param d is the index of the value to compare with
     * @return the offset at which the pivot element ended up
     * @Precondition : all elements in ’list ’ are unique ( things get messy otherwise !)
     * @Postcondition : all elements smaller than the pivot appear in the leftmost
     * part of the subarray , then the pivot element , followed by
     * the elements larger than the pivot . There is no guarantee
     * about the ordering of the elements before and after the
     * pivot .
     */
    protected int partition(NDPoint280 [] list, int left, int right, int d){
        double pivot;
        pivot = list[right].idx(d); //start the pivot on the right

        int swapOffset;
        swapOffset = left;

        for (int i = left; i < right; i++){

            //checks the arr of the index value is less or equal to the pivot
            if (list[i].idx(d) <= pivot){
                swap(list, i, swapOffset); // will swap the item in the index i

                swapOffset = swapOffset + 1; //will move the swapOffset to the right

            }
        }

        swap(list, right, swapOffset);
        return swapOffset; // return the offset where the pivot ended up

    }


    /**
     * It swaps the items in the arr
     * @param list arr nd points
     * @param item0 first item
     * @param item1 second item
     */
    protected void swap(NDPoint280 [] list, int item0, int item1){
        NDPoint280 swap_item;

        //swap the items in the array
        swap_item = list[item0];
        list[item0] = list[item1];
        list[item1] = swap_item;

    }

    /**
     *Helper function for the find range to get the maximum and minimum points in the node
     * @param find_point is the linked list that stores the result
     * @param node is the kd node
     * @param minimum is the lowest point
     * @param maximum is the highest point
     */
    protected void Helperfuction(LinkedList<NDPoint280> find_point, KDNode280 node, NDPoint280 minimum, NDPoint280 maximum){
        if (node != null) { //checks if the node is not empty;

            if (differPoints(node.getItemPoint(), minimum) && differPoints(maximum, node.getItemPoint())) { //will compare both the maximum and minimum point in the node
                find_point.add(node.getItemPoint()); //will add the nd point linked list to the item node

                Helperfuction(find_point, node.getLeftNode(), minimum, maximum); //call the helper function and the left node
                Helperfuction(find_point, node.getRightNode(), minimum, maximum); //call the helper function and the right node
            } else { //otherwise
                List<KDNode280> alist; //represent the kd node list
                alist = Arrays.asList(node.getLeftNode(), node.getRightNode());
                int i = 0;
                while (i < alist.size()) { //checks if the size of the list is zero
                    KDNode280 kdNode280;
                    kdNode280 = alist.get(i);
                    Helperfuction(find_point, kdNode280, minimum, maximum); //call the helper function
                    i++;
                }
            }

        }}

    /**
     *
     * @param point1 the first point
     * @param point2 the second point
     * @return it returns true if the co-ordinates is big or equal
     * @throws InvalidArgument280Exception throws an error
     */
    protected boolean differPoints(NDPoint280 point1, NDPoint280 point2) throws InvalidArgument280Exception {

        boolean boo = true;

        //checks if the dimensional point is equal
        assert point1.dim() == point2.dim() : "Error: two points are different..";

        int i = 0;
        while (i < dimension) {

            if (!(point1.idx(i) < point2.idx(i))) //comparison of both points
                i++;
            else {
                return false; //it returns false if the second point is bigger than the first point
            }
        }

        return boo; //returns true
    }


    /**
     *  Is the string to be printed in the tree
     * @param node_string is the string of the node to be outputted
     * @param d is the depth
     */

    protected void toStringHeight(KDNode280 node_string, int d){

        String string;
        string = " "; //is the string in the node

        int i = 1;
        while (i < d) { //checks for the depth
            string = String.format("%s", string);
            i++;
        }
        if (node_string != null) { //it checks if the string is empty

            for (KDNode280 kdNode280 : Arrays.asList(node_string.getRightNode(), node_string.getLeftNode())) {

                toStringHeight(kdNode280, d + 1); //adds the depth of the tree by one
                System.out.println(string + d + ":" + node_string.toString()); //will then output the string
            }

        } else {
            System.out.println(string + d + ":"); //prints the string kd tree
        }

    }

    /**
     * It prints the kd tree
     */
    protected void toStringHeight(){
        toStringHeight(kdNode, 1);

    }

    /**
     * it finds the range between the highest and lowest point
     * @param minimum is the lowest point
     * @param maximum is the highest point
     * @return the list of the values been stored
     */
    protected LinkedList<NDPoint280> findRange(NDPoint280 minimum, NDPoint280 maximum){
        LinkedList<NDPoint280> find_point; //is thw linked list of the nd point 280
        find_point = new LinkedList<NDPoint280>();

        Helperfuction(find_point, kdNode, minimum, maximum); //call the helper function
        return find_point;

    }



    public static void main(String[] args) {
        //testing for the 2d points
        System.out.println("                                                            ");
        System.out.println("****************Testing for 2D Points***********************");
        System.out.println("                                                            ");

        System.out.println("Input two points: (5.0 , 2.0)\n" +
                "(9.0 , 10.0)\n" +
                "(11.0 , 1.0)\n" +
                "(4.0 , 3.0)\n" +
                "(2.0 , 12.0)\n" +
                "(3.0 , 7.0)\n" +
                "(1.0 , 5.0)" +
                "\n The 2D lib280 tree built from these points is:");

        NDPoint280[] nd = new NDPoint280[] {new NDPoint280(new double[]{5.0, 2.0}), new NDPoint280(new double[]{9.0, 10.0}), new NDPoint280(new double[]{11.0, 1.0}), new NDPoint280(new double[]{4.0, 3.0}),  new NDPoint280(new double[]{2.0, 12.0}), new NDPoint280(new double[]{3.0, 7.0}), new NDPoint280(new double[]{1.0, 5.0})};


        KDTree280 tree;
        tree = new KDTree280(nd, 2);

        tree.toStringHeight();

        //testing for the 3d points

        System.out.println("                                                            ");
        System.out.println("****************Testing for 3D Points***********************");
        System.out.println("                                                            ");

        System.out.println("Input two points: (1.0 , 12.0, 0.0)\n" +
                "(18.0 , 1.0 , 2.0)\n" +
                "(2.0 , 13.0 , 16.0)\n" +
                "(7.0 , 3.0 , 3.0)\n" +
                "(3.0 , 7.0 , 5.0)\n" +
                "(16.0 , 4.0 , 4.0)\n" +
                "(4.0 , 6.0 , 1.0)\n" +
                "(5.0 , 5.0 , 17.0)\n" +
                "-------------------");



        nd = new NDPoint280[] {new NDPoint280((new double[]{1.0, 12.0, 1.0})), new NDPoint280(new double[]{18.0, 1.0, 2.0}),
                new NDPoint280(new double[]{2.0, 12.0, 16.0}), new NDPoint280(new double[]{7.0, 3.0, 3.0}),
                new NDPoint280(new double[]{3.0, 7.0, 5.0}), new NDPoint280(new double[]{16.0, 4.0, 4.0}),
                new NDPoint280(new double[]{4.0, 6.0, 1.0}), new NDPoint280(new double[]{5.0, 5.0, 17.0})};


        KDTree280 kdtree;
        kdtree = new KDTree280(nd, 3);

        kdtree.toStringHeight();
        System.out.println("\n");


        System.out.println("Looking for points between (0.0 , 1.0 , 0.0) and (4.0 , 6.0 , 3.0). \nFound:");

        LinkedList<NDPoint280> parsePoint = kdtree.findRange(new NDPoint280(new double[]{0.0 , 1.0 , 0.0}), new NDPoint280(new double[]{4.0 , 6.0 , 3.0}));

        int i = 0, parsePointSize = parsePoint.size();

        while (i < parsePointSize) {
            NDPoint280 ndPoint280 = parsePoint.get(i);
            System.out.println(ndPoint280.toString());
            i++;
        }
        System.out.println("\n");

        System.out.println("Looking for points between (0.0 , 1.0 , 0.0) and (8.0 , 7.0 , 4.0). \nFound: ");
        parsePoint = kdtree.findRange(new NDPoint280(new double[]{0.0, 1.0,0.0}), new NDPoint280(new double[]{8.0 , 7.0 , 4.0}));

        int j = 0, pointSize = parsePoint.size();

        while (j < pointSize) {
            NDPoint280 point280 = parsePoint.get(j);
            String toString = point280.toString();
            System.out.println(toString);
            j++;
        }
        System.out.println("\n");

        System.out.println("Looking for points between (0.0 , 1.0 , 0.0) and (17.0 , 9.0 , 10.0). \nFound:");
        parsePoint = kdtree.findRange(new NDPoint280(new double[]{0.0 , 1.0 , 0.0}), new NDPoint280(new double[]{17.0 , 9.0 , 10.0}));

        int k = 0, size = parsePoint.size();

        while (k < size) {
            NDPoint280 point280 = parsePoint.get(k);
            String toString = point280.toString();
            System.out.println(toString);
            k++;
        }
    }

    }








