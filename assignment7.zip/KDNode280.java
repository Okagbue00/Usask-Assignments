import lib280.base.NDPoint280;

public class KDNode280 {
    /** The left node. */
    protected KDNode280 leftNode;
    /** The right node. */
    protected KDNode280 rightNode;
    /** Contents of the node Point. */
    protected NDPoint280 itemPoint;
    /** The parent of the node. */
    protected KDNode280 parent;


    /**
     * Creates a new node from the node Point
     * @param itemPoint node Point
     */
    protected KDNode280(NDPoint280 itemPoint){
        leftNode = null;
        rightNode = null;
        this.itemPoint = itemPoint;
    }


    protected NDPoint280 getItemPoint(){ return itemPoint;}

    /** The left node.
     *  @timing Time = O(1) */
    protected KDNode280 getLeftNode(){ return leftNode;}

    /** The right node.
     *  @timing Time = O(1) */
    protected KDNode280 getRightNode(){ return rightNode;}

    /**
     * Set the left child of this node
     * @param leftNode The new left child of this node.
     */
    protected void setLeftNode(KDNode280 leftNode){ this.leftNode = leftNode;}

    /**
     * Set the right child of this node
     * @param rightNode The new left child of this node.
     */
    protected void setRightNode(KDNode280 rightNode){ this.rightNode = rightNode; }

    /**
     * Checks if the node is empty
     * * @return kdnode if is empty */
    protected boolean isEmpty(){ return this.itemPoint == null;}

    /**
     * It gets the parent of the node
     * @return the parent node*/
    public KDNode280 getParent() { return parent;}

    public void setParent(KDNode280 node) { parent = node;}

    /**
     * Returns a string representation of the item contained within the node.
     */
    public String toString(){ return this.itemPoint.toString();}


}
