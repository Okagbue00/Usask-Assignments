

import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class Client {
    @WebServiceRef(wsdlLocation="http://localhost:8080/Server")


    public JFrame frame;
    public JLabel usernameLabel;
    public JPanel usernamePanel;
    public JLabel privateMessageLabel1;
    public static JTextArea myText;
    public static JTextArea otherText;
    public static JTextArea privateMessageUser;
    public static JTextArea usernameText;
    public JScrollPane myTextScroll;
    public JScrollPane otherTextScroll;
    public static JButton userConfirm;
    public static JRadioButton privateMessageButton;
    public static TextThread otherTextThread;
    public String textString = "";
    public static String user = "";
    public Boolean private_boolean = false;

    private static final int HOR_SIZE = 350;
    private static final int VER_SIZE = 150;

    private ChatServerService service;
    private Server port;
    private int id;


    private void initComponents(String host) {
        frame = new JFrame("REST API Client Chat-box");
        myText = new JTextArea();
        frame.setResizable(false);

        myTextScroll = new JScrollPane(myText);
        myTextScroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        myTextScroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        myTextScroll.setMaximumSize(
                new java.awt.Dimension(HOR_SIZE, VER_SIZE));
        myTextScroll.setMinimumSize(new java.awt.Dimension(HOR_SIZE, VER_SIZE));
        myTextScroll.setPreferredSize(new java.awt.Dimension(
                HOR_SIZE, VER_SIZE));
        myText.setEditable(false);
        myText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                textTyped(evt);
            }
        });
        frame.getContentPane().add(myTextScroll, java.awt.BorderLayout.CENTER);

        otherText = new JTextArea();

        otherTextScroll = new JScrollPane(otherText);
        otherText.setBackground(new java.awt.Color(200, 200, 200));
        otherTextScroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        otherTextScroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        otherTextScroll.setMaximumSize(
                new java.awt.Dimension(HOR_SIZE, VER_SIZE));
        otherTextScroll.setMinimumSize(
                new java.awt.Dimension(HOR_SIZE, VER_SIZE));
        otherTextScroll.setPreferredSize(new java.awt.Dimension(
                HOR_SIZE, VER_SIZE));
        otherText.setEditable(false);

        frame.getContentPane().add(otherTextScroll,
                java.awt.BorderLayout.SOUTH);


        usernamePanel = new JPanel();
        usernamePanel.setPreferredSize(new Dimension(90,75));
        usernameText = new JTextArea(1,10);
        usernameText.setPreferredSize(new Dimension(10,10));
        usernameText.setLineWrap(true);
        usernameText.setWrapStyleWord(true);

        usernameLabel = new JLabel("Username:-");

        userConfirm = new JButton("Confirm");

        usernamePanel.add(usernameLabel);
        usernamePanel.add(usernameText);
        usernamePanel.add(userConfirm);


        userConfirm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                if(usernameText.getText().length() != 0){
                    myText.setEditable(true);
                    privateMessageUser.setEditable(true);
                    usernameText.setEditable(false);
                    user = usernameText.getText();
                    startServer(user);
                }
            }
        });

        privateMessageLabel1 = new JLabel("Private Message User:");
        usernamePanel.add(privateMessageLabel1);

        privateMessageUser = new JTextArea(1,10);
        privateMessageUser.setPreferredSize(new Dimension(10,10));
        usernamePanel.add(privateMessageUser);
        privateMessageUser.setEditable(false);

        privateMessageButton = new JRadioButton("Switch on Private message");
        usernamePanel.add(privateMessageButton);

        privateMessageButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                if (!privateMessageButton.isSelected()) {
                    if (!privateMessageButton.isSelected()) {
                        private_boolean = false;
                    }
                } else {
                    private_boolean = true;
                }
            }
        });

        frame.getContentPane().add(usernamePanel, java.awt.BorderLayout.NORTH);
        frame.pack();
        frame.setVisible(true);

    }

    private void startServer(String userString){
        try {
            // Start the server
            service = new Chatserver.ChatServerService();
            port = service.getChatServerPort();
            port.ServerJoin(userString);
            port.ServerTalk(userString + " : Has joined");
            otherTextThread = new TextThread(otherText, id , port);
            otherTextThread.start();

            frame.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    try {
                        port.ServerTalk(user + " has Left");
                        port.ServerLeave(user);
                    }
                    catch (Exception ex) {
                        otherText.append("Failed to leave...");
                    }
                    System.exit(0);
                }
            });
        }
        catch (Exception ex) {
            otherText.append("Cannot connect to the server");
        }
    }

    private void textTyped(java.awt.event.KeyEvent evt) {
        char c = evt.getKeyChar();
        if ('\n' != c) {
            textString = textString + c;
        } else {
            try {
                if (private_boolean) {
                    port.privateMessage(privateMessageUser.getText(), user, textString);
                    myText.setText("");
                } else {
                    port.ServerTalk(user + " : " + textString);
                    myText.setText("");
                }
            }
            catch (Exception ie) {
                otherText.append("Failed to send message.");
            }
            textString = "";
        }
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        final String host = "localhost";
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            final Client client = new Client();
            public void run() {
                client.initComponents(host);
            }
        });

    }
    public static String getUsername() {
        return user;
    }
}

//
class TextThread extends Thread {
    JTextArea otherText;
    int id;
    Server port;

    TextThread(JTextArea other, int id, Server port) throws IOException
    {
        otherText = other;
        this.id = id;
        this.port = port;
    }

    public void run() {
        while (true) {
            try {
                // Send the username to the listen method
                String newText = port.ServerListen(Client.getUsername());
                if (!newText.equals("")) {
                    otherText.append(newText + "\n");
                    Thread.sleep(1000);
                } else {
                    Thread.sleep(1000);
                }
            }
            catch (Exception e) {
                otherText.append("Error reading from server.");
            }
        }
    }
}