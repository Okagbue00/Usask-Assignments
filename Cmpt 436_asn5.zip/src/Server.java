
import java.util.*;
import javax.jws.WebService;
import javax.jws.WebMethod;


@WebService
public class Server {
    //i created a hashtable for both the users and the message box
    private static Hashtable<String, String> users = new Hashtable<String, String>();


    @WebMethod
    public void ServerJoin(String user){
        users.put(user, "");
    }

    @WebMethod
    public void ServerTalk(String message){
        users.keySet().forEach(users -> {
            Server.users.get(users);
            Server.users.put(users, message); //it adds messages to the users
        });
    }

    @WebMethod
    public String ServerListen(String user) {
        String user_message = users.get(user);
        users.put(user, "");
        return user_message;
    }


    @WebMethod
    public void ServerLeave(String user){
        users.remove(user); //user leaves the chatroom console
    }

    @WebMethod
    public void privateMessage (String userToSendTo, String user, String message){
        if (!users.containsKey(userToSendTo)) {
            if(!users.containsKey(userToSendTo)){
                users.put(user, "Error:-  " + userToSendTo +  "not in the server...");
            }
        }
        users.put(userToSendTo, user + "Private message:-" + message);
        users.put(user, user + " Private message : " + message);
    }

}

