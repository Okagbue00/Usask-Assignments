package lib280.dispenser;

import lib280.exception.ContainerFull280Exception;
import lib280.exception.NoCurrentItem280Exception;
import lib280.tree.ArrayedBinaryTreeIterator280;
import lib280.tree.IterableArrayedHeap280;

import static java.util.stream.IntStream.range; //returns a sequential ordered int stream

public class PriorityQueue280<I extends Comparable<? super I>> {
	
	// This is the heap that we are restricting.
	// Items in the priority queue get stored in the heap.
	protected IterableArrayedHeap280<I> items;

	public ArrayedBinaryTreeIterator280<I> cursor;
	public I priority;
	public boolean test = true;
	public I min_number;




	/**
	 * Create a new priorty queue with a given capacity.
	 * @param cap The maximum number of items that can be in the queue.
	 */
	public PriorityQueue280(int cap) {
		items = new IterableArrayedHeap280<I>(cap);
	}
	
	public String toString() {
		return items.toString();	
	}

	// TODO
	// Add Priority Queue ADT methods (from the specification) here.

	public void createNewPriority(I n){
		/**
		 * created a new queue with capacity n
		 */
	}

	public void insert(I g) throws ContainerFull280Exception{
		/**
		 *it inserts a new g into t in priority order with the highest priority
		 * @throws ContainerFull280Exception: if the queue is empty
		 */
		if (isFull()) throw new ContainerFull280Exception("queue is empty");
		else
		items.insert(g); //inserts item g into the queue

	}

	public boolean isFull(){
		/**
		 * It will return true if full and false otherwise
		 */
		if (items.isFull())
			return true;
		else
	return false;
	}

	public boolean isEmpty(){
		/**
		 * It will return true if is empty and false otherwise
		 */
		if (items.isEmpty())
			return true;
		else
		return false;
	}

	public int count(){
		/**
		 * It will obtain the number of items in the queue
		 */
		if (isEmpty()) throw new NoCurrentItem280Exception("queue is empty.");
		return (items.count());
	}

	private I maxItem(){

		/**
		 * It will return the highest priority in the queue
		 * @return will return the largest item
		 */
		if (isEmpty()) throw new NoCurrentItem280Exception("queue is empty.");
		I result;


		cursor = items.iterator280(); //assign cursor to be the iterator of the queue
		cursor.goFirst(); //will go the first item
		cursor.before(); //and check correct position at the start
		return cursor.item(); //returns the highest item
	}

	private I minItem() {

		/**
		 * It will compute for the minimum item in the queue that has the lowest priority
		 * @return will return the smallest item
		 */
		I result;
		if (isEmpty()) throw new NoCurrentItem280Exception("queue is empty.");

		else {  cursor = items.iterator280();


		cursor.goFirst(); //assigns the variable to the first item in the queue


			min_number = cursor.item();

			range(1, items.count()).forEachOrdered(this::accept);


		}
		return min_number; //returns the smallest item in the queue
	}


	public void deleteMax(){
		/**
		 * It will remove the highest priority in the queue
		 */
		if (isEmpty()) throw new NoCurrentItem280Exception("queue is empty.");
		items.deleteItem(); //will delete the item with the highest priority

	}

	public void deleteMin() {
		/**
		 * It will remove the lowest priority in the queue
		 */

			if (isEmpty()) throw new NoCurrentItem280Exception("queue is empty.");
		else {
			deleteMinHelper(); //called my delete min helper function
			}}





	public void deleteAllMax(){
		/**
		 * It will check the highest priority item deleted from the queue
		 */
		if (isEmpty()) throw new NoCurrentItem280Exception("queue is empty.");

		priority = maxItem(); //assign to be the highest priority

		while (!(items.isEmpty() || priority.compareTo(maxItem()) != 0)){ //check for the highest item
			deleteMax(); //delete the highest priority
		}

	}

	public void deleteMinHelper(){

		cursor = items.iterator280(); //assigned my cursor to be the item in the iterator

		int item;
		cursor.goFirst(); //then the cursor will go the first item in the queue

		int small;
		assert items != null; //will throw an error if the item is not empty
		small = items.count() >> 1; //used bitwise to get the items count in the queue


		boolean test = true;
		for (int y = 1; y <= small; y++) {
			cursor.goFirst(); //will then go the first item in the queue

		}

		min_number = cursor.item(); //assigned my min number to be the items in the cursor


		item = 1 + small; //stored in my variable item

		cursor.goBefore();//will move the cursor to the first position

		for (int y = 1; y <= item; y++) cursor.goForth(); //will then advance one item in the cursor

		test = false;

		items.deleteAtPosition(); //will then delete the lowest priority in my queue
	}





	

	//UNCOMMENT THE REGRESSION TEST WHEN YOU ARE READY

	public static void main(String args[]) {
		class PriorityItem<I> implements Comparable<PriorityItem<I>> {
			final I item;
			final Double priority;

			public PriorityItem(I item, Double priority) {
				super();
				this.item = item;
				this.priority = priority;
			}

			public int compareTo(PriorityItem<I> o) {
				return this.priority.compareTo(o.priority);
			}

			public String toString() {
				return this.item + ":" + this.priority;
			}
		}

		PriorityQueue280<PriorityItem<String>> Q = new PriorityQueue280<PriorityItem<String>>(5);

		// Test isEmpty()
		if( !Q.isEmpty())
			System.out.println("Error: Queue is empty, but isEmpty() says it isn't.");

		// Test insert() and maxItem()
		Q.insert(new PriorityItem<String>("Sing", 5.0));
		if( Q.maxItem().item.compareTo("Sing") != 0) {
			System.out.println("??Error: Front of queue should be 'Sing' but it's not. It is: " + Q.maxItem().item);
		}

		// Test isEmpty() when queue not empty
		if( Q.isEmpty())
			System.out.println("Error: Queue is not empty, but isEmpty() says it is.");

		// test count()
		if( Q.count() != 1 ) {
			System.out.println("Error: Count should be 1 but it's not.");
		}

		// test minItem() with one element
		if( Q.minItem().item.compareTo("Sing")!=0) {
			System.out.println("Error: min priority item should be 'Sing' but it's not.");
		}

		// insert more items
		Q.insert(new PriorityItem<String>("Fly", 5.0));
		if( Q.maxItem().item.compareTo("Sing")!=0) System.out.println("Front of queue should be 'Sing' but it's not.");
		Q.insert(new PriorityItem<String>("Dance", 3.0));
		if( Q.maxItem().item.compareTo("Sing")!=0) System.out.println("Front of queue should be 'Sing' but it's not.");
		Q.insert(new PriorityItem<String>("Jump", 7.0));
		if( Q.maxItem().item.compareTo("Jump")!=0) System.out.println("Front of queue should be 'Jump' but it's not.");

		if(Q.minItem().item.compareTo("Dance") != 0) System.out.println("minItem() should be 'Dance' but it's not.");

		if( Q.count() != 4 ) {
			System.out.println("Error: Count should be 4 but it's not.");
		}

		// Test isFull() when not full
		if( Q.isFull())
			System.out.println("Error: Queue is not full, but isFull() says it is.");

		Q.insert(new PriorityItem<String>("Eat", 10.0));
		if( Q.maxItem().item.compareTo("Eat")!=0) System.out.println("Front of queue should be 'Eat' but it's not.");

		if( !Q.isFull())
			System.out.println("Error: Queue is full, but isFull() says it isn't.");

		// Test insertion on full queue
		try {
			Q.insert(new PriorityItem<String>("Sleep", 15.0));
			System.out.println("Expected ContainerFull280Exception inserting to full queue but got none.");
		}
		catch(ContainerFull280Exception e) {
			// Expected exception
		}
		catch(Exception e) {
			System.out.println("Expected ContainerFull280Exception inserting to full queue but got a different exception.");
			e.printStackTrace();
		}

		// test deleteMin
		Q.deleteMin();
		if(Q.minItem().item.compareTo("Sing") != 0) System.out.println("Min item should be 'Sing', but it isn't.");

		Q.insert(new PriorityItem<String>("Dig", 1.0));
		if(Q.minItem().item.compareTo("Dig") != 0) System.out.println("minItem() should be 'Dig' but it's not.");

		// Test deleteMax
		Q.deleteMax();
		if( Q.maxItem().item.compareTo("Jump")!=0) System.out.println("Front of queue should be 'Jump' but it's not.");

		Q.deleteMax();
		if( Q.maxItem().item.compareTo("Fly")!=0) System.out.println("Front of queue should be 'Fly' but it's not.");

		if(Q.minItem().item.compareTo("Dig") != 0) System.out.println("minItem() should be 'Dig' but it's not.");

		Q.deleteMin();
		if( Q.maxItem().item.compareTo("Fly")!=0) System.out.println("Front of queue should be 'Fly' but it's not.");

		Q.insert(new PriorityItem<String>("Scream", 2.0));
		Q.insert(new PriorityItem<String>("Run", 2.0));

		if( Q.maxItem().item.compareTo("Fly")!=0) System.out.println("Front of queue should be 'Fly' but it's not.");

		// test deleteAllMax()
		Q.deleteAllMax();
		if( Q.maxItem().item.compareTo("Scream")!=0) System.out.println("Front of queue should be 'Scream' but it's not.");
		if( Q.minItem().item.compareTo("Scream") != 0) System.out.println("minItem() should be 'Scream' but it's not.");
		Q.deleteAllMax();

		// Queue should now be empty again.
		if( !Q.isEmpty())
			System.out.println("Error: Queue is empty, but isEmpty() says it isn't.");

		System.out.println("Regression test complete.");
	}


	private void accept(int y) {

		cursor.goForth();
		if (cursor.item().compareTo(min_number) < 0) {
			min_number = cursor.item();
		}
	}
}
