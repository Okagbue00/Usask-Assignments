import com.opencsv.CSVReader;
import lib280.base.Pair280;
import lib280.hashtable.KeyedChainedHashTable280;
import lib280.tree.OrderedSimpleTree280;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

// This project uses a JAR called opencsv which is a library for reading and
// writing CSV (comma-separated value) files.
// 
// You don't need to do this for this project, because it's already done, but
// if you want to use opencsv in other projects on your own, here's the process:
//
// 1. Download opencsv-3.1.jar from http://sourceforge.net/projects/opencsv/
// 2. Drag opencsv-3.1.jar into your project.
// 3. Right-click on the project in the package explorer, select "Properties" (at bottom of popup menu)
// 4. Choose the "Libraries" tab
// 5. Click "Add JARs"
// 6. Select the opencsv-3.1.jar from within your project from the list.
// 7. At the top of your .java file add the following imports:
//        import java.io.FileReader;
//        import com.opencsv.CSVReader;
//
// Reference documentation for opencsv is here:  
// http://opencsv.sourceforge.net/apidocs/overview-summary.html


public class QuestLog extends KeyedChainedHashTable280<String, QuestLogEntry> {

	LinkedList<String> string = new LinkedList<>();

	//private int num;



	public QuestLog() {
		super();
	}

	/**
	 * Obtain an array of the keys (quest names) from the quest log.  There is
	 * no expectation of any particular ordering of the keys.
	 *
	 * @return The array of keys (quest names) from the quest log.
	 */
	public String[] keys() {
		// TODO Implement this method.
		String[] str;

		AtomicInteger num = new AtomicInteger(); //created a new atomic integer to represent num
		int quest = count;
		while (!(quest <= 0b0)){ //check if the quest linked list is not equal to zero

			findNextItem(num.get()); //will go to the first item of the worst case

			num.set(0b1 + hashPos(item().key())); //then will add one to the sets the key of the item of the hashtable
			do { //check the do while loop; if the item exists in the correct location
				if (!itemListLocation.itemExists())
					//System.out.println("break out from the loop");
				{
					break; //will break out from the loop
				}

				boolean add = string.add(item().getQuestName());
				quest = quest - 0b1; //will decrease the quest
				itemListLocation.goForth(); //will advance one item in the list location of the item
			} while (!(false)); //will check the while loop is true and then breaks out

		}
		str = new String[string.size()]; //assized my str to be the size of the string

		String[] strings;

		strings = string.<String>toArray(str); //get the keys in array

		return strings; //will then return the array of the keys

		//return null;  // Remove this line you're ready.  It's just to prevent compiler errors.
	}

	/**
	 * Format the quest log as a string which displays the quests in the log in
	 * alphabetical order by name.
	 *
	 * @return A nicely formatted quest log.
	 */
	public String toString() {
		// TODO Implement this method.

		String[] string = keys(); //gets the keys of the log in array

		Arrays.sort(string); //will format the ques log in alphabetical order

		return ""; //returned the quest log well formatted
	}




		// Remove this line you're ready.  It's just to prevent compiler errors.
		//return "QuestLog.toString() not implemented yet!\n";

	/**
	 * Obtain the quest with name k, while simultaneously returning the number of
	 * items examined while searching for the quest.
	 * @param k Name of the quest to obtain.
	 * @return A pair in which the first item is the QuestLogEntry for the quest named k, and the
	 *         second item is the number of items examined during the search for the quest named k.
	 *         Note: if no quest named k is found, then the first item of the pair should be null.
	 */
	public Pair280<QuestLogEntry, Integer> obtainWithCount(String k) {
		// TODO Implement this method.
		int count;

		var quest = hashPos(k); //assigned quest to be the name of the quest to obtain in the hashtable

		findNextItem(quest); //goes to the first item and if no found, jumps to goAfter to search for the next item

		QuestLogEntry quest_log; //extended my quest log entry to store it into quest_log

		quest_log = null; //then set the quest log to be empty; to contain empty stuffs




		count = 0b0; //assigned my count to be 0 in binary form
		if (itemListLocation.itemExists()) { //will check if the item exists in the list location

			do {

				count = count + 1; //will then increase it by one
				if (!Objects.equals(this.item().getQuestName(), k)) { //conditional statement to check if the quest returns the number of items

					itemListLocation.goForth(); //will then advance one item in the list location
				} else { //otherwise
					quest_log = item(); //quest_log will be the items the log
					//System.out.println("Breaking out of the loop");
					break; //exit from the loop

				}
			} while (itemListLocation.itemExists());

		}
		return new Pair280<>(quest_log, count); //returns the pair of the item in the quest log
	}


	// Write a method that returns a Pair280 which contains the quest log entry with name k,
		// and the number QuestLogEntry objects that were examined in the process.  You need to write
		// this method from scratch without using any of the superclass methods (mostly because
		// the superclass methods won't be terribly useful unless you can modify them, which you
		// aren't allowed to do!).


		//return null;  // Remove this line you're ready.  It's just to prevent compiler errors.

	
	
	public static void main(String args[])  {
		// Make a new Quest Log
		QuestLog hashQuestLog = new QuestLog();
		
		// Make a new ordered binary lib280.tree.
		OrderedSimpleTree280<QuestLogEntry> treeQuestLog =
				new OrderedSimpleTree280<QuestLogEntry>();
		
		
		// Read the quest data from a CSV (comma-separated value) file.
		// To change the file read in, edit the argument to the FileReader constructor.
		CSVReader inFile;
		try {
			//input filename on the next line - path must be relative to the working directory reported above.
			inFile = new CSVReader(new FileReader("/Users/francis/IdeaProjects/A5/src/QuestLog-Template/quests4.csv"));
		} catch (FileNotFoundException e) {
			System.out.println("Error: File not found.");
			return;
		}
		
		String[] nextQuest;
		try {
			// Read a row of data from the CSV file
			while ((nextQuest = inFile.readNext()) != null) {
				// If the read succeeded, nextQuest is an array of strings containing the data from
				// each field in a row of the CSV file.  The first field is the quest name,
				// the second field is the quest region, and the next two are the recommended
				// minimum and maximum level, which we convert to integers before passing them to the
				// constructor of a QuestLogEntry object.
				QuestLogEntry newEntry = new QuestLogEntry(nextQuest[0], nextQuest[1], 
						Integer.parseInt(nextQuest[2]), Integer.parseInt(nextQuest[3]));
				// Insert the new quest log entry into the quest log.
				hashQuestLog.insert(newEntry);
				treeQuestLog.insert(newEntry);
			}
		} catch (IOException e) {
			System.out.println("Something bad happened while reading the quest information.");
			e.printStackTrace();
		}
		
		// Print out the hashed quest log's quests in alphabetical order.
		// COMMENT THIS OUT when you're testing the file with 100,000 quests.  It takes way too long.
		System.out.println(hashQuestLog);
		
		// Print out the lib280.tree quest log's quests in alphabetical order.
		// COMMENT THIS OUT when you're testing the file with 100,000 quests.  It takes way too long.
	    System.out.println(treeQuestLog.toStringInorder());
		





		// TODO Determine the average number of elements examined during access for hashed quest log.

		//Arrays.stream ---> is to get the sequential stream from the array passed as the parameter with its element.

		String[] questLog4; //assigned the variable to be a string
		questLog4 = hashQuestLog.keys(); //and then be the hash quest keys in the log
		double quest = Arrays.stream(questLog4).mapToDouble(str -> hashQuestLog.obtainWithCount(str).secondItem()).sum(); //will return a double stream consisting of the result

		System.out.println("Avg # of items examined per query in the hashed quest log with 4 entries :" + quest/8); //prints out the average items in the hash quest when is; will then divide it by 8. so each quest is quest*2; 4*2 = 8


		// (call hashQuestLog.obtainWithCount() for each quest in the log and find average # of access)
		
		
		// TODO Determine the average number of elements examined during access for lib280.tree quest log.
		//String[] questLog4;
		//treeLog = hashQuestLog.keys();
		double avg_log = Arrays.stream(questLog4).mapToDouble(str -> treeQuestLog.searchCount(hashQuestLog.obtainWithCount(str).firstItem())).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 4 entries :" + avg_log/8);
	    // (call treeQuestLog.searchCount() for each quest in the log and find average # of access)



		/*
		String[] questLog16;
		questLog16 = hashQuestLog.keys();
		double quest = Arrays.stream(questLog16).mapToDouble(str -> hashQuestLog.obtainWithCount(str).secondItem()).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 16 entries :" + quest/32);


		// (call hashQuestLog.obtainWithCount() for each quest in the log and find average # of access)




		double avg_log = Arrays.stream(questLog16).mapToDouble(str -> treeQuestLog.searchCount(hashQuestLog.obtainWithCount(str).firstItem())).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 16 entries :" + avg_log/32);
		// (call treeQuestLog.searchCount() for each quest in the log and find average # of access) */



		/*
		String[] questLog250;
		questLog250 = hashQuestLog.keys();
		double quest = Arrays.stream(questLog250).mapToDouble(str -> hashQuestLog.obtainWithCount(str).secondItem()).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 250 entries :" + quest/500);


		// (call hashQuestLog.obtainWithCount() for each quest in the log and find average # of access)




		double avg_log = Arrays.stream(questLog250).mapToDouble(str -> treeQuestLog.searchCount(hashQuestLog.obtainWithCount(str).firstItem())).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 250 entries :" + avg_log/500);
		// (call treeQuestLog.searchCount() for each quest in the log and find average # of access) */

		//  TODO Determine the average number of elements examined during access for hashed quest log.


		/*String[] questLog1000;
		questLog1000 = hashQuestLog.keys();
		double quest = Arrays.stream(questLog1000).mapToDouble(str -> hashQuestLog.obtainWithCount(str).secondItem()).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 1000 entries :" + quest/2000);


		// (call hashQuestLog.obtainWithCount() for each quest in the log and find average # of access)


		// TODO Determine the average number of elements examined during access for lib280.tree quest log.

		double avg_log = Arrays.stream(questLog1000).mapToDouble(str -> treeQuestLog.searchCount(hashQuestLog.obtainWithCount(str).firstItem())).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 1000 entries :" + avg_log/2000);
		// (call treeQuestLog.searchCount() for each quest in the log and find average # of access) */

		// TODO Determine the average number of elements examined during access for hashed quest log.


		/*String[] questLog100000;
		questLog100000 = hashQuestLog.keys();
		double quest = Arrays.stream(questLog100000).mapToDouble(str -> hashQuestLog.obtainWithCount(str).secondItem()).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 100000 entries :" + quest/200000);


		// (call hashQuestLog.obtainWithCount() for each quest in the log and find average # of access)


		// TODO Determine the average number of elements examined during access for lib280.tree quest log.

		double avg_log = Arrays.stream(questLog100000).mapToDouble(str -> treeQuestLog.searchCount(hashQuestLog.obtainWithCount(str).firstItem())).sum();

		System.out.println("Avg # of items examined per query in the hashed quest log with 100000 entries :" + avg_log/200000);
		// (call treeQuestLog.searchCount() for each quest in the log and find average # of access) */

	}
	
	
}
