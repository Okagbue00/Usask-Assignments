package lib280.tree;

import lib280.exception.ContainerFull280Exception;
import lib280.exception.NoCurrentItem280Exception;

public class IterableArrayedHeap280<I extends Comparable<? super I>> extends ArrayedHeap280<I> {







	/**
	 * Create an iterable heap with a given capacity.
	 *
	 * @param cap The maximum number of elements that can be in the heap.
	 */
	public IterableArrayedHeap280(int cap) {
		super(cap);

	}

	// TODO
	// Add iterator() and deleteAtPosition() methods here.

	/**
	 *Is going to remove the item position at the iterator
	 * @throws ContainerFull280Exception if the heap is empty
	 * @throws NoCurrentItem280Exception going check is the heap does not contain any item
	 */
	public void deleteAtPosition() throws ContainerFull280Exception, NoCurrentItem280Exception {

		if (isEmpty()) //check if the heap is empty
			throw new NoCurrentItem280Exception("Cannot delete an item from an empty heap.");

		if (count <= currentNode) throw new ContainerFull280Exception("item is not in the heap.");

		// Delete the root by moving in the last item.
		// If there is more than one item, and we aren't deleting the last item,
		// copy the last item in the array to the current position.

		items[currentNode] = items[count()];
		this.count--;

		// If we deleted the last remaining item, make the the current item invalid, and we're done.
		if (this.count == 0) {
			this.currentNode = 0;
			return;
		}

		// Propagate the new root down the lib280.tree.
		int n = 1;

		// While offset n has a left child...
		while (findLeftChild(n) <= count) {
			// Select the left child.
			int child = findLeftChild(n);

			// If the right child exists and is larger, select it instead.
			if (child + 1 <= count && items[child].compareTo(items[child + 1]) < 0)
				child++;

			// If the parent is smaller than the root...
			if (items[n].compareTo(items[child]) < 0) {
				// Swap them.
				I temp = items[n];
				items[n] = items[child];
				items[child] = temp;
				n = child;
			} else return;

		}
	}

	// Add iterator()
	

	/**
	 *The iterator280 of the arrayed binary tree iterator 280.
	 * @return Going to return the ArrayedBinaryTreeIterator280 of the heap in the iterator280
	 */
	public   ArrayedBinaryTreeIterator280<I> iterator280(){
		ArrayedBinaryTreeIterator280<I> iterator;
		iterator = new ArrayedBinaryTreeIterator280<I>(true); //passed the true as parameter.
		return iterator; //returned the arrayed binary tree iterator of the heap.

}}