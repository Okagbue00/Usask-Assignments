/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.util.Pair;

public class SMItem {
    protected double x;
    protected double y;
    protected double width;
    protected double height;

    public SMItem(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public double getWidth() { return width; }

    public double getHeight() {
        return height;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getCenterX() { return x + width / 2; }

    public double getCenterY() { return y + height / 2; }

    public void setWidth(double newWidth) {
        width = newWidth;
    }

    public void setHeight(double newHeight) {
        height = newHeight;
    }

    public void setX(double newX) {
        x = newX;
    }

    public void setY(double newY) {
        y = newY;
    }

    public boolean contains(double mx, double my) {
        return x <= mx && mx <= (x + width) && y <= my && my <= (y + height);
    }

    public Pair<Double, Double> getIntersection(double x1, double y1) {
        // Compute the intersection
        double top = y;
        double bottom = y + height;
        double left = x;
        double right = x + width;

        // Get central coordinates
        double x2 = getCenterX();
        double y2 = getCenterY();

        // Get four possible intersections
        // Check with left edge
        if (x1 <= left) {
            double intY = y1 + (y2 - y1) / (x2 - x1) * (left - x1);
            if (top <= intY && intY <= bottom) {
                return new Pair<>(left, intY);
            }
        } else {
            // Check with right edge
            double intY = y1 + (y2 - y1) / (x2 - x1) * (right - x1);
            if (top <= intY && intY <= bottom) {
                return new Pair<>(right, intY);
            }
        }

        // Check with top edge
        if (y1 <= top) {
            double intX = x1 + (x2 - x1) / (y2 - y1) * (top - y1);
            if (left <= intX && intX <= right) {
                return new Pair<>(intX, top);
            }
        } else {
            // Check with bottom edge
            double intX = x1 + (x2 - x1) / (y2 - y1) * (bottom - y1);
            if (left <= intX && intX <= right) {
                return new Pair<>(intX, bottom);
            }
        }

        // No intersection on any edge
        // Return the center point instead
        return new Pair<>(getCenterX(), getCenterY());
    }
}
