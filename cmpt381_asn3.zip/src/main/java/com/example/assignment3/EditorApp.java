/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class EditorApp extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Build the components
        SMModel model = new SMModel();
        InteractionModel iModel = new InteractionModel();
        AppController controller = new AppController(model, iModel);

        // Create the UI
        MainUI ui = new MainUI(600, 600, controller);
        Scene scene = new Scene(ui);

        // Set the scene and stage
        stage.setScene(scene);
        stage.setTitle("State Machine Editor");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}