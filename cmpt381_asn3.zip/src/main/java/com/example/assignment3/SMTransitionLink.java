/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

/**
 * State machine transition link class
 */
public class SMTransitionLink extends SMItem {
    SMStateNode from = null;
    SMStateNode to = null;
    String event;
    String context;
    String sideEffects;

    public SMTransitionLink(SMStateNode fromNode, SMStateNode toNode, String event, String context, String sideEffects, double width, double height, double centerX, double centerY) {
        super(centerX - width / 2, centerY - height / 2, width, height);
        from = fromNode;
        to = toNode;
        this.event = event;
        this.context = context;
        this.sideEffects = sideEffects;
    }

    public String getEvent() {
        return event;
    }

    public String getContext() {
        return context;
    }

    public String getSideEffects() {
        return sideEffects;
    }

    public String getDetails() {
        return "- Event:\n" + event + "\n- Context:\n" + context + "\n- Side Effects:\n" + sideEffects;
    }

    public SMStateNode getFrom() {
        return from;
    }

    public SMStateNode getTo() {
        return to;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public void setSideEffects(String sideEffects) {
        this.sideEffects = sideEffects;
    }
}
