/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

public interface SMModelSubscriber {
    void modelChanged();
}
