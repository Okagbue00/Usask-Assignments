/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.net.URL;

public class ToolPalette extends VBox implements InteractionModelSubscriber {
    AppController controller;
    Button arrowBtn;
    Button panBtn;
    Button linkBtn;
    ImageView pointerImg;
    ImageView moveImg;
    ImageView crossImg;

    String activeButtonStyle = "-fx-background-color: #21b1a7; -fx-padding: 8;";
    String inactiveButtonStyle = "-fx-background-color: #21b1a7; -fx-padding: 4;";
    public ToolPalette(AppController appController) {
        controller = appController;

        // Load images
        pointerImg = new ImageView(new Image(ToolPalette.class.getClassLoader().getResource("pointer_icon.png").toString()));
        pointerImg.setFitHeight(24);
        pointerImg.setPreserveRatio(true);

        moveImg = new ImageView(new Image(ToolPalette.class.getClassLoader().getResource("move_icon.png").toString()));
        moveImg.setFitHeight(24);
        moveImg.setPreserveRatio(true);

        crossImg = new ImageView(new Image(ToolPalette.class.getClassLoader().getResource("cross_icon.png").toString()));
        crossImg.setFitHeight(24);
        crossImg.setPreserveRatio(true);

        // Create the buttons;
        arrowBtn = new Button();
        arrowBtn.setGraphic(pointerImg);
        arrowBtn.setStyle(inactiveButtonStyle);
        panBtn = new Button();
        panBtn.setGraphic(moveImg);
        panBtn.setStyle(inactiveButtonStyle);
        linkBtn = new Button();
        linkBtn.setGraphic(crossImg);
        linkBtn.setStyle(inactiveButtonStyle);

        setSpacing(4);
        setAlignment(Pos.TOP_CENTER);

        setBackground(Background.fill(Color.rgb(243, 243, 243)));

        getChildren().add(arrowBtn);
        getChildren().add(panBtn);
        getChildren().add(linkBtn);

        attachListeners();
    }

    protected void attachListeners() {
        controller.getInteractionModel().addSubscriber(this);
        arrowBtn.setOnAction(e -> controller.getInteractionModel().setCurrentTool(InteractionModel.Tool.ARROW));
        panBtn.setOnAction(e -> controller.getInteractionModel().setCurrentTool(InteractionModel.Tool.PAN));
        linkBtn.setOnAction(e -> controller.getInteractionModel().setCurrentTool(InteractionModel.Tool.LINK));
    }

    @Override
    public void iModelChanged() {
        // Change the size of the selected button
        arrowBtn.setStyle(inactiveButtonStyle);
        panBtn.setStyle(inactiveButtonStyle);
        linkBtn.setStyle(inactiveButtonStyle);

        switch (controller.getInteractionModel().getCurrentTool()) {
            case ARROW -> arrowBtn.setStyle(activeButtonStyle);
            case PAN -> panBtn.setStyle(activeButtonStyle);
            case LINK -> linkBtn.setStyle(activeButtonStyle);
        }

        // Change the cursor
        if (getScene() != null) {
            switch (controller.getInteractionModel().getCurrentTool()) {
                case ARROW -> getScene().setCursor(Cursor.DEFAULT);
                case PAN -> getScene().setCursor(Cursor.MOVE);
                case LINK -> getScene().setCursor(Cursor.CROSSHAIR);
            }
        }
    }
}
