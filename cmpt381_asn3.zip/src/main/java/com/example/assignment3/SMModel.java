/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * State machine model
 */
public class SMModel {
    ArrayList<SMStateNode> stateNodes;
    ArrayList<SMTransitionLink> transitionLinks;
    ArrayList<SMModelSubscriber> subscribers;

    public SMModel() {
        stateNodes = new ArrayList<>();
        transitionLinks = new ArrayList<>();
        subscribers = new ArrayList<>();
    }

    public void addStateNode(SMStateNode stateNode) {
        stateNodes.add(stateNode);
        notifySubscribers();
    }

    public void addTransitionLink(SMTransitionLink transitionLink) {
        transitionLinks.add(transitionLink);
        notifySubscribers();
    }

    public ArrayList<SMStateNode> getStateNodes() {
        return stateNodes;
    }

    public ArrayList<SMTransitionLink> getTransitionLinks() {
        return transitionLinks;
    }

    public void addSubscriber(SMModelSubscriber subscriber) {
        subscribers.add(subscriber);
    }

    public void notifySubscribers() {
        for (SMModelSubscriber subscriber : subscribers) {
            subscriber.modelChanged();
        }
    }

    public void updateNode(SMStateNode node, String name) {
        node.setName(name);
        notifySubscribers();
    }

    public void updateLink(SMTransitionLink link, String event, String context, String sideEffects) {
        link.setEvent(event);
        link.setContext(context);
        link.setSideEffects(sideEffects);
        notifySubscribers();
    }

    public void deleteItem(SMItem item) {
        if (item != null) {
            if (item instanceof SMStateNode) {
                // Delete node and links associated to it
                SMStateNode node = (SMStateNode)item;

                // Delete connected links
                ArrayList<SMTransitionLink> remLinks = new ArrayList<>();
                for (SMTransitionLink link : transitionLinks) {
                    if (!(link.getFrom() == node || link.getTo() == node)) {
                        remLinks.add(link);
                    }
                }

                // Copy the remaining links
                transitionLinks = remLinks;

                // Delete node
                stateNodes.remove(node);
            } else {
                // Delete the transition link
                SMTransitionLink link = (SMTransitionLink)item;
                transitionLinks.remove(link);
            }
            notifySubscribers();
        }
    }

    public SMItem selectItem(double x, double y) {
        // Search for nodes first
        for (int i = stateNodes.size() - 1; i >= 0; i--) {
            SMStateNode node = stateNodes.get(i);
            if (node.contains(x, y)) {
                return node;
            }
        }

        // Search for transition links
        for (int i = transitionLinks.size() - 1; i >= 0; i--) {
            SMTransitionLink link = transitionLinks.get(i);
            if (link.contains(x, y)) {
                return link;
            }
        }

        return null;
    }

    public void move(SMItem item, double x, double y) {
        item.setX(x);
        item.setY(y);

        notifySubscribers();
    }
}
