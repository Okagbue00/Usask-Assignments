/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class NodePropertiesView extends VBox implements InteractionModelSubscriber {
    AppController controller;
    TextField stateNameField;

    public NodePropertiesView(AppController appController) {
        controller = appController;

        setMaxWidth(180);
        setPadding(new Insets(6));

        // Create view components
        stateNameField = new TextField();
        clear();

        getChildren().add(new PropertiesTitle("State"));
        getChildren().add(new Label("State Name"));
        getChildren().add(stateNameField);

        attachListeners();
    }

    protected void clear() {
        stateNameField.setText("No Title");
        stateNameField.setDisable(true);
    }

    protected void attachListeners() {
        controller.getInteractionModel().addSubscriber(this);

        stateNameField.setOnAction(e -> update());
    }

    public void update() {
        SMStateNode node = currentStateNode();
        if (node != null) {
            controller.getModel().updateNode(node, stateNameField.getText());
        }
    }

    protected SMStateNode currentStateNode() {
        SMItem currentItem = controller.getInteractionModel().getSelectedItem();

        if (currentItem != null && currentItem instanceof SMStateNode) {
            return (SMStateNode) currentItem;
        } else {
            return null;
        }
    }

    @Override
    public void iModelChanged() {
        SMStateNode node = currentStateNode();
        if (node != null) {
            stateNameField.setDisable(false);
            stateNameField.setText(node.getName());
        } else {
            clear();
        }
    }
}
