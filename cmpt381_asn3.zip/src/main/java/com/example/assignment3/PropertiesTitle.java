/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class PropertiesTitle extends Label {
    public PropertiesTitle(String s) {
        super(s);

        setStyle("-fx-alignment: center; -fx-padding: 8 16; -fx-background-color: #BBBBB9; -fx-font-size: 16;");
        setMaxWidth(Double.MAX_VALUE);
    }
}
