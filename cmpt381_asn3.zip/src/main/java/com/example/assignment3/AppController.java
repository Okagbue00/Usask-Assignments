/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */


package com.example.assignment3;

import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;

/**
 * Handles events in the views
 */
public class AppController {
    SMModel model;
    InteractionModel iModel;

    public AppController(SMModel smModel, InteractionModel interactionModel) {
        model = smModel;
        iModel = interactionModel;
    }

    public SMModel getModel() {
        return model;
    }

    public InteractionModel getInteractionModel() {
        return iModel;
    }

    protected double getRealX(double mX) {
        return mX + iModel.getViewPortX();
    }

    protected double getRealY(double mY) {
        return mY + iModel.getViewPortY();
    }

    // Define handlers for arrow tool
    protected void arrowOnMousePressed(MouseButton button, double x, double y) {
        if (button == MouseButton.PRIMARY) {
            // Apply viewport
            x = getRealX(x);
            y = getRealY(y);

            SMItem selection = model.selectItem(x, y);

            if (selection == null) {
                // Create a new node
                SMStateNode node = new SMStateNode("Default", 80, 60, x, y);
                model.addStateNode(node);
                iModel.setSelectedItem(node);
            } else {
                // Select a new node
                iModel.setSelectedItem(selection);

                // Compute the offset
                iModel.setSelectOffsetX(x - selection.getX());
                iModel.setSelectOffsetY(y - selection.getY());
            }
        }
    }

    protected void arrowOnMouseDragged(MouseButton button, double x, double y) {
        // Only update if left button is pressed
        if (button == MouseButton.PRIMARY) {
            x = getRealX(x);
            y = getRealY(y);
            SMItem node = iModel.getSelectedItem();

            if (node != null) {
                model.move(node,
                        x - iModel.getSelectOffsetX(),
                        y - iModel.getSelectOffsetY());
            }
        }
    }

    protected void linkOnMousePressed(MouseButton button, double x, double y) {
        if (button == MouseButton.PRIMARY) {
            x = getRealX(x);
            y = getRealY(y);
            SMItem selected = model.selectItem(x, y);

            // Check if selection is a node
            if (selected != null && selected instanceof SMStateNode) {
                iModel.setSelectedItem(selected);
                iModel.setLinkMouseX(x);
                iModel.setLinkMouseY(y);
            }
        }
    }

    protected void panOnMousePressed(MouseButton button, double x, double y) {
        if (button == MouseButton.PRIMARY) {
            iModel.setSelectOffsetX(x + iModel.getViewPortX());
            iModel.setSelectOffsetY(y + iModel.getViewPortY());
        }
    }

    protected  void panOnMouseDragged(MouseButton button, double x, double y) {
        if (button == MouseButton.PRIMARY) {
            double vpX = -x + iModel.getSelectOffsetX();
            double vpY = -y + iModel.getSelectOffsetY();

            // Check if it is outside the bounds of the document
            if (vpX < 0) {
                vpX = 0;
            } else if (vpX > (1600 - iModel.getViewPortWidth())) {
                vpX = (1600 - iModel.getViewPortWidth());
            }

            if (vpY < 0) {
                vpY = 0;
            } else if (vpY > (1600 - iModel.getViewPortHeight())) {
                vpY = (1600 - iModel.getViewPortHeight());
            }

            iModel.setViewPortX(vpX);
            iModel.setViewPortY(vpY);
        }
    }

    protected void linkOnMouseDragged(MouseButton button, double x, double y) {
        if (button == MouseButton.PRIMARY) {
            x = getRealX(x);
            y = getRealY(y);

            iModel.setLinkMouseX(x);
            iModel.setLinkMouseY(y);
        }
    }

    protected  void linkOnMouseReleased(double x, double y) {
        SMItem from = iModel.getSelectedItem();

        if (from != null) {
            x = getRealX(x);
            y = getRealY(y);

            // Check if we have a destination node
            SMItem node_item = model.selectItem(x, y);

            if (node_item != null && node_item instanceof SMStateNode) {
                // Create a transition link
                // Compute the middle coordinates
                double centerX = (from.getCenterX() + node_item.getCenterX()) / 2;
                double centerY = (from.getCenterY() + node_item.getCenterY()) / 2;
                SMTransitionLink transitionLink = new SMTransitionLink(
                        (SMStateNode)from, (SMStateNode)node_item,
                        "No event", "No context", "No side effects",
                        100, 120,
                        centerX, centerY);
                model.addTransitionLink(transitionLink);
            }
        }

        // Clear selection
        iModel.setSelectedItem(null);
    }

    public void onMousePressed(MouseButton button, double x, double y) {
        switch (iModel.getCurrentTool()) {
            case ARROW -> arrowOnMousePressed(button, x, y);
            case LINK -> linkOnMousePressed(button, x, y);
            case PAN -> panOnMousePressed(button, x, y);
        }
    }

    public void onMouseDragged(MouseButton button, double x, double y) {
        switch (iModel.getCurrentTool()) {
            case ARROW -> arrowOnMouseDragged(button, x, y);
            case LINK -> linkOnMouseDragged(button, x, y);
            case PAN -> panOnMouseDragged(button, x, y);
        }
    }


    public void onMouseReleased(double x, double y) {
        if (iModel.getCurrentTool() == InteractionModel.Tool.LINK) {
            linkOnMouseReleased(x, y);
        }
    }

    public void onKeyPressed(KeyCode code) {
        switch (code) {
            case DELETE -> {
                model.deleteItem(iModel.getSelectedItem());
            }
        }
    }

    public void onDiagramResize(double w, double h) {
        if (iModel.getViewPortX() > 1600 - w) {
            iModel.setViewPortX(1600 - w);
        }

        if (iModel.getViewPortY() > 1600 - h) {
            iModel.setViewPortY(1600 - h);
        }
    }
}
