/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

/**
 * State Machine state node class
 */
public class SMStateNode extends SMItem {
    String name;

    public SMStateNode(String nodeName, double nodeWidth, double nodeHeight, double centerX, double centerY) {
        super(centerX - nodeWidth / 2, centerY - nodeHeight / 2, nodeWidth, nodeHeight);
        name = nodeName;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }
}
