/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class LinkPropertiesView extends VBox implements InteractionModelSubscriber {
    AppController controller;
    TextField eventField;
    TextArea contextField;
    TextArea sideEffectsField;
    Button updateBtn;

    public LinkPropertiesView(AppController appController) {
        controller = appController;

        setMaxWidth(180);
        setPadding(new Insets(6));

        // Create view components
        eventField = new TextField();
        contextField = new TextArea();
        sideEffectsField = new TextArea();
        updateBtn = new Button("Update");

        clear();

        getChildren().add(new PropertiesTitle("Transition"));
        getChildren().add(new Label("Event"));
        getChildren().add(eventField);
        getChildren().add(new Label("Context"));
        getChildren().add(contextField);
        getChildren().add(new Label("Side Effects"));
        getChildren().add(sideEffectsField);
        getChildren().add(updateBtn);

        attachListeners();
    }

    protected void clear() {
        eventField.setText("No Event");
        eventField.setDisable(true);
        contextField.setText("No Context");
        contextField.setDisable(true);
        sideEffectsField.setText("No Side Effects");
        sideEffectsField.setDisable(true);
    }

    protected void attachListeners() {
        controller.getInteractionModel().addSubscriber(this);

        updateBtn.setOnAction(e -> update());
    }

    public void update() {
        SMTransitionLink link = currentLink();
        if (link != null) {
            controller.getModel().updateLink(link,
                    eventField.getText(),
                    contextField.getText(),
                    sideEffectsField.getText());
        }
    }

    protected SMTransitionLink currentLink() {
        SMItem currentItem = controller.getInteractionModel().getSelectedItem();

        if (currentItem != null && currentItem instanceof SMTransitionLink) {
            return (SMTransitionLink) currentItem;
        } else {
            return null;
        }
    }

    @Override
    public void iModelChanged() {
        SMTransitionLink link = currentLink();
        if (link != null) {
            // Load details
            eventField.setDisable(false);
            eventField.setText(link.getEvent());
            contextField.setDisable(false);
            contextField.setText(link.getContext());
            sideEffectsField.setDisable(false);
            sideEffectsField.setText(link.getSideEffects());
        } else {
            clear();
        }
    }
}
