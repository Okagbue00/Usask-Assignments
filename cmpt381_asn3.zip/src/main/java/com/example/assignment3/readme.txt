/* Okagbue  Onyeka Francis
* Ono206
* 11279373 */

To run the application, you would need to run the EditorApp class, it has the start function that would execute the program.
All parts of the assignment is implemented correctly and the GUI are working appropriately as supposed to.
The files for the assignment include:- AppController, DiagramView, EditorApp, InteractionModel, InteractionModelSubscriber, LinkPropertiesView, MainUI, NodePropertiesView, PropertiesTitle, SMItem, SMModel, SMModelSubscriber, SMStateNode, SMTransitionLink and ToolPalette...
And in the resources contained are the png files for the toolbars that is located on the left side of the GUI application.