/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.geometry.VPos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;
import javafx.scene.transform.Affine;
import javafx.util.Pair;

public class DiagramView extends Canvas implements InteractionModelSubscriber, SMModelSubscriber {
    GraphicsContext gc;
    AppController controller;
    public DiagramView(int width, int height, AppController appController) {
        super(width, height);

        controller = appController;
        gc = getGraphicsContext2D();

        // Subscribe to react to model changes
        controller.getModel().addSubscriber(this);
        controller.getInteractionModel().addSubscriber(this);

        // Set events
        attachListeners();
    }

    protected void attachListeners() {
        setOnMousePressed(e -> controller.onMousePressed(e.getButton(), e.getX(), e.getY()));
        setOnMouseDragged(e -> controller.onMouseDragged(e.getButton(), e.getX(), e.getY()));
        setOnMouseReleased(e -> controller.onMouseReleased(e.getX(), e.getY()));
        widthProperty().addListener(e -> onResize());
        heightProperty().addListener(e -> onResize());
    }

    protected void onResize() {
        controller.onDiagramResize(getWidth(), getHeight());
        controller.getInteractionModel().setViewPortWidth(getWidth());
        controller.getInteractionModel().setViewPortHeight(getHeight());
        redraw();
    }

    protected void drawInteraction() {
        InteractionModel iModel = controller.getInteractionModel();
        SMItem node = iModel.getSelectedItem();

        if (iModel.getCurrentTool() == InteractionModel.Tool.LINK && node != null) {
            // Draw line
            gc.setStroke(Color.BLACK);
            gc.setLineWidth(2);

            gc.strokeLine(node.getCenterX(), node.getCenterY(), iModel.getLinkMouseX(), iModel.getLinkMouseY());
        }
    }

    protected void draw(double opacity) {
        // Draw the interaction links
        for (SMTransitionLink transitionLink : controller.getModel().getTransitionLinks()) {
            drawTransitionLink(transitionLink, opacity);
        }

        // Draw the state nodes
        for (SMStateNode node : controller.getModel().getStateNodes()) {
            drawNode(node, opacity);
        }
    }

    protected void drawArrow(double fromX, double fromY, double toX, double toY, double opacity) {
        gc.setStroke(Color.rgb(0, 0, 0, opacity));
        gc.setLineWidth(2);

        // Draw arrow head
        double arrowLength = 20;
        double arrowWidth = 10;
        double length = Math.sqrt((fromX - toX) * (fromX - toX) + (fromY - toY) * (fromY - toY));

        // Draw baseline
        gc.strokeLine(fromX, fromY,
                fromX + (toX - fromX) * (length - arrowLength) / length,
                fromY + (toY - fromY) * (length - arrowLength) / length);

        double baseX = toX + (fromX - toX) * arrowLength / length;
        double baseY = toY + (fromY - toY) * arrowLength / length;

        double offsetX = (fromY - toY) * arrowWidth / 2 / length;
        double offsetY = -(fromX - toX) * arrowWidth / 2 / length;

        double leftX = baseX - offsetX;
        double leftY = baseY - offsetY;

        double rightX = baseX + offsetX;
        double rightY = baseY + offsetY;

        double[] pointsX = {toX, leftX, rightX};
        double[] pointsY = {toY, leftY, rightY};

        gc.setFill(Color.rgb(0, 0, 0, opacity));
        gc.fillPolygon(pointsX, pointsY, 3);
    }



    protected void drawTransitionLink(SMTransitionLink transitionLink, double opacity) {
        // Draw the arrows
        gc.setStroke(Color.rgb(0, 0, 0, opacity));
        gc.setLineWidth(2);

        Pair<Double, Double> intFrom = transitionLink.getIntersection(
                transitionLink.getFrom().getCenterX(), transitionLink.getFrom().getCenterY()
        );
        drawArrow(transitionLink.getFrom().getCenterX(),
                transitionLink.getFrom().getCenterY(),
                intFrom.getKey(),
                intFrom.getValue(), opacity);

        Pair<Double, Double> intTo = transitionLink.getTo().getIntersection(
                transitionLink.getCenterX(), transitionLink.getCenterY()
        );
        drawArrow(transitionLink.getCenterX(),
                transitionLink.getCenterY(),
                intTo.getKey(),
                intTo.getValue(), opacity);

        // Draw circle if the transition link point to the same node
        if (transitionLink.getFrom() == transitionLink.getTo()) {
            double centerX = (intFrom.getKey() + intTo.getKey()) / 2;
            double centerY = (intFrom.getValue() + intTo.getValue()) / 2;
            double r = Math.sqrt(Math.pow(intFrom.getKey() - intTo.getKey(), 2) + Math.pow(intFrom.getValue() - intTo.getValue(), 2)) / 2;

            gc.strokeOval(centerX - r, centerY - r, 2 * r, 2 * r);
        }

        // Draw the transition link details
        gc.setFill(Color.rgb(255, 255, 255, opacity));
        gc.setStroke(controller.getInteractionModel().getSelectedItem() == transitionLink ? Color.rgb(255, 0, 0, opacity) : Color.rgb(0, 0, 0, opacity));
        gc.setLineWidth(1);

        gc.fillRoundRect(transitionLink.getX(), transitionLink.getY(),
                transitionLink.getWidth(), transitionLink.getHeight(), 10, 10);
        gc.strokeRoundRect(transitionLink.getX(), transitionLink.getY(),
                transitionLink.getWidth(), transitionLink.getHeight(), 10, 10);
        
        gc.setTextAlign(TextAlignment.LEFT);
        gc.setTextBaseline(VPos.TOP);
        gc.setLineWidth(1);
        gc.setStroke(Color.rgb(0, 0, 0, opacity));
        gc.strokeText(transitionLink.getDetails(),
                transitionLink.getX() + 5, transitionLink.getY() + 5,
                transitionLink.getWidth() - 10);
    }

    protected void drawNode(SMStateNode node, double opacity) {
        gc.setFill(Color.rgb(255, 255, 0, opacity));
        gc.setLineWidth(1);
        gc.setTextAlign(TextAlignment.CENTER);
        gc.setTextBaseline(VPos.CENTER);
        gc.fillRect(node.getX(), node.getY(), node.getWidth(), node.getHeight());
        gc.setStroke(Color.rgb(0, 0, 0, opacity));
        gc.strokeText(node.getName(), node.getCenterX(), node.getCenterY(), node.getWidth());
        gc.setStroke(controller.getInteractionModel().getSelectedItem() == node ? Color.rgb(255, 0, 0, opacity) : Color.rgb(0, 0,0, opacity));
        gc.strokeRect(node.getX(), node.getY(), node.getWidth(), node.getHeight());
    }

    protected void drawOverview() {
        Affine scTransform = new Affine();
        double ratio = Math.min(getWidth() / 2, getHeight() / 2) / 1600;
        scTransform.setMxx(ratio);
        scTransform.setMyy(ratio);
        gc.setTransform(scTransform);

        // Draw background
        gc.setFill(Color.rgb(127, 127, 127, 0.5));
        gc.fillRect(0, 0, 1600, 1600);

        // Draw the items
        draw(0.5);

        // Draw the view port
        gc.setStroke(Color.rgb(255, 0, 0, 0.5));
        gc.setLineWidth(2);
        gc.strokeRect(controller.getInteractionModel().getViewPortX(),
                controller.getInteractionModel().getViewPortY(),
                getWidth(), getHeight());
    }

    @Override
    public void iModelChanged() {
        redraw();
    }

    protected void redraw() {
        // Reset transform
        gc.setTransform(new Affine());

        // Clear background
        gc.setFill(Color.rgb(134, 207, 235));
        gc.fillRect(0, 0, getWidth(), getHeight());

        drawOverview();

        // Apply translation transform
        Affine transform = new Affine();
        transform.setTx(-controller.getInteractionModel().getViewPortX());
        transform.setTy(-controller.getInteractionModel().getViewPortY());

        gc.setTransform(transform);

        draw(1.0);
        drawInteraction();
    }

    @Override
    public void modelChanged() {
        redraw();
    }

    @Override
    public boolean isResizable() {
        return true;
    }

    @Override
    public double prefWidth(double height) {
        return getWidth();
    }

    @Override
    public double prefHeight(double width) {
        return getHeight();
    }
}
