/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import java.util.ArrayList;

public class InteractionModel {
    ArrayList<InteractionModelSubscriber> subscribers;
    SMItem selectedItem;
    double selectOffsetX;
    double selectOffsetY;
    Tool currentTool;

    double linkMouseX;
    double linkMouseY;
    double viewPortX;
    double viewPortY;
    double viewPortWidth;
    double viewPortHeight;

    public enum Tool { ARROW, PAN, LINK }

    public InteractionModel() {
        subscribers = new ArrayList<>();
        currentTool = Tool.ARROW;
        selectedItem = null;
        selectOffsetX = 0;
        selectOffsetY = 0;
        viewPortX = 0;
        viewPortY = 0;
    }

    public Tool getCurrentTool() {
        return currentTool;
    }

    protected void reset() {
        selectedItem = null;
    }

    public void setCurrentTool(Tool tool) {
        reset();
        currentTool = tool;
        notifySubscribers();
    }

    public void addSubscriber(InteractionModelSubscriber subscriber) {

        subscribers.add(subscriber);
        subscriber.iModelChanged();
    }

    public void notifySubscribers() {
        for (InteractionModelSubscriber subscriber : subscribers) {
            subscriber.iModelChanged();
        }
    }

    public SMItem getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(SMItem item) {
        selectedItem = item;
        notifySubscribers();
    }

    public void setSelectOffsetX(double offsetX) {
        selectOffsetX = offsetX;
        notifySubscribers();
    }

    public void setSelectOffsetY(double offsetY) {
        selectOffsetY = offsetY;
        notifySubscribers();
    }

    public double getSelectOffsetX() { return selectOffsetX; }
    public double getSelectOffsetY() { return selectOffsetY; }
    public double getLinkMouseX() { return linkMouseX; }
    public double getLinkMouseY() { return linkMouseY; }
    public double getViewPortX() { return viewPortX; }
    public double getViewPortY() { return viewPortY; }

    public void setViewPortX(double viewportX) {
        viewPortX = viewportX;
        notifySubscribers();
    }

    public void setViewPortY(double viewportY) {
        viewPortY = viewportY;
        notifySubscribers();
    }

    public void setLinkMouseX(double mouseX) {
        linkMouseX = mouseX;
        notifySubscribers();
    }

    public void setLinkMouseY(double mouseY) {
        linkMouseY = mouseY;
        notifySubscribers();
    }

    public double getViewPortWidth() {
        return viewPortWidth;
    }

    public double getViewPortHeight() {
        return viewPortHeight;
    }

    public void setViewPortWidth(double width) {
        viewPortWidth = width;
    }

    public void setViewPortHeight(double height) {
        viewPortHeight = height;
    }
}
