/**
 * Okagbue Francis
 * CMPT 381
 * 11279373
 * ONO206
 */

package com.example.assignment3;

import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;

public class MainUI extends HBox implements InteractionModelSubscriber {
    ToolPalette palette;
    DiagramView diagram;
    AppController controller;
    NodePropertiesView nodeProperties;
    LinkPropertiesView linkProperties;

    public MainUI(int width, int height, AppController appController)  {
        palette = new ToolPalette(appController);
        diagram = new DiagramView(width, height, appController);
        nodeProperties = new NodePropertiesView(appController);
        linkProperties = new LinkPropertiesView(appController);

        controller = appController;

        // Create diagram canvas container
        StackPane stackPane = new StackPane();
        stackPane.getChildren().add(diagram);
        stackPane.setMinSize(600, 600);

        diagram.widthProperty().bind(stackPane.widthProperty());
        diagram.heightProperty().bind(stackPane.heightProperty());

        getChildren().add(palette);
        getChildren().add(stackPane);
        getChildren().add(nodeProperties);
        getChildren().add(linkProperties);

        //palette.setMaxHeight(Double.MAX_VALUE);
        HBox.setHgrow(stackPane, Priority.ALWAYS);

        attachListeners();
    }

    protected void attachListeners() {
        controller.getInteractionModel().addSubscriber(this);

        setOnKeyPressed(e -> controller.onKeyPressed(e.getCode()));
    }

    public ToolPalette getPalette() {
        return palette;
    }

    public DiagramView getDiagram() {
        return diagram;
    }

    @Override
    public void iModelChanged() {
        SMItem item = controller.getInteractionModel().getSelectedItem();

        if (item != null && item instanceof SMTransitionLink) {
            linkProperties.setVisible(true);
            linkProperties.setManaged(true);
            nodeProperties.setVisible(false);
            nodeProperties.setManaged(false);
        } else {
            linkProperties.setVisible(false);
            linkProperties.setManaged(false);
            nodeProperties.setVisible(true);
            nodeProperties.setManaged(true);
        }
    }
}
