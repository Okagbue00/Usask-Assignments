package asn3_startercode;

import lib280.list.LinkedList280;
import lib280.tree.BasicMAryTree280;
import lib280.tree.MAryNode280;

import javax.management.RuntimeErrorException;

public class SkillTree extends BasicMAryTree280<Skill> {

	private Skill skillname;

	/**
	 * Create lib280.tree with the specified root node and
	 * specified maximum arity of nodes.  
	 * @timing O(1) 
	 * @param x item to set as the root node
	 * @param m number of children allowed for future nodes 
	 */
	public SkillTree(Skill x, int m)
	{
		super(x,m);
	}

	/**
	 * A convenience method that avoids typecasts.
	 * Obtains a subtree of the root.
	 * 
	 * @param i Index of the desired subtree of the root.
	 * @return the i-th subtree of the root.
	 */
	public SkillTree rootSubTree(int i) {
		return (SkillTree)super.rootSubtree(i);
	}



	public LinkedList280<Skill> SkillDependencies(Skill name) throws RuntimeException { //throws exception

		LinkedList280<Skill> skill_list;
		skill_list = new LinkedList280<>();
		boolean boo = false;
		if (this.rootItem().equals(name)){
			skill_list.insert(this.rootItem());
			boo = true;
		}
		if (this.rootLastNonEmptyChild() == 0){
		}
		else {
			for (int i = 1; i <= this.rootLastNonEmptyChild(); i++) {
				skill_list.insert(this.rootItem());

				rootSubTree(i).SkillDependencies(name);
			}

		}
		return skill_list;}


		public int SkillTotalCost(Skill name) throws RuntimeErrorException{


			return 1;
		}









	public static void main(String[] args) {
		System.out.println("MY SKILL TREE:- ");
		System.out.println("FRANCE STARTING ELEVEN WORLD CUP 2018 FINALS AGAINST CROATIA:- ");
		Skill foot_1 = new Skill("Lloris" ,"Tottenham", 1);
		Skill foot_2 = new Skill("Pavard", "Bayern Munich",2);
		Skill foot_3 = new Skill("Varane", "Real Madrid", 4);
		Skill foot_4 = new Skill("Umtiti", "Barcelona", 5);
		Skill foot_5 = new Skill("Hernandez", "Bayern Munich", 21);
		Skill foot_6 = new Skill("Kante", "Chelsea", 13);
		Skill foot_7 = new Skill("Matuidi", "Inter Miami", 14);
		Skill foot_8 = new Skill("Pogba", "Manchester United", 6);
		Skill foot_9 = new Skill("Griezmann", "Barcelona", 7);
		Skill foot_10 = new Skill("Mbappe", "Paris Saint Germain", 10);
		Skill foot_11 = new Skill("Giroud", "Chelsea", 9);

		System.out.println("France National Team Managerial Role");
		Skill manager = new Skill("Deschamps", "France", 52);
		Skill assistant_manager = new Skill("Stephan", "France", 47);

		System.out.println("France Roaster Date of Birth\n");
		//subtree-- player date of birth
		SkillTree year1 = new SkillTree(foot_1, 5);
		SkillTree year2 = new SkillTree(foot_2, 3);
		SkillTree year3 = new SkillTree(foot_3, 3);
		SkillTree year4 = new SkillTree(foot_4, 5);
		SkillTree france_ass_coach = new SkillTree(manager, 5);
		SkillTree year5 = new SkillTree(foot_5, 4);
		SkillTree year6 = new SkillTree(foot_6, 4);
		SkillTree year7 = new SkillTree(foot_7, 5);
		SkillTree year8 = new SkillTree(foot_8, 3);
		SkillTree year9 = new SkillTree(foot_9, 3);
		SkillTree year10 = new SkillTree(foot_10, 4);
		SkillTree year11 = new SkillTree(foot_11, 4);
		SkillTree france_coach = new SkillTree(assistant_manager, 3);





		//set subtree in the skilltree

		year1.setRootSubtree(year2, 1);
		year1.setRootSubtree(year3, 1);
		year1.setRootSubtree(year4, 1);
		year1.setRootSubtree(year5, 2);

		year1.setRootSubtree(france_coach, 3);


		year6.setRootSubtree(year7, 1);
		year6.setRootSubtree(year8, 1);
		year6.setRootSubtree(year9, 2);
		year6.setRootSubtree(year10, 3);

		year10.setRootSubtree(year1, 1);
		year10.setRootSubtree(year11, 1);
		year10.setRootSubtree(year4, 1);
		year10.setRootSubtree(year11, 3);

		france_ass_coach.setRootSubtree(france_coach, 1);
		france_ass_coach.setRootSubtree(year1, 2);
		france_ass_coach.setRootSubtree(year2, 3);
		france_ass_coach.setRootSubtree(year3, 4);
		france_ass_coach.setRootSubtree(year4, 5);













		System.out.println(year1.toStringByLevel());



		//for skill dependencies

		System.out.println("Dependencies for Varane: \n" + foot_3.getSkillName() + "\n" + year1.SkillDependencies(foot_7).toString());
		System.out.println("Dependencies for Kante: \n" + foot_6.getSkillName() + "\n" + year11.SkillDependencies(foot_7).toString());

		try{
			System.out.println("Dependencies for Deschamps:\n" + manager.getSkillName());
		} catch (RuntimeException e) {
			System.out.println( manager.getSkillName() + "not found.");
		}


		//for skill total cost
		System.out.println("Test for SkillTotalCost\n");

		System.out.println("To get " + foot_1.getSkillName() + " you must invest " + year1.SkillTotalCost(foot_1) + " points.");
		System.out.println("To get " + foot_2.getSkillName() + " you must invest " + year1.SkillTotalCost(foot_2) + " points.");
		System.out.println("To get " + foot_3.getSkillName() + " you must invest " + year1.SkillTotalCost(foot_3) + " points.");

		try{
			System.out.println("Dependencies for Hernandez:\n" + foot_5.getSkillName());
		} catch (RuntimeException e) {
			System.out.println( manager.getSkillName() + "not found.");
		}







	}





}

