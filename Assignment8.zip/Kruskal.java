import lib280.graph.Edge280;
import lib280.graph.Vertex280;
import lib280.graph.WeightedEdge280;
import lib280.graph.WeightedGraphAdjListRep280;
import lib280.list.ArrayedList280;
import lib280.tree.ArrayedMinHeap280;

public class Kruskal {

	public static WeightedGraphAdjListRep280<Vertex280> minSpanningTree(WeightedGraphAdjListRep280<Vertex280> G) {

		// TODO -- Complete this method.

		// Get the number of vertices
		int numVerts = G.numVertices();
		int numEdges = G.numEdges();

		// Create the minimum spanning tree with the same nodes as the original.
		WeightedGraphAdjListRep280<Vertex280> minST = new WeightedGraphAdjListRep280<Vertex280>(numVerts, false);
		minST.ensureVertices(numVerts);

		// Use the union find data structure
		UnionFind280 UF = new UnionFind280(numVerts);

		// Sort the edges
		ArrayedMinHeap280<WeightedEdge280<Vertex280>> edges = new ArrayedMinHeap280<WeightedEdge280<Vertex280>>(numEdges);

		System.out.println(numEdges);

		for (int vi = 1; vi <= numVerts; vi++) {
			G.eGoFirst(G.vertex(vi));

			while (G.eItemExists()) {
				try {
					edges.insert(G.eItem());
					G.eGoForth();
				}
				catch (Exception e) {
					break;
				}
			}
		}

		// Loop through all edges
		WeightedEdge280<Vertex280> edge;
		int a, b;
		while (!edges.isEmpty()) {
			edge = edges.item();
			edges.deleteItem();

			a = edge.firstItem().index();
			b = edge.secondItem().index();

			if (UF.find(a) != UF.find(b)) { // vertices a & b are on different subsets
				minST.addEdge(a, b);
				minST.setEdgeWeight(a, b, edge.getWeight());
				UF.union(a, b);
			}
		}

		return minST;
	}


	public static void main(String args[]) {
		WeightedGraphAdjListRep280<Vertex280> G = new WeightedGraphAdjListRep280<Vertex280>(1, false);
		G.initGraphFromFile("/Users/francis/Downloads/asn-8-280/Kruskal-Template/mst.graph");
		System.out.println(G);

		WeightedGraphAdjListRep280<Vertex280> minST = minSpanningTree(G);

		System.out.println(minST);
	}
}


