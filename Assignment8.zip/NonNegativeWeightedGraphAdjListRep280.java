package lib280.graph;

//import java.io.File;
//import java.io.IOException;
//import java.util.Scanner;

import lib280.base.Pair280;
import lib280.dispenser.ArrayedQueue280;
import lib280.exception.InvalidArgument280Exception;

import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Scanner;


public class NonNegativeWeightedGraphAdjListRep280<V extends Vertex280> extends
        WeightedGraphAdjListRep280<V> {

    public NonNegativeWeightedGraphAdjListRep280(int cap, boolean d,
                                                 String vertexTypeName) {
        super(cap, d, vertexTypeName);
    }

    public NonNegativeWeightedGraphAdjListRep280(int cap, boolean d) {
        super(cap, d);
    }


    @Override
    public void setEdgeWeight(V v1, V v2, double weight) {
        // Overriding this method to throw an exception if a weight is negative will cause
        // super.initGraphFromFile to throw an exception when it tries to set a weight to
        // something negative.

        // Verify that the weight is non-negative
        if(weight < 0) throw new InvalidArgument280Exception("Specified weight is negative.");

        // If it is, then just set the edge weight using the superclass method.
        super.setEdgeWeight(v1, v2, weight);
    }

    @Override
    public void setEdgeWeight(int srcIdx, int dstIdx, double weight) {
        // Get the vetex objects associated with each index and pass off to the
        // version of setEdgeWEight that accepts vertex objects.
        this.setEdgeWeight(this.vertex(srcIdx), this.vertex(dstIdx), weight);
    }


    /**
     * Implementation of Dijkstra's algorithm.
     * @param startVertex Start vertex for the single-source shortest paths.
     * @return An array of size G.numVertices()+1 in which offset k contains the shortest
     *         path from startVertex to k.  Offset 0 is unused since vertex indices start
     *         at 1.
     */
    public Pair280<double[], int[]> shortestPathDijkstra(int startVertex) {
        int numVerts = this.numVertices();
        double[] tentativeDistance = new double[numVerts + 1];
        int[] predecessorNode = new int[numVerts + 1];
        boolean[] visited = new boolean[numVerts + 1];

        // get the vertices and set the initial values
        for (int i = 0; i <= numVerts; i++) {
            tentativeDistance[i] = Double.POSITIVE_INFINITY;
            visited[i] = false;
            predecessorNode[i] = -1;
        }

        // set the tentative distance of start vertex to zero
        tentativeDistance[startVertex] = 0;

        int numVisited = 0;
        int currentVertex = 0;

        while (numVisited < numVerts) {
            // find the unvisited vertex with least distance
            currentVertex = 0; // reset
            for (int i = 1; i <= numVerts; i++) {
                if (visited[i] == false) {
                    if (tentativeDistance[i] < tentativeDistance[currentVertex]) {
                        currentVertex = i;
                    }
                }
            }
            visited[currentVertex] = true;
            numVisited++;

            // update the tentative distances array
            // loop through each adjacent vertex to the current vertex
            WeightedEdge280<V> edge;
            for (int z = 1; z <= numVerts; z++) {
                eSearch(this.vertex(currentVertex), this.vertex(z));
                if (z != currentVertex && eItemExists()) {
                    if (visited[z] == false && tentativeDistance[z] > tentativeDistance[currentVertex] + eItem.getWeight()) {
                        tentativeDistance[z] = tentativeDistance[currentVertex] + eItem.getWeight();
                        predecessorNode[z] = currentVertex;
                    }
                }
            }
        }

        return new Pair280<double[], int[]>(tentativeDistance, predecessorNode);
    }

    // Given a predecessors array output from this.shortestPathDijkatra, return a string
    // that represents a path from the start node to the given destination vertex 'destVertex'.
    private static String extractPath(int[] predecessors, int destVertex) {
        // TODO Implement this method
        if (predecessors[destVertex] == -1) {
            return "Not reachable.";
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("The path to ");
            sb.append(destVertex);
            sb.append(" is : ");

            int[] pathPoints = new int[predecessors.length];
            int length = 0, currentVertex = 0;

            for (currentVertex = destVertex; currentVertex != -1; currentVertex = predecessors[currentVertex]) {
                pathPoints[length] = currentVertex;
                length++;
            }

            for (int i = length - 1; i >= 0; i--) { // loop backwards
                sb.append(pathPoints[i]);

                if (i > 0) {
                    sb.append(", ");
                }
            }

            return sb.toString();
        }
    }

    // Regression Test
    public static void main(String args[]) {
        NonNegativeWeightedGraphAdjListRep280<Vertex280> G = new NonNegativeWeightedGraphAdjListRep280<Vertex280>(1, false);

        if( args.length == 0)
            G.initGraphFromFile("/Users/francis/Downloads/asn-8-280/lib280-asn8/src/lib280/graph/weightedtestgraph.gra");
        else
            G.initGraphFromFile(args[0]);

        System.out.println("Enter the number of the start vertex: ");
        Scanner in = new Scanner(System.in);
        int startVertex;
        try {
            startVertex = in.nextInt();
        }
        catch(InputMismatchException e) {
            in.close();
            System.out.println("That's not an integer!");
            return;
        }

        if( startVertex < 1 || startVertex > G.numVertices() ) {
            in.close();
            System.out.println("That's not a valid vertex number for this graph.");
            return;
        }
        in.close();


        Pair280<double[], int[]> dijkstraResult = G.shortestPathDijkstra(startVertex);
        double[] finalDistances = dijkstraResult.firstItem();
        //double correctDistances[] = {-1, 0.0, 1.0, 3.0, 23.0, 7.0, 16.0, 42.0, 31.0, 36.0};
        int[] predecessors = dijkstraResult.secondItem();

        for(int i=1; i < G.numVertices() +1; i++) {
            System.out.println("The length of the shortest path from vertex " + startVertex + " to vertex " + i + " is: " + finalDistances[i]);
            //			if( correctDistances[i] != finalDistances[i] )
            //				System.out.println("Length of path from to vertex " + i + " is incorrect; should be " + correctDistances[i] + ".");
            //			else {
            System.out.println(extractPath(predecessors, i));
            //			}
        }
    }

}
