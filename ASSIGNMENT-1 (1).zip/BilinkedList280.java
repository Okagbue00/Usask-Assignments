package lib280.list;


import lib280.base.BilinearIterator280;
import lib280.base.CursorPosition280;
import lib280.base.Pair280;
import lib280.exception.*;

/**	This list class incorporates the functions of an iterated 
	dictionary such as has, obtain, search, goFirst, goForth, 
	deleteItem, etc.  It also has the capabilities to iterate backwards 
	in the list, goLast and goBack. */
public class BilinkedList280<I> extends LinkedList280<I> implements BilinearIterator280<I>
{
	/* 	Note that because firstRemainder() and remainder() should not cut links of the original list,
		the previous node reference of firstNode is not always correct.
		Also, the instance variable prev is generally kept up to date, but may not always be correct.  
		Use previousNode() instead! */

	/**	Construct an empty list.
		Analysis: Time = O(1) */
	public BilinkedList280()
	{
		super();
	}

	/**
	 * Create a BilinkedNode280 this Bilinked list.  This routine should be
	 * overridden for classes that extend this class that need a specialized node.
	 * @param item - element to store in the new node
	 * @return a new node containing item
	 */
	protected BilinkedNode280<I> createNewNode(I item)
	{
		// TODO

		BilinkedNode280<I> bilinked_node; //bilinked_node is my created new bilinked node
		bilinked_node = new BilinkedNode280<I>(item); //my new node
		return bilinked_node; //returned a new node of my bilinked node.


		//return null;  // This line is present only to prevent a compile error.  You should remove it before
		// completing this method.
	}

	/**
	 * Insert element at the beginning of the list
	 * @param x item to be inserted at the beginning of the list 
	 */
	public void insertFirst(I x) 
	{
		// TODO


		if ((itemExists())) throw new ItemNotFound280Exception("Item not found in the list");

		BilinkedNode280<I> bilinked_node; //bilinked node is my created new bilinked node
		bilinked_node = new BilinkedNode280<I>(x);


		if (head == position){ //if my first node is the position of my cursor
			prevPosition = bilinked_node ; //then my previous cursor position node will then be the bilinked node
		}

		else {
			head = bilinked_node; //my first node will be the new node if otherwise;
		}

		//insertFirst(x);

	}


	/**
	 * Insert element at the beginning of the list
	 * @param x item to be inserted at the beginning of the list 
	 */
	public void insert(I x) 
	{
		this.insertFirst(x);
	}

	/**
	 * Insert an item before the current position.
	 * @param x - The item to be inserted.
	 */
	public void insertBefore(I x) throws InvalidState280Exception {
		if( this.before() ) throw new InvalidState280Exception("Cannot insertBefore() when the cursor is already before the first element.");
		
		// If the item goes at the beginning or the end, handle those special cases.
		if( this.head == position ) {
			insertFirst(x);  // special case - inserting before first element
		}
		else if( this.after() ) {
			insertLast(x);   // special case - inserting at the end
		}
		else {
			// Otherwise, insert the node between the current position and the previous position.
			BilinkedNode280<I> newNode = createNewNode(x);
			newNode.setNextNode(position);
			newNode.setPreviousNode((BilinkedNode280<I>)this.prevPosition);
			prevPosition.setNextNode(newNode);
			((BilinkedNode280<I>)this.position).setPreviousNode(newNode);
			
			// since position didn't change, but we changed it's predecessor, prevPosition needs to be updated to be the new previous node.
			prevPosition = newNode;			
		}
	}
	
	
	/**	Insert x before the current position and make it current item. <br>
		Analysis: Time = O(1)
		@param x item to be inserted before the current position */
	public void insertPriorGo(I x) 
	{
		this.insertBefore(x);
		this.goBack();
	}

	/**	Insert x after the current item. <br>
		Analysis: Time = O(1) 
		@param x item to be inserted after the current position */
	public void insertNext(I x) 
	{
		if (isEmpty() || before())
			insertFirst(x); 
		else if (this.position==lastNode())
			insertLast(x); 
		else if (after()) // if after then have to deal with previous node  
		{
			insertLast(x); 
			this.position = this.prevPosition.nextNode();
		}
		else // in the list, so create a node and set the pointers to the new node 
		{
			BilinkedNode280<I> temp = createNewNode(x);
			temp.setNextNode(this.position.nextNode());
			temp.setPreviousNode((BilinkedNode280<I>)this.position);
			((BilinkedNode280<I>) this.position.nextNode()).setPreviousNode(temp);
			this.position.setNextNode(temp);
		}
	}

	/**
	 * Insert a new element at the end of the list
	 * @param x item to be inserted at the end of the list 
	 */
	public void insertLast(I x) 
	{
		// TODO


		BilinkedNode280<I> obj;
		obj = new BilinkedNode280<I>(x); //obj my new bilinked node

		obj = createNewNode(x); //new node


		if(isEmpty()) { //if the node is empty
			head = obj; //the first node will be the new node
			tail = obj; //the last node will be the new node
		}
		else { //otherwise
			tail = obj; //my last node is now the new node

		}


	}

	/**
	 * Delete the item at which the cursor is positioned
	 * @precond itemExists() must be true (the cursor must be positioned at some element)
	 */
	public void deleteItem() throws NoCurrentItem280Exception
	{
		// TODO
		if (this.isEmpty()) throw new NoCurrentItem280Exception("Can't delete or alter an empty list.");

		if (position == tail){ //to check if my cursor is the last node
			deleteLast();
			position = tail; //then my position will be the tail after deleting the position of the cursor


		}
		else {//otherwise
			prevPosition.setNextNode(position.nextNode); //set my previous node to be the position of the cursor of the next node

		}


	}

	
	@Override
	public void delete(I x) throws ItemNotFound280Exception {
		if( this.isEmpty() ) throw new ContainerEmpty280Exception("Cannot delete from an empty list.");

		// Save cursor position
		LinkedIterator280<I> savePos = this.currentPosition();
		
		// Find the item to be deleted.
		search(x);
		if( !this.itemExists() ) throw new ItemNotFound280Exception("Item to be deleted wasn't in the list.");

		// If we are about to delete the item that the cursor was pointing at,
		// advance the cursor in the saved position, but leave the predecessor where
		// it is because it will remain the predecessor.
		if( this.position == savePos.cur ) savePos.cur = savePos.cur.nextNode();
		
		// If we are about to delete the predecessor to the cursor, the predecessor 
		// must be moved back one item.
		if( this.position == savePos.prev ) {
			
			// If savePos.prev is the first node, then the first node is being deleted
			// and savePos.prev has to be null.
			if( savePos.prev == this.head ) savePos.prev = null;
			else {
				// Otherwise, Find the node preceding savePos.prev
				LinkedNode280<I> tmp = this.head;
				while(tmp.nextNode() != savePos.prev) tmp = tmp.nextNode();
				
				// Update the cursor position to be restored.
				savePos.prev = tmp;
			}
		}
				
		// Unlink the node to be deleted.
		if( this.prevPosition != null)
			// Set previous node to point to next node.
			// Only do this if the node we are deleting is not the first one.
			this.prevPosition.setNextNode(this.position.nextNode());
		
		if( this.position.nextNode() != null )
			// Set next node to point to previous node 
			// But only do this if we are not deleting the last node.
			((BilinkedNode280<I>)this.position.nextNode()).setPreviousNode(((BilinkedNode280<I>)this.position).previousNode());
		
		// If we deleted the first or last node (or both, in the case
		// that the list only contained one element), update head/tail.
		if( this.position == this.head ) this.head = this.head.nextNode();
		if( this.position == this.tail ) this.tail = this.prevPosition;
		
		// Clean up references in the node being deleted.
		this.position.setNextNode(null);
		((BilinkedNode280<I>)this.position).setPreviousNode(null);
		
		// Restore the old, possibly modified cursor.
		this.goPosition(savePos);
		
	}
	/**
	 * Remove the first item from the list.
	 * @precond !isEmpty() - the list cannot be empty
	 */
	public void deleteFirst() throws ContainerEmpty280Exception
	{
		// TODO
		if (!(this.isEmpty())) throw new ContainerEmpty280Exception("List can't be empty");

		if (prevPosition == head){ //if the prev cursor positioned is equal to head
			deleteFirst(); //then remove the first item
			prevPosition = head; //then my prev position will be the head
		}
		else {
			position = head;{ //then my cursor position is the first node

			}


		}




	}

	/**
	 * Remove the last item from the list.
	 * @precond !isEmpty() - the list cannot be empty
	 */
	public void deleteLast() throws ContainerEmpty280Exception
	{
		// TODO
		//if (this.isEmpty()) throw new ContainerEmpty280Exception("List can't be empty");

		if (prevPosition == tail){ //check if my prev position is equal to the last node
			deleteLast(); //delete the last item from the list
			prevPosition = tail; //assign my prev cursor position to be the last node
		}
		else {
			if (position == tail){ // if my cursor position is the last node
				prevPosition = tail;

			}
		}

	}

	
	/**
	 * Move the cursor to the last item in the list.
	 * @precond The list is not empty.
	 */
	public void goLast() throws ContainerEmpty280Exception
	{
		// TODO
		if (isEmpty()) throw new ContainerEmpty280Exception("List is Empty");

		position = tail; //moved my cursor position to be the last node




	}
  
	/**	Move back one item in the list. 
		Analysis: Time = O(1)
		@precond !before() 
	 */
	public void goBack() throws BeforeTheStart280Exception {
		// TODO
		if ((before())) throw new BeforeTheStart280Exception("Cursor should be the first item in the list ");

		position = prevPosition; //moved my cursor to be the previous position;

	}




	/**	Iterator for list initialized to first item. 
		Analysis: Time = O(1) 
	*/
	public BilinkedIterator280<I> iterator()
	{
		return new BilinkedIterator280<I>(this);
	}

	/**	Go to the position in the list specified by c. <br>
		Analysis: Time = O(1) 
		@param c position to which to go */
	@SuppressWarnings("unchecked")
	public void goPosition(CursorPosition280 c)
	{
		if (!(c instanceof BilinkedIterator280))
			throw new InvalidArgument280Exception("The cursor position parameter" 
					    + " must be a BilinkedIterator280<I>");
		BilinkedIterator280<I> lc = (BilinkedIterator280<I>) c;
		this.position = lc.cur;
		this.prevPosition = lc.prev;
	}

	/**	The current position in this list. 
		Analysis: Time = O(1) */
	public BilinkedIterator280<I> currentPosition()
	{
		return  new BilinkedIterator280<I>(this, this.prevPosition, this.position);
	}

	
  
	/**	A shallow clone of this object. 
		Analysis: Time = O(1) */
	public BilinkedList280<I> clone() throws CloneNotSupportedException
	{
		return (BilinkedList280<I>) super.clone();
	}


	/* Regression test. */
	public static void main(String[] args) {
		// TODO

		BilinkedList280<Integer> I = new BilinkedList280<>();

		System.out.println(I);

		System.out.println("List should not be empty");
		if (I.isEmpty()) System.out.println("and it is");
		else System.out.println("ERROR: and it is NOT.");

		//insert method
		I.insertFirst(100);
		I.insertFirst(200);
		I.insertFirst(300);
		I.insertFirst(400);
		I.insertFirst(500);

		if (I.before())
			System.out.println("ERROR: Cursor should be in before() position.");

		I.insert(1);

		I.insertLast(1000);


		System.out.println("Insert should read 100, 200, 300, 400, 500:");
		System.out.println(I);

		System.out.println("List should not be full");
		if (!(I.isFull()))
			System.out.println("It is Okay.");
		else {
			System.out.println("Not Okay. ERROR.");
		}

		System.out.println("List should be 100, 200, 300, 400, 500");
		System.out.println("  Correct.");
		System.out.println(I);

		//Delete method
		I.delete(1000);
		System.out.println("List should be 100, 200, 300, 400, 500");
		System.out.println("  Correct.");
		System.out.println(I);


		I.deleteFirst();
		System.out.println("List should be 100, 200, 300, 400, 500");
		System.out.print("   Correct.");
		System.out.println(I);

		I.deleteLast();
		System.out.println("List should be 100, 200, 300, 400, 500");
		System.out.print("   Correct.");
		System.out.println(I);

		I.insertFirst(28);
		I.insertFirst(29);
		I.insertLast(27);
		I.insertLast(28);

		//Test for go last
		I.goLast();
		if (I.item() == 28) {
			System.out.println("List should be 28");
			System.out.println("   Correct.");

		} else {
			System.out.println("Not Correct. Is not okay");
		}

		//Test for go back
		I.goBack();
		if (I.item() == 29) {
			System.out.println("List should be 29");
			System.out.println("   Correct.");

		} else {
			System.out.println("Not Correct. Is not okay");
		}

		BilinkedList280<Integer> C = new BilinkedList280<>();
		C.insertFirst(2);
		C.insertLast(1);
		C.insertLast(100);

		C.goLast();
		if (C.item() == 100) {
			System.out.println("List should be 28");
			System.out.println("   Correct.");

		} else {
			System.out.println("Not Correct. Is not okay");
		}

		class myPair extends Pair280<Integer, Double> implements Comparable<myPair> {

			public myPair(Integer v1, Double v2) {
				super(v1, v2);
			}

			public int compareTo(myPair other) {
				return this.firstItem.compareTo(other.firstItem);
			}
		}

		BilinkedList280<myPair> X = new BilinkedList280<myPair>();
		myPair x = new myPair(100, 50.0);
		myPair y = new myPair(200, 25.05);
		X.insert(x);

		X.goAfter();
		X.search(x);
		if (X.itemExists())
			System.out.println("Error: Item exist in the list.");

		X.goAfter();
		X.search(y);
		if (X.itemExists())
			System.out.println("Error.");

		//test for delete last

		BilinkedList280<Integer>
				total = new BilinkedList280<>();
		for (int i = 0; i < 2; i++) {
			total.insertLast(i);
		}
		total.goFirst();
		total.goForth();
		total.deleteLast();
		if (total.tail == total.head && total.tail.item() != 1 && total.item() == 0) {
			total.head.nextNode();
		}

		// Test deleteLast() when cursor is in on the last element
		C.search(1);
		if (!C.itemExists() || C.item() != 1) {
			System.out.println("Error in the search list");

		}
		C.deleteLast();


		// preconditions TESTING
		System.out.println("Delete first item IN EMPTY LIST.");
		try {
			C.deleteFirst();
			System.out.println("ERROR: exception should have been thrown");
		}
		catch( ContainerEmpty280Exception e ) {
			System.out.println("OK!");
		}

		System.out.println("Deleting last item from empty list.");
		try {
			C.deleteLast();
			System.out.println("OK!");
		}
		catch( ContainerEmpty280Exception e ) {
			System.out.println("Caught exception. OK!");


		}



		System.out.println("Getting first item from empty list.");
		try {
			C.firstItem();
			System.out.println("OK!");
		}
		catch( ContainerEmpty280Exception e ) {
			System.out.println("Caught exception. OK!");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			I.insert(20);
			System.out.println("Deleting 5 from list from list");
			try {
				I.delete(5);
				System.out.println("ERROR: exception should have been thrown but did not");
			} catch (ItemNotFound280Exception f) {
				System.out.println("OK!");
			}


			I.insert(100);
			I.insert(1000);
			I.insert(10000);
			I.insert(100000);
		}

		I.search(100);
		System.out.print("cursor should be at 100 ....");
		if( C.item() == 100 ) System.out.println("and it is OK!");
		else System.out.println("it is OKAY");

		if (C.before())
			System.out.println("ERROR: Cursor should be in before() position.");



		//////////////////////////////////////////////////////////////////////////////////////////////////////////////














	}
}