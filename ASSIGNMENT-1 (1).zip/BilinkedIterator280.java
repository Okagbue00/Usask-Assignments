package lib280.list;


import lib280.base.BilinearIterator280;
import lib280.exception.BeforeTheStart280Exception;
import lib280.exception.ContainerEmpty280Exception;

/**	A LinkedIterator which has functions to move forward and back, 
	and to the first and last items of the list.  It keeps track of 
	the current item, and also has functions to determine if it is 
	before the start or after the end of the list. */
public class BilinkedIterator280<I> extends LinkedIterator280<I> implements BilinearIterator280<I>
{

	/**	Constructor creates a new iterator for list 'list'. <br>
		Analysis : Time = O(1) 
		@param list list to be iterated */
	public BilinkedIterator280(BilinkedList280<I> list)
	{
		super(list);
	}

	/**	Create a new iterator at a specific position in the newList. <br>
		Analysis : Time = O(1)
		@param newList list to be iterated
		@param initialPrev the previous node for the initial position
		@param initialCur the current node for the initial position */
	public BilinkedIterator280(BilinkedList280<I> newList, 
			LinkedNode280<I> initialPrev, LinkedNode280<I> initialCur)
	{
		super(newList, initialPrev, initialCur);
	}
    
	/**
	 * Move the cursor to the last element in the list.
	 * @precond The list is not empty.
	 */
	public void  goLast() throws ContainerEmpty280Exception
	{
		// TODO
		if (!itemExists()) throw new IllegalArgumentException("List is not empty"); //checks if there is no item in the list


		if (cur == list.tail){// checks if my current item in the node is my last node in the list
			list.lastNode(); //assign my cursor to be the last element in the node
		}
		else { //otherwise


		prev = list.lastNode(); //my previous node will then be last node in the list
		cur = list.lastNode(); //and my cursor position will be the last node in the list




	}
	}

	/**
	 * Move the cursor one element closer to the beginning of the list
	 * @precond !before() - the cursor cannot already be before the first element.
	 */
	public void goBack() throws BeforeTheStart280Exception
	{
		// TODO
		if (!(before())) throw new BeforeTheStart280Exception("Cursor can't be the first elememt"); //throws an error if cursor is the element

		if (cur == list.firstNode()){ //checks if the current position is the first node in the list
			goBefore(); //the cursor cant be the first element
		}
		else { //otherwise
			cur = prev; //assign my current position to be the previous element in the node

			prev = prev.nextNode(); //previous current node will be the next node of my previous node list.
		}










	 }

	/**	A shallow clone of this object. <br> 
	Analysis: Time = O(1) */
	public BilinkedIterator280<I> clone()
	{
		return (BilinkedIterator280<I>) super.clone();
	}


} 
