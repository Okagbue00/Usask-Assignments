% Okagbue Onyeka Francis
% Ono206
% 11279373
% Assignment 5
% Cmpt 340
% Question 1 and 2

% Prolog Programming

% Problem 1

% person 1 is married to person 2 or was married

ever_married_to(diana, charles).
ever_married_to(charles, diana).
ever_married_to(charles, camilla).
ever_married_to(camilla, charles).
ever_married_to(william, catherine).
ever_married_to(catherine, william).
ever_married_to(harry, meghan).
ever_married_to(meghan, harry).

% person 1 is a child of person 2

child_of(william, charles).
child_of(william, diana).
child_of(harry, charles).
child_of(harry, diana).
child_of(archie, harry).
child_of(archie, meghan).
child_of(lilibet, harry).
child_of(lilibet, meghan).
child_of(george, william).
child_of(george, catherine).
child_of(charlotte, william).
child_of(charlotte, catherine).
child_of(louis, william).
child_of(louis, catherine).

% person is male

male(charles).
male(william).
male(harry).
male(george).
male(louis).
male(archie).

% person is female

female(diana).
female(camilla).
female(catherine).
female(meghan).
female(charlotte).
female(lilibet).

% person is no longer alive

deceased(diana).

% person is a senior royal

senior_royal(diana).
senior_royal(charles).
senior_royal(camilla).
senior_royal(william).
senior_royal(catherine).
senior_royal(george).
senior_royal(charlotte).
senior_royal(louis).


% Problem 2

father_of(X, Y) :- male(X), child_of(Y, X).

brother_of(X, Y) :- male(X), father_of(Z, Y), child_of(X, Z).

% person 1 is the uncle of person 2

% is parent siblings
uncle_of(X, Y) :- male(X), child_of(Y, Z), brother_of(X, Z).

% is parent sibling marriage
uncle_of(X, Y) :- male(X), child_of(Y, Z), child_of(Z, W), child_of(V, W), ever_married_to(X, V), not(child_of(Y, X)).

% person 1 is the grandmother of person 2
grandmother_of(X, Y) :- female(X), child_of(Y, Z), child_of(Z, X).

% person 1 is the grandson of person 2
grandson_of(X, Y) :- male(X), child_of(X, Z), child_of(Z, Y).

% person 1 is the parent of person 2
parent_of(X, Y) :- child_of(Y, X).

% person 1 is the mother of person 2
mother_of(X, Y) :- female(X), child_of(Y, X).

% person 1 is step mother of person 2
stepmother_of(X, Y) :- female(X), father_of(Z, Y), ever_married_to(X, Z), not(child_of(X, Y)). 

% person 1 is the son of person 2
son_of(X, Y) :- male(X), child_of(X, Y).