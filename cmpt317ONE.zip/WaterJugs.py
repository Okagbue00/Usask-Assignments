#OKAGBUE FRANCIS
#ono206
#11279373



# CMPT 317: Problem Class Template

# Copyright (c) 2016-2019 Michael C Horsch and Jeff Long,
# Department of Computer Science, University of Saskatchewan

# This file is provided solely for the use of CMPT 317 students.  Students are permitted
# to use this file for their own studies, and to make copies for their own personal use.

# This file should not be posted on any public server, or made available to any party not
# enrolled in CMPT 317.

# This implementation is provided on an as-is basis, suitable for educational purposes only.
#

import random as rand
import math as math

class State(object):

    def __init__(self, preceding_action, jugWater=[0,0,0]):
        """
        Initialize the State object.
        """
        # each state MUST store the action that created it
        # if you want to be able to actually see your solutions
        self.action = preceding_action
        self.jugWater = jugWater
        #pass


    def __str__(self):
        """ A string representation of the State """
        return "<{}>".format(self.jugWater)


    def __eq__(self, other):
        """ Allows states to be compared"""
        return self.jugWater == other.jugWater


class Problem(object):
    """The Problem class defines aspects of the problem.
       One of the important definitions is the transition model for states.
       To interact with search classes, the transition model is defined by:
            is_goal(s): returns true if the state is a goal state.
            actions(s): returns a list of all legal actions in state s
            result(s,a): returns a new state, the result of doing action a in state s

    """

    def __init__(self, goal):
        """ The problem is defined by a target value.  We want to measure that many
        liters of water.

            :param goal: the number of liters of water we want to measure

        """
        self.goal = goal
        # INSERT WHATEVER ELSE YOU NEED HERE


    def create_initial_state(self):
        """ returns an initial state 
        """  
        return State(None)

    def is_goal(self, a_state:State):
        """Determine whether a_state is a goal state"""

        return any(map(lambda l: l == self.goal, a_state.jugWater))

    def actions(self, a_state:State):
        """ Returns all the actions that are legal in the given state.
            
        """

        # Define a helper function to generate the actions
        def actions_generator(caps):
            for i, max in enumerate(caps):
                # Filling a jug from faucet
                if a_state.jugWater[i] < max:
                    yield f'Fill jug {max}'

                # Empty a jug to ground
                if a_state.jugWater[i] > 0:
                    yield f'Empty jug {max}'

                    # Pouring water from one jug to another
                if a_state.jugWater[i] > 0:
                    for j, cap in enumerate(caps):
                        # Skip self
                        if i == j:
                            continue

                            # Destination should not be full
                        if a_state.jugWater[j] == cap:
                            continue

                            # Pour
                        yield f'Pour jug {max} to jug {cap}'

        return list(actions_generator([15, 7, 4]))

    def result(self, a_state:State, an_action):
        """Implements the transition function.
        Given a state and an action, return the resulting state.
          
        """

        # Define an action converter to compute the corresponding change in level
        def get_change(action, caps, state: State):
            if action.startswith('Fill jug'):
                # Split the tokens
                tokens=action.split()
                # Compute the change
                cap=int(tokens[2])
                index=caps.index(cap)
                action=[0] * len(caps)
                action[index]=cap - state.jugWater[index]

                return action
            elif action.startswith('Empty jug'):
                # Split tokens
                tokens=action.split()
                # Compute the change
                cap=int(tokens[2])
                index=caps.index(cap)
                action=[0] * len(caps)
                action[index]=-state.jugWater[index]

                return action
            else:
                # Split tokens
                tokens=action.split()
                cap1=int(tokens[2])
                cap2=int(tokens[5])
                # Compute the change
                index1=caps.index(cap1)
                index2=caps.index(cap2)
                poured=min(state.jugWater[index1], cap2 - state.jugWater[index2])
                action=[0] * len(caps)
                action[index1]=-poured
                action[index2]=+poured

                return action

                # Apply the action

        return State(an_action, [sum(x) for x in zip(a_state.jugWater, get_change(an_action, [15, 7, 4], a_state))])



# end of file

