/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */


package com.example.cmpt381_asn2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;

public class view1 extends Application
{

    int screenWidth = (int) Screen.getPrimary().getBounds().getWidth();
    int screenHeight = (int) Screen.getPrimary().getBounds().getHeight();
    @Override
    public void start(Stage stage) throws IOException {

        int sceneWidth = 0;
        int sceneHeight = 0;


        if (screenWidth <= 800 && screenHeight <= 600) {
            sceneWidth = 600;
            sceneHeight = 350;

        } else if (screenWidth <= 1280 && screenHeight <= 800) {
            sceneWidth = 800;
            sceneHeight = 450;


        } else if (screenWidth <= 1920 && screenHeight <= 1000) {
            sceneWidth = 1000;
            sceneHeight = 650;
        }

        // buttons for booking the system court
        Button nsid = new Button();
        Button court_number = new Button();
        Button time_slot = new Button();

        //this is the textfield for nsid info
        TextField nsid_textfield = new TextField();
        nsid_textfield.setMaxWidth(100);

        //dropdown button for court number

        final ComboBox<String> court_number_combo_box = new ComboBox<String>();
        court_number_combo_box.getItems().addAll("1", "2", "3", "4", "5", "6");
        court_number_combo_box.setValue("1");

        final ComboBox<String> time_slot_combo_box = new ComboBox<String>();
        time_slot_combo_box.getItems().addAll("3-4pm", "4-5pm", "5-6pm", "6-7pm", "7-8pm", "8-9pm");
        time_slot_combo_box.setValue("7-8pm");



        //label for client
        Label clientLabel= new Label();
        clientLabel.setFont(Font.font("Arial", 20));

        //label for billing
        Label billLabel= new Label();
        billLabel.setFont(Font.font("Arial", 20));

        //label for day
        Label dayLabel= new Label();
        dayLabel.setFont(Font.font("Arial", 20));

        //label for month
        Label monthLabel= new Label();
        monthLabel.setFont(Font.font("Arial", 20));

        //label for task
        Label taskLabel= new Label();
        taskLabel.setFont(Font.font("Arial", 20));

        // display the result
        TextArea result= new TextArea();
        result.setEditable((false));
        result.setMinSize(420,150);
        result.setMaxSize(600,150);

        //labels for the nsid name
        Label nsid_label = new Label();
        nsid_label.setFont(Font.font("Poppins", 24));

        Label court_number_label = new Label();
        court_number_label.setFont(Font.font("Poppins", 24));

        Label time_slot_label = new Label();
        time_slot_label.setFont(Font.font("Poppins", 24));

        //textbox for each of the menu for the booking system

        nsid.setText("NSID");
        court_number.setText("Tennis Court Number");
        time_slot.setText("Available Time Slots");

        // display the result
        TextArea text_result = new TextArea();
        text_result.setEditable((false));

        text_result.setMinSize(220,50);
        text_result.setMaxSize(220,50);

        //this is a button to accomplish the task

        Button button_done = new Button("Book Court");

        button_done.setOnAction(e -> text_result.setText("The nsid is " + nsid_textfield.getText() + "\n"
        + "The booked tennis court number is " + court_number_combo_box.getValue() + "\n"
        + "The available time slots is " + time_slot_combo_box.getValue())
        );


        //this is to clear the textarea field {undo}
        Button button_clear =new Button("Cancel");

        button_clear.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                text_result.clear();
            }
        });

        //the horizontal box for booking and cancelling
        HBox hbox_items= new HBox();
        hbox_items.setPadding(new Insets(10));
        hbox_items.setAlignment(Pos.CENTER);
        hbox_items.setSpacing(25);

        hbox_items.getChildren().addAll(button_done, button_clear);


        // this is the vbox for all the components in the system

        VBox vbox_items=new VBox(10);
        vbox_items.setAlignment(Pos.CENTER);

        vbox_items.getChildren().addAll(nsid, nsid_textfield, court_number, court_number_combo_box, time_slot, time_slot_combo_box, text_result, hbox_items);

        Scene scene = new Scene(vbox_items, sceneHeight, sceneWidth);
        stage.setTitle("tennis booking system");
        stage.setScene(scene);
        stage.setResizable(true);
        stage.show();

    }
}
