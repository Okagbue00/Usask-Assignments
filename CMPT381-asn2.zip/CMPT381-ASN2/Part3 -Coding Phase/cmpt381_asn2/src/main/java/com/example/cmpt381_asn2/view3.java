/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381_asn2;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javafx.stage.Screen;
import javafx.stage.Stage;


public class view3 extends Application {

    int screenWidth = (int) Screen.getPrimary().getBounds().getWidth();
    int screenHeight = (int) Screen.getPrimary().getBounds().getHeight();

    @Override
    public void start(Stage stage){

        int sceneWidth = 0;
        int sceneHeight = 0;


        if (screenWidth <= 800 && screenHeight <= 600) {
            sceneWidth = 600;
            sceneHeight = 350;

        } else if (screenWidth <= 1280 && screenHeight <= 800) {
            sceneWidth = 800;
            sceneHeight = 450;


        } else if (screenWidth <= 1920 && screenHeight <= 1000) {
            sceneWidth = 1000;
            sceneHeight = 650;
        }

        //textfields for the student info

        TextField nsid_textfield = new TextField();
        nsid_textfield.setMaxWidth(300);

        TextField first_name_textfield = new TextField();
        first_name_textfield.setMaxWidth(300);

        TextField last_name_textfield = new TextField();
        last_name_textfield.setMaxWidth(300);

        TextField court_number_textfield = new TextField();
        court_number_textfield.setMaxWidth(300);

        // this would display the text results in another different field
        TextArea text_result = new TextArea();
        text_result.setEditable((true));

        //this would set the min and max size of the text area
        text_result.setMinSize(220,50);
        text_result.setMaxSize(220,50);


        // this would complete and add the booked games to the text area

        Button booked_button =new Button("ADD TO SYSTEM");
        booked_button.setOnAction(e-> {text_result.setText( "FIRST NAME:- " + first_name_textfield.getText() + "\n"
                + "LAST NAME:- " + last_name_textfield.getText() + "\n"
                + "COURT NUMBER:- " + court_number_textfield.getText());
        });

        //this would cancel the booked games in the system
        Button button_cancel =new Button("CANCEL BOOKED GAMES ");

        button_cancel.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                text_result.clear();
            }
        });

        //the horizontal box for the complete and cancel booking system

        HBox hbox_system = new HBox();
        hbox_system.setPadding(new Insets(15));
        hbox_system.setAlignment(Pos.CENTER);
        hbox_system.setSpacing(25);

        //adds all the button
        hbox_system.getChildren().addAll(booked_button, button_cancel);




        // this is the horizontal box for the first name field
        HBox hbox2 = new HBox();
        hbox2.setPadding(new Insets(12));
        hbox2.setSpacing(25);

        hbox2.getChildren().add(new Label("First Name"));
        hbox2.getChildren().add(first_name_textfield);


        // this is the horizontal box for the last name field
        HBox hbox3 = new HBox();
        hbox3.setPadding(new Insets(12));
        hbox3.setSpacing(25);

        hbox3.getChildren().add(new Label("Last Name"));
        hbox3.getChildren().add(last_name_textfield);

        // this is the horizontal box for the court number field
        HBox hbox4 = new HBox();
        hbox4.setPadding(new Insets(12));
        hbox4.setSpacing(25);

        hbox4.getChildren().add(new Label("Court Number"));
        hbox4.getChildren().add(court_number_textfield);

        //renders all the components

        VBox vbox_booked_system = new VBox();

        vbox_booked_system.setAlignment(Pos.CENTER);
        vbox_booked_system.getChildren().addAll(hbox2, hbox3, hbox4, text_result, hbox_system);


        //renders the view3 system
        Scene scene = new Scene(vbox_booked_system,sceneWidth, sceneHeight);
        stage.setTitle("BOOKED TENNIS MANAGER");
        stage.setScene(scene);
        stage.setResizable(true);
        stage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}