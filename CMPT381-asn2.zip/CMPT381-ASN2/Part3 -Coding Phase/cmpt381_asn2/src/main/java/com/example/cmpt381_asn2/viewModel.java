package com.example.cmpt381_asn2;

import java.util.ArrayList;

public class viewModel {
    protected final ArrayList<viewModelSubscriber> subs;

    public viewModel(ArrayList<viewModelSubscriber> subs) {
        this.subs = subs;
    }

    protected void addSub(viewModelSubscriber newSub) {
        subs.add(newSub);
    }

    protected void notifySubs() {
        for (viewModelSubscriber sub : subs) {
            sub.modelChanged();
        }

    }
}
