package com.example.cmpt381_asn2;

import java.util.ArrayList;

public class InteractionModel {

    ArrayList<InteractionModelSubscriber> subs;



    protected InteractionModel() {
        subs = new ArrayList<>();
    }

    protected void addiSub(InteractionModelSubscriber newSub) {
        subs.add(newSub);
    }


    protected void notifySubs() {
        for (InteractionModelSubscriber sub : subs) {
            sub.iModelChanged();
        }

    }
}
