/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381_asn2;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;

public class MainUI extends StackPane {

    // it stores all the widgets
    ListView<CourtRoom> houses;
    ListView<SearchSpec> searches;
    ControlFilter priceFilter;

    TextField searchName;
    Button saveButton;
    Button loadButton;
    Button clearButton;
    Button quitButton;
    ArrayList<CourtRoom> courtList = CourtRoom.loadRoomList();
    SearchSpec filterSpec = new SearchSpec();

    /**
     * Construct the main UI control of the application.
     */
    public MainUI() {
        setPrefWidth(800); // it sets the size
        GridPane mainBox = new GridPane(); // it adds the widgets
        getChildren().add(mainBox); // it adds the main box

        // Set constraints to grid pane
        ColumnConstraints columnConst = new ColumnConstraints();
        columnConst.setPercentWidth(50);
        mainBox.getColumnConstraints().add(columnConst);
        mainBox.getColumnConstraints().add(columnConst);

        RowConstraints rowConst = new RowConstraints();
        rowConst.setPercentHeight(100);
        mainBox.getRowConstraints().add(rowConst);

        // Add the left and right boxes
        VBox leftBox = setupLeftBox();
        mainBox.add(leftBox, 0, 0);

        VBox rightBox = setupRightBox();
        mainBox.add(rightBox, 1, 0);
    }

    /**
     * Setup the left box of the application.
     * @return the vertical box control
     */
    private VBox setupLeftBox() {
        VBox leftBox = new VBox();
        leftBox.setSpacing(5);
        leftBox.setPadding(new Insets(5));

        // Add controls to the left box
        Label title = new Label("Available Court Rooms");
        leftBox.getChildren().add(title);
        title.setStyle("-fx-font-size: 200%; -fx-font-weight: bold; -fx-text-fill:green; ");

        // Create the list view for houses
        houses = new ListView<CourtRoom>();
        houses.getItems().addAll(courtList);
        leftBox.getChildren().add(houses);
        VBox.setVgrow(houses, Priority.ALWAYS);

        // Add the filter controls
        priceFilter = new ControlFilter("Number", 1, 6, 1, 6);


        // Setup the filter controls
        setupFilterEvents();
        createNewSpec();    // Create a valid filter specification
        leftBox.getChildren().addAll(priceFilter);

        // Add the save search box
        leftBox.getChildren().add(setupSaveSearch());

        return leftBox;
    }

    /**
     * Create a new specification based on the filter controls' values.
     */
    private void createNewSpec() {
        filterSpec = new SearchSpec();

        // Get the values from the filter controls
        filterSpec.setCourtLower(priceFilter.lower().get());
        filterSpec.setCourtUpper(priceFilter.upper().get());

    }

    /**
     * Setup the filter events to update the filter when the set button is pressed.
     */
    private void setupFilterEvents() {
        // Create an event handler for all the set buttons
        final EventHandler<ActionEvent> filterHandler = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                // Update current spec
                createNewSpec();
                filter();
            }
        };

        // Set the common event handler to all filter controls
        priceFilter.setOnAction(filterHandler);

    }

    /**
     * Setup the save search box that will store the search specifications.
     * @return horizontal box of the save search
     */
    private HBox setupSaveSearch() {
        // Create save search box
        HBox saveBox = new HBox();
        saveBox.setSpacing(5);

        // Create the controls and set its properties
        saveButton = new Button("Book");
        searchName = new TextField();
        searchName.setPromptText("Court Number");

        saveBox.getChildren().addAll(new Label("Book Court:"), searchName, saveButton);
        HBox.setHgrow(searchName, Priority.ALWAYS);

        // Setup event for save button
        saveButton.setOnAction((event) -> {
            // Only save if name is saved
            if (searchName.getText().length() > 0) {
                // Update the name of the search spec
                filterSpec.setName(searchName.getText());

                // Add to the searches list view
                searches.getItems().add(filterSpec);

                // Clear the text box
                searchName.clear();
            }
        });

        return saveBox;
    }

    /**
     * Setup the buttons box to control the searches list.
     * @return horizontal box of the buttons
     */
    private HBox setupButtonsBox() {
        // it creates the buttons box
        HBox buttonsBox = new HBox();
        buttonsBox.setSpacing(5);

        // Create buttons
        loadButton = new Button("Load Search");
        clearButton = new Button("Cancel Booking");
        quitButton = new Button("Quit");

        //styling the buttons

        clearButton.setStyle("-fx-text-fill:black; -fx-background-color:red");
        quitButton.setStyle("-fx-text-fill:black; -fx-background-color:red");

        // Configure button events
        quitButton.setOnAction((action) -> {
            Platform.exit();
        });

        clearButton.setOnAction((action) -> {
            searches.getItems().clear();
        });

        loadButton.setOnAction((action) -> {
            // Selected search spec
            SearchSpec selectedItem = searches.getSelectionModel().getSelectedItem();

            // Update only if there is a selected item
            if (selectedItem == null) {
                return;
            }

            // Get the selected searches item
            filterSpec = selectedItem;

            // Update the filter controls
            priceFilter.lower().set(filterSpec.getCourtLower());
            priceFilter.upper().set(filterSpec.getCourtUpper());


            // Apply the filter
            filter();
        });

        // Add to the box
        buttonsBox.getChildren().addAll(loadButton, clearButton, quitButton);

        // Adjust the width
        HBox.setHgrow(loadButton, Priority.ALWAYS);
        HBox.setHgrow(clearButton, Priority.ALWAYS);

        loadButton.setMaxWidth(Double.MAX_VALUE);
        clearButton.setMaxWidth(Double.MAX_VALUE);
        quitButton.setMinWidth(80);

        return buttonsBox;
    }

    /**
     * Setup the right box that contains the search list.
     * @return
     */
    private VBox setupRightBox() {
        VBox rightBox = new VBox();
        rightBox.setSpacing(5);
        rightBox.setPadding(new Insets(5));

        // Create the list view of searches
        searches = new ListView<SearchSpec>();

        // Add controls to the right box
        Label title = new Label("Booked Court Rooms");
        title.setStyle("-fx-font-size: 150%; -fx-font-weight: bold; -fx-text-fill:green;" );
        rightBox.getChildren().add(title);
        rightBox.getChildren().add(searches);
        VBox.setVgrow(searches, Priority.ALWAYS);

        rightBox.getChildren().add(setupButtonsBox());

        return rightBox;
    }

    /**
     * Apply the current filter search specification.
     */
    private void filter() {
        houses.getItems().clear(); // clears the house list search


    }

}

