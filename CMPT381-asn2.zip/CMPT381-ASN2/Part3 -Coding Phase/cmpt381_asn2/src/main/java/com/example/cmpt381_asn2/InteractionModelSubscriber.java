package com.example.cmpt381_asn2;

public interface InteractionModelSubscriber {
    void iModelChanged();
}
