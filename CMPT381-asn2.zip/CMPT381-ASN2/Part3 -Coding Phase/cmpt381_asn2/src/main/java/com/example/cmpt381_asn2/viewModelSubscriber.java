package com.example.cmpt381_asn2;

public class viewModelSubscriber {
    void modelChanged() {

    }
}
