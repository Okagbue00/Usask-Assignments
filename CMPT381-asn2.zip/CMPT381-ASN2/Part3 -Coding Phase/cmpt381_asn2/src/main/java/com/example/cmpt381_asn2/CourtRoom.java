/* Okagbue  Onyeka Francis
 * Ono206
 * 11279373 */

package com.example.cmpt381_asn2;

import java.util.ArrayList;

public class CourtRoom {

    private final String court_number;



    /**
     * Create a court-room object based on the given line.
     * @param line line object
     * @throws IllegalArgumentException when the input line is invalid
     */
    public CourtRoom(String line) throws IllegalArgumentException {
        // it splits the string
        String[] tokens = line.split(",");

        try {
            court_number = tokens[0];


        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    /**
     * Convert the court-room data into a string.
     * @return formatted string of the house
     */
    @Override
    public String toString() {
        return String.format("%s",
                court_number);
    }

    /**
     * Get the court-room number.
     * @return address
     */
    public String getCourt_number()
    {
        return court_number;
    }


    /**
     * Initialize all court-room values.
     */

    static String[] courtLines = {"Court Room: 1", "Court Room: 2", "Court Room: 3", "Court Room: 4", "Court Room: 5", "Court Room: 6"};

    /**
     * Load house list from the static variable.
     * @return array list of court-room
     */
    public static ArrayList<CourtRoom> loadRoomList() {
        ArrayList<CourtRoom> roomList = new ArrayList<>();

        for (String line : courtLines) {
            roomList.add(new CourtRoom(line));
        }

        return roomList;
    }

}
