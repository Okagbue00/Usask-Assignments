package com.example.cmpt381_asn2;

public class viewController {

    protected enum State {READY}

    protected State currentState;

    InteractionModel iModel;
    viewModel model;

    protected void setInteractionModel(InteractionModel newiModel) {
        iModel = newiModel;
    }

    protected viewController() {
        currentState = State.READY;
    }

    protected void setModel(viewModel newModel) {
        model = newModel;
    }




}


