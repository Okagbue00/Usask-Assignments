package com.example.cmpt381_asn2;

public class SearchSpec {
    private double courtLower = 0;
    private double courtHigher = Double.MAX_VALUE;

    private String name = "";

    /**
     * Get the name of the search specification.
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name of the search specification.
     * @param value new name
     */
    public void setName(String value) {
        name = value;
    }

    /**
     * Get the lower price.
     * @return lower price value
     */
    public double getCourtLower() {
        return courtLower;
    }

    /**
     * Get the court upper number.
     * @return upper price value
     */
    public double getCourtUpper() {
        return courtHigher;
    }

    /**
     * Set the court lower number.
     * @param value new lower price
     */
    public void setCourtLower(double value) {
        courtLower = value;
    }

    /**
     * Set the court upper number.
     * @param value new upper price
     */
    public void setCourtUpper(double value) {
        courtHigher = value;
    }



    /**
     * Convert the filter specification to string.
     * @return Formatted string showing the details of the filter specification
     */
    public String toString() {
        return String.format("%s: Booked Court Room %.0f-%.0f",
                name, courtLower, courtHigher);
    }
}
